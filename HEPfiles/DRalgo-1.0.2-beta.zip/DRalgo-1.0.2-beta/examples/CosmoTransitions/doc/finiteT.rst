finiteT.py
----------------------------------------

.. automodule:: cosmoTransitions.finiteT
    :members:
