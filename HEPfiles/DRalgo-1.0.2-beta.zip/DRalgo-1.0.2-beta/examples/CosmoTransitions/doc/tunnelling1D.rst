tunneling1D.py
----------------------------------------

.. automodule:: cosmoTransitions.tunneling1D

PotentialError
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoexception:: PotentialError

SingleFieldInstanton
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: SingleFieldInstanton
    :members:
    :undoc-members:
    :show-inheritance:

WallWithConstFriction
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: WallWithConstFriction
    :members:
    :undoc-members:
    :show-inheritance:

 
