#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import division
from __future__ import print_function
from scipy.interpolate import splrep, PPoly

import sys
import os
sys.path.append(os.path.abspath('/home/felipe/JoaoPino/1_Ashar_project/Cosmo/CosmoTransitions/'))

from cosmoTransitions.generic_potential import generic_potential
from modelDR_class_based import modelDR
# import transitionFinder_mod as transitionFinder
# import pathDeformation_mod as pathDeformation
from cosmoTransitions import transitionFinder
from cosmoTransitions import pathDeformation
import numpy as np
import warnings





class generic_potential_DR(modelDR, generic_potential):
    """
    Implements a generic model and its effective potential based on 
    dimensional reduction, for usage in CosmoTransitions.
    
    This class implements a generic model and its effective potential
    based on dimensional reduction, rather than the Coleman-Weinberg
    potential plus thermal corrections. The class subclasses the class
    generic_potential from CosmoTransitions as well as the class modelDR in 
    order to override the function Vtot with an expression for the effective
    potential based on dimensional reduction. 
    
    Because the dimensional reduction formalism only works down to a certain
    minimum temperature, the generic_potential class is slightly tweaked to
    start the phase search (in the overriden function getPhases) from a 
    strictly positive minimum temperature Tmin set by the user upon 
    initialization.
    
    In addition to the above changes, the function V0 is overriden to return
    the potential at temperature T = Tmin (rather than T = 0) and the function
    V1T_from_X is overriden to return Vtot. Also, the functions boson_massSq,
    fermion_massSq, V1 and V1T are overriden to throw a NotImplementedError,
    since these functions should not be called when using the generic_potential
    class in the dimensional reduction formalism.
    
    Regarding the phase transition, the function findAllTransitions() is 
    overriden to make sure the pressure difference is calculated using the
    expressions from dimensional reduction. Further, the functions 
    pruneTransitions and augmentTransitionDictionary have been added, with the
    former an auxiliary function to remove uninteresting transitions, and the 
    latter adding a few additional entries to the transition dictionary 
    self.TnTrans. The function prettyPrintTnTrans has been overriden to 
    additionally print these extra entries (if they are set).
    
    Aside from the various functions in modelDR that need to be overriden, a
    subclass of the present class may override the functions approxZeroTMin as
    well as gEff. The former should give the approximate location of the 
    minima at the minimum temperature Tmin which, if Tmin is small enough, 
    could probably reasonably be approximated by the zero temperature minima 
    (at least, it would give a better approximation than the default 
    implementation; see the CosmoTransitions generic_potential class). The
    function gEff should give the effective number of degrees of freedom as
    a function of temperature, and defaults to the constant value 106.75, 
    which is OK for phase transitions near the electroweak scale. 
    
    In addition, the function forbidPhaseCrit can be overriden to remove 
    certain phases. The default implementation ensures that phases do not 
    exceed the parameter X4DMax in the highTOptions dictionary, provided the 
    option enforceX4DMax is set to True in the same dictionary.
    """
    def __init__(self, Ndim, mu4DMinLow, mu4DMaxHigh, mu4DRef, params4DRef, 
                 highTOptions = {}, solve4DRGOptions = {}, 
                 params3DUSInterpolOptions = {}, scaleFactor = 1, 
                 mu3DSPreFactor = 1, auxParams = None, Tmin = None,
                 Tmax = None, orderDR = 1, orderVEff = 1, x_eps = .001,
                 T_eps = .001, deriv_order = 4):
        """
        Initialization method for the generic_potential_DR class.
        
        Parameters
        ----------
        Ndim : int
            The number of dynamic field dimensions in the model 
        mu4DMinLow : float
            The minimum value of μ4D (initial lower limit for the RG solver)
        mu4DMaxHigh : float, optional
            The maximum value of μ4D (initial upper limit for the RG solver)
        mu4DRef : float
            The reference value of the 4D RG scale parameter μ4D
        params4DRef : array
            The values of the 4D Lagrangian parameters at the scale mu4DRef        
        highTOptions : dictionary, optional
            An optional dictionary with some parameters pertaining to checking
            that the high temperature expansion is valid. The high temperature
            expansion is considered valid at temperature T and 3D field point 
            X3D if m(T,X3D) < (1/safetyFactor) * scaleFactor * π * T, where 
            m(T,X3D) denotes the largest field dependent boson mass at 
            temperature T and field point X3D. The following parameters can be
            specified in the dictionary:
                
            adjustTMinLow : bool
                If True, then the value of TMinLow will (if needed) be adjusted 
                so that the high temperature expansion is estimated to be 
                valid for all T ≥ TMinLow. 
            X4DMax : array_like
                The parameter must be set if adjustMuMin is set to True. 
                If so, the parameter should be a point in 4D field space which 
                provides an estimate of the maximum extent of field space that 
                needs to be covered. The value of X3D that will be used in the
                high temperature check is then X3D = X4D/√T.
            safetyFactor : float, optional
                A safety factor which appears in the high temperature check 
                (see above). Defaults to 1.
            enforceX4DMax : bool, optional
                If True, the forbidPhaseCrit function will by default forbid
                phases at a field point X satisfying np.any(abs(X) > X4DMax)
        solve4DRGOptions : dictionary, optional
            An optional dictionary with parameters to use for the solve_ivp
            method used for solving the 4D RG equations. The following 
            options can be specified in the dictionary:
            
            params4DMin : array, optional
                Optional array with minimum values for the 4D Lagrangian
                parameters. The solver will terminate when the minimum for
                at least one parameter is crossed.
            params4DMax : array, optional
                Optional array with maximum values for the 4D Lagrangian
                parameters. The solver will terminate when the maximum for
                at least one parameter is crossed.    
            method: string or OdeSolver, optional
                The integration method to use when solving the RG equations. 
                Check the documentation for scipy.integrate.solve_ivp for 
                details. Defaults to RK45.
            mu4DVals: array_like, optional
                The values of μ4D at which the solution will be computed. 
                Must be sorted and lie within the range [mu4DMin, mu4DMax].
                Corresponds to the option t_eval in scipy.integrate.solve_ivp.
                Defaults to None, in which case the solver picks the values.
            options: dictionary
                Options passed to a chosen solver. Check the documentation for
                scipy.integrate.solve_ivp for details.
        params3DUSInterpolOptions : dictionary, optional
            An optional dictionary with parameters to use for interpolation of
            the 3D parameters in the ultrasoft limit. If interpolation is used
            (as defined by the flag option 'interpolate'), a cubic spline 
            interpolation, using the function scipy.interpolate.CubicSpline, 
            will be made over the T-range [TMinLow, TMaxHigh] for each of the 
            3D parameters in the ultrasoft limit. This interpolation can 
            subsequently be used when calling the functions VEff3DComplex, 
            VEff3D, VThermalComplex and VThermal. The following options can be
            specified in the dictionary:
                
            interpolate : bool, optional
                Choose whether or not the 3D parameters should be evaluated
                through interpolation. Defaults to True.
            TVals: array_like, optional
                The values of T at which the 3D parameters will be computed
                for the interpolation. The values must cover the range 
                [TMinLow, TMaxHigh]. Defaults to None, in which case the 
                values are picked over the range [TMinLow, TMaxHigh] using the
                options below.
            nVals: int, optional
                The number of values of μ to be used for the interpolation.
                Defaults to int((TMaxHigh-TMinLow)/10).            
            scale: string, optional
                The scale to be used for the distribution. Can be either 'lin'
                (linear) or 'log' (logarithmic). Defaults to 'log'.   
        scaleFactor : float, optional
            A scale factor defined by the relation μ4DH = scaleFactor * pi * T.
            Defaults to 1.
        mu3DSPreFactor : float, optional
            The prefactor in the relation between μ3DS and the smallest Debye
            mass mDMin according to μ3DS = preFactor * mDMin. Defaults to 1.
        auxParams : tuple, optional
            A tuple of any auxiliary parameters appearing in the Lagrangian 
            Defaults to None.    
        Tmin : float, optional
            The minimum temperature used in the phase search. If set to None 
            (default), it is set to self.TMinLow. If the user-supplied value 
            is lower than this limit, Tmin is set to self.TMinLow and a 
            warning is made.
        Tmax : float, optional
            The maximum temperature used in the phase search. If set to None 
            (default), it is set to self.TMaxHigh. If the user-supplied value 
            is higher than this limit, Tmax is set to self.TMaxHigh and a 
            warning is made.
        orderDR : int, optional
            The order at which the dimensional reduction (i.e. the mathcing)
            is performed. Defaults to 1, corresponding to NLO.
        orderVEff : int, optional
            The order at which the potential will be calculated in the 
            functions V0, Vtot, VtotComplex and V1T_from_X. Defaults to 1,
            corresponding to NLO.
        x_eps : float, optional
            The epsilon to use in brute-force evalutations of the gradient and
            for the second derivatives. Defaults to 0.001.
        T_eps : float, optional
            The epsilon to use in brute-force evalutations of the temperature
            derivative. Defaults to 0.001.
        deriv_order : int, optional
            Sets the order to which finite difference derivatives are 
            calculated. Must be 2 or 4; defaults to 4.
        
        Raises
        ------
        ValueError
            A ValueError is raised if the parameters fail some basic sanity
            checks. An absence of a ValueError does not guarantee that all of
            the parameter values are sensible.
        """
        # super(generic_potential, self).__init__()
        # super(modelDR, self).__init__(muRef, params4DRef, muMinLow, muMax, 
        #                               highTOptions = {}, solve4DRGOptions = {}, 
        #                               params3DInterpolOptions = {}, 
        #                               scaleFactor = 1, mu3SPreFactor = 1, 
        #                               auxParams = None)
        modelDR.__init__(self, mu4DMinLow, mu4DMaxHigh, mu4DRef, params4DRef, 
                         highTOptions, solve4DRGOptions, 
                         params3DUSInterpolOptions, scaleFactor, 
                         mu3DSPreFactor, auxParams)
        
        if 'enforceX4DMax' not in self.highTOptions:
            self.highTOptions['enforceX4DMax'] = False
        if self.highTOptions['enforceX4DMax'] and 'X4DMax' not in             \
           self.highTOptions:
           raise ValueError("If enforceX4DMax is set to True in highTOptions,"\
                            "then X4DMax must be specified.")   
               
        generic_potential.__init__(self, Ndim, Tmin, Tmax, orderDR, orderVEff,
                                   x_eps, T_eps, deriv_order)
                
        
    def init(self, Ndim, Tmin, Tmax, orderDR, orderVEff, x_eps, T_eps, 
             deriv_order):
        """
        Init method needed for compatibility with the generic_potential class.

        Parameters
        ----------
        Ndim : int
            The number of dynamic field dimensions in the model. 
        Tmin : float, optional
            The minimum temperature used in the phase search. If set to None 
            (default), it is set to self.TMinLow. A user-defined value cannot 
            be lower than this limit.
        Tmax : float, optional
            The maximum temperature used in the phase search. If set to None 
            (default), it is set to self.TMaxHigh. A user-defined value cannot
            be larger than this limit.
        orderDR : int, optional
            The order at which the dimensional reduction (i.e. the mathcing)
            is performed. Defaults to 1, corresponding to NLO.
        orderVEff : int, optional
            The order at which the potential will be calculated in the 
            functions V0, Vtot, VtotComplex and V1T_from_X. Defaults to 1,
            corresponding to NLO.
        x_eps : float, optional
            The epsilon to use in brute-force evalutations of the gradient and
            for the second derivatives. Defaults to 0.001.
        T_eps : float, optional
            The epsilon to use in brute-force evalutations of the temperature
            derivative. Defaults to 0.001.
        deriv_order : int, optional
            Sets the order to which finite difference derivatives are 
            calculated. Must be 2 or 4; defaults to 4.
            
        Raises
        ------
        ValueError
            A ValueError is raised if the parameters fail some basic sanity
            checks. An absence of a ValueError does not guarantee that all of
            the parameter values are sensible.    
        """
        self.Ndim = Ndim
        if self.Ndim <= 0:
            raise ValueError("The number of dimensions in the potential must "
                             "be at least 1.")
        
        if Tmin is None:
            self.Tmin = self.TMinLow
        else:
            if Tmin < self.TMinLow:
                warnings.warn("Tmin cannot be smaller than TMinLow = ",
                              self.TMinLow)
                self.Tmin = self.TMinLow
            self.Tmin = Tmin
        if Tmax is None:
            self.Tmax = self.TMaxHigh
        else:
            if Tmax > self.TMaxHigh:
                warnings.warn("Tmax cannot be greater than TMaxHigh = ",
                              self.TMaxHigh)
                self.Tmax = self.TMaxHigh
            if Tmax <= Tmin:
                raise ValueError("If Tmax is set it must satisfy Tmax > Tmin.")
            self.Tmax = Tmax 
            
        if not orderDR in [0,1]:
            raise ValueError("The parameter orderDR must be 0 or 1.")
        self.orderDR = orderDR
        
        if not orderVEff in [0,1]:
            raise ValueError("The parameter orderVEff must be 0 or 1.")
        self.orderVEff = orderVEff
        
        self.x_eps = x_eps
        self.T_eps = T_eps
        self.deriv_order = deriv_order
        self.XMax = 10**20
        
        
    def V0(self, X):
        """
        The tree-level potential, as defined by the V0Func parameter.
    
        This function returns the tree-level potential at T = Tmin. More
        specifically, the function returns T*VEff3D, where VEff3D is the 3D
        effective potential at T = Tmin and with the field values X3D = X/√T.  
        The function is not super important, and is mostly used for plotting.
        
        Parameters
        ----------
        X : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
            
        Returns
        -------
        The (real part of the) tree-level potential at T = Tmin
        """
        return self.VEffThermal(X, self.Tmin, 0, 
                                self.params3DInterpolOptions['interpolate'])

    
    def boson_massSq(self, X, T):
        """
        Overrides the default method in the class generic_potential. 
        
        This method is simply there to override the default method in the
        CosmoTransitions class generic_potential. Potentially it could be
        independently useful, but it is not supposed to be called since the
        effective potential is calculated by other means. Thus, in the current
        implementation, calling the functions simply throws an error.

        Parameters
        ----------
        X : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        T : float or array_like
            The temperature at which to calculate the boson masses. Can be used
            for including thermal mass corrrections. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
        """
        raise NotImplementedError("This method is deliberately not imple"     \
                                  "mented as it should not need to be called "\
                                  "when using this class.")

            
    def fermion_massSq(self, X):
        """
        Overrides the default method in the class generic_potential. 
        
        This method is simply there to override the default method in the
        CosmoTransitions class generic_potential. Potentially it could be
        independently useful, but it is not supposed to be called since the
        effective potential is calculated by other means. Thus, in the current
        implementation, calling the functions simply throws an error.

        Parameters
        ----------
        X : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        """
        raise NotImplementedError("This method is deliberately not imple"     \
                                  "mented as it should not need to be called "\
                                  "when using this class.")

            
    def V1(self, bosons, fermions):
        """
        Overrides the default method in the class generic_potential. 
        
        This method is simply there to override the default method in the
        CosmoTransitions class generic_potential. Potentially it could be
        independently useful, but it is not supposed to be called since the
        effective potential is calculated by other means. Thus, in the current
        implementation, calling the functions simply throws an error.
        """
        raise NotImplementedError("This method is deliberately not imple"     \
                                  "mented as it should not need to be called "\
                                  "when using this class.")


    def V1T(self, bosons, fermions, T, include_radiation=True):
        """
        Overrides the default method in the class generic_potential. 
        
        This method is simply there to override the default method in the
        CosmoTransitions class generic_potential. Potentially it could be
        independently useful, but it is not supposed to be called since the
        effective potential is calculated by other means. Thus, in the current
        implementation, calling the functions simply throws an error.
        """
        raise NotImplementedError("This method is deliberately not imple"     \
                                  "mented as it should not need to be called "\
                                  "when using this class.")
 
            
    def Vtot(self, X, T, include_radiation=True):
        """
        The finite temperature effective potential.
        
        This function overrides the function Vtot in the generic_potential
        class of CosmoTransitions. It returns the *real part only* of the 
        effective potential for the given field values and at the given 
        temperature. More specifically, it returns the real part of T*VEff3D,
        where VEff3D is the 3D effective potential at the given temperature
        and with the field values X3D = X/√T. 
            
        Parameters
        ----------
        X : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
        include_radiation : bool, optional
            NOTE: This is kept for compatibility reasons with CosmoTransitions.
            Setting this parameter to True or False does not change anything.
            
        Returns
        -------
        The (real part of the) effective potential
        """
        # VT = self.VEffThermal(X, T, self.order, 
        #                self.params3DUSInterpolOptions['interpolate'])
        # print("\n\n\n")
        # print("In Vtot:")
        # print("X: {} X.shape: {}".format(X,X.shape))
        # print("VT.shape: ",VT.shape)
        # print("VT: ",VT)
        # print("VT.real:",VT.real)
        # print("real(VT):",np.real(VT))
        # print("")
        return np.real(self.VEffThermal(X, T, self.orderDR, self.orderVEff, 
                       self.params3DUSInterpolOptions['interpolate']))

            
    def VtotComplex(self, X, T):
        """
        The finite temperature effective potential (with imaginary part)
        
        This function calculates the effective potential for the given field 
        values and at the given temperature. The value of the potential is
        returned as a complex number and may have a nonzero imaginary part.
        More specifically, the function returns the value of T*VEff3D, where 
        VEff3D is the 3D effective potential at the given temperature and with
        the field values X3D = X/√T. 
    
        Parameters
        ----------
        X : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
            
        Returns
        -------
        The value of effective potential as a complex number  
        """
        return  self.VEffThermalComplex(X, T, self.orderDR, self.orderVEff, 
                                self.params3DUSInterpolOptions['interpolate'])

            
    def V1T_from_X(self, X, T, include_radiation=True):
        """
        Calculates the temperature dependent part of Vtot.

        This function is overriden for the sake of getting the correct 
        numerical derivatives with respect to temperature in CosmoTransitions.
        In the present context, the effective potential has no temperature-
        independent part, so the function simply returns the same as Vtot.
        
        Parameters
        ----------
        X : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
        include_radiation : bool, optional
            NOTE: This is kept for compatibility reasons with CosmoTransitions.
            Setting this parameter to True or False does not change anything.
            
        Returns
        -------
        The (real part of the) effective potential
        """
        return self.Vtot(X,T,include_radiation)

    
    def getPhases(self, tracingArgs={}):
        """
        Find different phases as functions of temperature.
        
        This function overrides the corresponding function in the 
        generic_potential class, in order to ensure that the starting 
        temperature is at Tmin (possibly nonzero) rather than zero.
    
        Parameters
        ----------
        tracingArgs : dict
            Parameters to pass to :func:`transitionFinder.traceMultiMin`.
    
        Returns
        -------
        dict
            Each item in the returned dictionary is an instance of
            :class:`transitionFinder.Phase`, and each phase is
            identified by a unique key. This value is also stored in
            `self.phases`.
        """
        tstop = self.Tmax
        points = []
        for x0 in self.approxZeroTMin():
            points.append([x0,self.Tmin])
        tracingArgs_ = dict(forbidCrit=self.forbidPhaseCrit)
        tracingArgs_.update(tracingArgs)
        phases = transitionFinder.traceMultiMin(
            self.Vtot, self.dgradV_dT, self.d2V, points,
            tLow=self.Tmin, tHigh=tstop, deltaX_target=100*self.x_eps,
            **tracingArgs_)
        self.phases = phases
        transitionFinder.removeRedundantPhases(
            self.Vtot, phases, self.x_eps*1e-2, self.x_eps*10)
        return self.phases



    # def findAllTransitions(self, tunnelFromPhase_args={}):
    #     """
    #     Find all phase transitions up to `self.Tmax`, storing the transitions
    #     in `self.TnTrans`.
        
    #     This function overrides the function findAllTransitions() in the
    #     generic_potential class. The only change is that the pressure entry
    #     in the transition dictionary is replaced by the pressure calculated
    #     in the dimensional reduction formalism. Note that the default 
    #     CosmoTransitions nucleation criterion S/T - 140 will be used unless
    #     otherwise specified. To use a different nucleation criterion, set
    #     the field 'nuclCriterion' in the tunnelFromPhase_args dictionary.
    
    #     In addition to the values output by
    #     :func:`transitionFinder.tunnelFromPhase`, this function adds
    #     the following entries to each transition dictionary:
    
    #     - *Delta_rho* : Energy difference between the two phases. Positive
    #       values mean the high-T phase has more energy.
    #     - *Delta_p* : Pressure difference between the two phases. Should always
    #       be positive.
    #     - *crit_trans* : The transition at the critical temperature, or None
    #       if no critical temperature can be found.
    #     - *dS_dT* : Derivative of the Euclidean action with respect to
    #       temperature. NOT IMPLEMENTED YET.
    #     - *highTSafety* : Indicates if the transition is safe with respect to
    #       the high temperature expansion, by checking if the expansion is
    #       valid at the low veve and the high vev.
    
    #     Parameters
    #     ----------
    #     tunnelFromPhase_args : dict
    #         Parameters to pass to :func:`transitionFinder.tunnelFromPhase`.
    
    #     Returns
    #     -------
    #     self.TnTrans
    #     """
    #     if self.phases is None:
    #         self.getPhases()
    #     self.TnTrans = transitionFinder.findAllTransitions(
    #         self.phases, self.Vtot, self.gradV, tunnelFromPhase_args)
    #     # Add in the critical temperature
    #     if self.TcTrans is None:
    #         self.calcTcTrans()
    #     transitionFinder.addCritTempsForFullTransitions(
    #         self.phases, self.TcTrans, self.TnTrans)
    #     # Add in Delta_rho, Delta_p
    #     for trans in self.TnTrans:
    #         T = trans['Tnuc']
    #         xlow = trans['low_vev']
    #         xhigh = trans['high_vev']
    #         trans['Delta_rho'] = self.energyDensity(xhigh,T,False) \
    #             - self.energyDensity(xlow,T,False)
    #         #Replace the pressure with the pressure from dimensional reduction.
    #         trans['Delta_p'] =                                                \
    #             self.pressure(T, self.order, 
    #                           self.params3DInterpolOptions['interpolate'])
    #     return self.TnTrans


    def pruneTransitions(self, dXCutoff = None, dRhoCutoff = None):
        """
        Prunes the transition dictionary self.TnTrans. 
        
        This function is used to prune the transitions dictionary self.TnTrans
        in order to remove entries that correspond to "false" transitions or
        irrelevant transitions. By a "false" transition, we mean a transition
        which appears by numerical artefacts, but which does not represent
        a physical transition.
        
        The pruning is done by two checks. First of all, it is checked that 
        the high_ev and the low_vev are not too close to each other, as
        controlled by the parameter dXCutoff. If dXCutoff is None (default),
        it is set equal to self.x_eps. A transition is removed if 
        |high_vev[i]-low_vev[i]| < dXCutoff for *all* components. 
        
        In addition, a transition can be removed if the energy difference 
        between the high_vev and the low_vev is too small, as controlled by
        the parameter dRho. If dRHo is None (default), transitions are not
        pruned with respect to the energy density. If dRho is set, then a
        transition is removed if Delta_rho < dRho.
        
        Parameters
        ----------
        dXCutoff : float, optional
            Cutoff for the smallest acceptable difference between the vevs. 
            If None, the value is set to self.x_eps.
        dRhoCutoff : float, optional
            The cutoff in energy difference below which transitions will be
            removed. Defaults to None, in which case no transitions are
            removed.

        Raises
        ------
        RuntimeError
            A RuntimeError is raised if the transition dictionary has not been
            calculated yet.
        """
        if self.TnTrans is None:
            raise RuntimeError("self.TnTrans has not been set. "
                "Try running self.findAllTransitions() first.")
        if dXCutoff is None:
            dXCutoff = self.x_eps
        elif dXCutoff <= 0:
            raise ValueError("The parameter dXCutoff should be strictly "     \
                             "positive")
        transitions = []
        for trans in self.TnTrans:
            XLow = trans['low_vev']
            XHigh = trans['high_vev']
            keep = True
            if not np.any(np.abs(XLow - XHigh) > dXCutoff):
                keep = False
            if keep and dRhoCutoff is not None:
                if trans['Delta_rho'] < dRhoCutoff:
                    keep = False
            if keep:
                transitions.append(trans)
        self.TnTrans = transitions
        

    def augmentTransitionDictionary(self, deltaMinus = 0.1, deltaPlus = 0.1, 
                                    SMin = 90, SMax = 200, nTVals = 10, 
                                    s = None):
        """
        Add some extra stuff to the transition dictionary self.TnTrans.
        
        This function adds the following entries to the transition dictionary
        self.TnTrans:
            
        - *S_vs_T* : The interpolated action (S3/T) vs. temperature T as an 
          instance of scipy.interpolate.PPoly (set to None if the 
          interpolation fails or if the transition is not 1:st order). 
        - *S_arr* : Array with the values of the action (S3/T) used for the 
          interpolation (set to None if the transition is not 1:st order).
        - *T_arr* : Array with the values of the temperature used for the
          interpolation (set to None if the transition is not 1:st order).
        - *dS_dT* : Derivative of the Euclidean (critical) action with respect
          to temperature (set to None if the interpolation fails or if the
          transition is not 1:st order).
        - *betaH* : The inverse time scale of the phase transition in units of
          the Hubble parameter (set to None if the interpolation fails or if
          the transition is not 1:st order).
        - *alpha_theta* : The phase transitions strength (for reference, see 
          e.g. Phys. Rev. D 96, 103520 (or arXiv:1704.05871 [astro-ph.CO])
        - *high_T_safety* : Indicates if the transition is safe with respect 
          to the high temperature expansion, by checking if the expansion is
          valid at the low vev and the high vev.        
              
        The action S_vs_T is calculated by means of a cubic spline inter-
        polation using scipy.interpolate.splrep and is returned as an instance
        ofscipy.interpolate.PPoly. This interpolation is also used to cal-
        culate the derivative dS_dT at nucleation. There are some optional 
        parameters controlling the interpolation:

        Parameters
        ----------
        deltaMinus : float, optional
            Defines the maximum lower end of the temperature range as 
            (1-deltaMinus)*Tnuc . Defaults to 0.1.
        deltaMinus : float, optional
            Defines the minimum upper end of the temperature range as 
            (1+deltaPlus)*Tnuc . Defaults to 0.1.
        SMin : float, optional
            The lowest value of the action S3/T that can be used for the
            interpolation. Defaults to 80.
        SMax : float, optional
            The highest value of the action S3/T that can be used for the
            interpolation. Defaults to 200.
        nTVals : int, optional
            The number of temperature values that will be used for the 
            interpolation. Defaults to 10.
        s : float, optional
            A smoothing condition. Defaults to None. See further details in 
            the scipy.interpolate.splrep documentation.

        Raises
        ------
        RuntimeError
            A RuntimeError is raised if the transition dictionary has not been
            calculated yet.
        """
        if self.TnTrans is None:
            raise RuntimeError("self.TnTrans has not been set. "
                "Try running self.findAllTransitions() first.")
        if nTVals <= 3:
            raise RuntimeError("The parameter nTVals must be at least 4.")
        def _dVdT(X, T):
            T_eps = self.T_eps
            if self.deriv_order == 2:
                dVdT = self.Vtot(X,T+T_eps)
                dVdT -= self.Vtot(X,T-T_eps)
                dVdT *= 1./(2*T_eps)
            else:
                dVdT = self.Vtot(X,T-2*T_eps)
                dVdT -= 8*self.Vtot(X,T-T_eps)
                dVdT += 8*self.Vtot(X,T+T_eps)
                dVdT -= self.Vtot(X,T+2*T_eps)
                dVdT *= 1./(12*T_eps)
            return dVdT
       
        def _S_vs_T(high_phase, low_phase, Tnuc, Snuc, Tc, deltaMinus, 
                    deltaPlus, SMin, SMax, nTVals, s):
            #We first determine lower and upper limits for the interpolation.
            #Initial ansatz for Tmax
            if Tc is not None:
                TMax = min(Tc-0.05*(Tc-Tnuc), (1+deltaPlus)*Tnuc)
            else:
                TMax = min((1+deltaPlus)*Tnuc, self.phases[high_phase].T[-1], 
                           self.phases[low_phase].T[-1])
                
            #Initial ansatz for Tmin
            TMin = max((1-deltaMinus)*Tnuc, self.phases[high_phase].T[0], 
                       self.phases[low_phase].T[0])
            
            TPlusArr = []
            TMinusArr = []
            SPlusArr = []
            SMinusArr = []
            TPlus = Tnuc
            TMinus = Tnuc
            
            def _S(T):
                V = lambda x: self.Vtot(x, T)
                dV = lambda x: self.gradV(x, T)
                x_high = self.phases[high_phase].valAt(T)
                x_low = self.phases[low_phase].valAt(T)
                S3 = pathDeformation.fullTunneling(np.array([x_low,x_high]),
                                                   V, dV).action
                return S3/T                
            
            for i in range(0,int(nTVals/2)):
                dTPlus = (TMax-TPlus)/(int(nTVals/2) - len(TPlusArr))
                try:
                    S = _S(TPlus + dTPlus)
                    if S <= SMax:    
                        TPlus = TPlus + dTPlus
                        TPlusArr.append(TPlus)
                        SPlusArr.append(S)
                    else:
                        TMax = TPlus + dTPlus
                except:
                    TMax = TPlus + dTPlus
                    
            for i in range(0,int(nTVals/2)):
                dTMinus = (TMinus-TMin)/(int(nTVals/2) - len(TMinusArr))
                try:
                    S = _S(TMinus - dTMinus)                    
                    if S >= SMin:    
                        TMinus = TMinus - dTMinus
                        TMinusArr.append(TMinus)
                        SMinusArr.append(S)
                    else:
                        TMin = TMinus - dTMinus
                except:
                    TMin = TMinus - dTMinus
            
            #Dubious to interpolate in this case.
            if len(TPlusArr) == 0 or len(TMinusArr) == 0: 
                TArr = np.concatenate((TMinusArr[::-1],[Tnuc],TPlusArr))
                SArr = np.concatenate((SMinusArr[::-1],[Snuc],SPlusArr))
                return None, np.array(TArr), np.array(SArr)
            
            #Make sure that we have the right number of points.
            nRem = nTVals-len(TPlusArr)-len(TMinusArr)-1
            if  nRem > 0:
                TInsMinusArr = np.linspace(TMinusArr[0],Tnuc,
                                           int(nRem/2)+2)[1:-1]
                SInsMinusArr = [_S(T) for T in TInsMinusArr]
                TInsPlusArr = np.linspace(Tnuc,TPlusArr[0],
                                          nRem-int(nRem/2)+2)[1:-1] 
                SInsPlusArr = [_S(T) for T in TInsPlusArr]
                TArr = np.concatenate((TMinusArr[::-1],TInsMinusArr,[Tnuc],
                                       TInsPlusArr,TPlusArr))
                SArr = np.concatenate((SMinusArr[::-1],SInsMinusArr,[Snuc],
                                       SInsPlusArr,SPlusArr))

            print("")
            tck, fp, ier, msg = splrep(TArr, SArr, k = 3, s = s,
                                       full_output = True)
            
            if ier <= 0: #success
                return PPoly.from_spline(tck), SArr, TArr
            else:
                return None, SArr, TArr

        for trans in self.TnTrans:
            XLow = trans['low_vev']
            XHigh = trans['high_vev']
            Tnuc = trans['Tnuc']
            if trans['trantype'] == 1:
                if 'Tcrit' in trans:
                    Tc = trans['Tcrit']
                else:
                    Tc = None
                
                #Calculate S_vs_T and dS_dT
                Snuc = trans['action']/Tnuc
                S_vs_T, SArr, TArr = _S_vs_T(trans['high_phase'], 
                                             trans['low_phase'], Tnuc, Snuc,
                                             Tc, deltaMinus, deltaPlus, SMin,
                                             SMax, nTVals, s = 0)
                trans['S_vs_T'] = S_vs_T
                trans['S_arr'] = SArr
                trans['T_arr'] = TArr
                if trans['S_vs_T'] is not None:
                    trans['dS_dT'] = trans['S_vs_T'](Tnuc, nu = 1)
                else:
                    trans['dS_dT'] = None
                   
                #Calculate betaH
                if trans['dS_dT'] is not None:
                    trans['betaH'] = Tnuc * trans['dS_dT']
                else:
                    trans['betaH'] = None
            else:
                trans['S_vs_T'] = None
                trans['S_arr'] = None
                trans['T_arr'] = None
                trans['dS_dT'] = None
                trans['betaH'] = None
                
            #Calculate alpha
            Vi = self.Vtot(XHigh, Tnuc)
            dVidT = _dVdT(XHigh, Tnuc)
            Vf = self.Vtot(XLow, Tnuc)
            dVfdT = _dVdT(XLow, Tnuc)
            gEff = self.gEff(Tnuc)
            rhoBath = gEff * np.pi**2 * Tnuc**4 / 30
            trans['alpha_theta'] = (Vi-Vf - Tnuc*(dVidT-dVfdT)/4) / rhoBath
            
            #Check high temperature expansion at the vevs.
            #interpolate = self.params3DUSInterpolOptions['interpolate']
            #
            #print("XLow: ",XLow)
            #print("Tnuc: ",Tnuc)
            #print("self.orderDR: ",self.orderDR)
            #print("interpolate: ",interpolate)
            #print("safety: ", self.highTOptions['safetyFactor'])
            #
            #XLowOK =                                                          \
            #    self.checkHighTSafety4D(XLow, Tnuc, self.orderDR, interpolate,
            #                            self.highTOptions['safetyFactor'])
            #XHighOK =                                                         \
            #    self.checkHighTSafety4D(XHigh, Tnuc, self.orderDR, interpolate,
            #                            self.highTOptions['safetyFactor'])            
            #trans['high_T_safety'] = XLowOK and XHighOK
                            
                
    def prettyPrintTnTrans(self):
        """
        Prints the contents of the transition dictionary self.TnTrans.
        
        This function is used to the print the contents of the transition
        dictionary self.TnTrans. It overrides the default CosmoTransitions
        function to add the entries from augmentTransitionDictionary (if
        they are set).
        
        Raises
        ------
        RuntimeError
            A RuntimeError is raised if the transition dictionary has not been
            calculated yet.
        """
        if self.TnTrans is None:
            raise RuntimeError("self.TnTrans has not been set. "
                "Try running self.findAllTransitions() first.")
        if len(self.TnTrans) == 0:
            print("No transitions for this potential.\n")
        augmented = False
        if len(self.TnTrans) > 0 and 'dS_dT' in self.TnTrans[0]:
            augmented = True
        for trans in self.TnTrans:
            trantype = trans['trantype']
            if trantype == 1:
                trantype = 'First'
            elif trantype == 2:
                trantype = 'Second'
            print("%s-order transition at Tnuc = %0.4g" %
                  (trantype, trans['Tnuc']))
            print("High-T phase:\n  key = %s; vev = %s" %
                  (trans['high_phase'], trans['high_vev']))
            print("Low-T phase:\n  key = %s; vev = %s" %
                  (trans['low_phase'], trans['low_vev']))
            print("Pressure difference = %0.4g = (%0.4g)^4" %
                  (trans['Delta_p'], trans['Delta_p']**.25))
            print("Energy difference = %0.4g = (%0.4g)^4" %
                  (trans['Delta_rho'], trans['Delta_rho']**.25))
            print("Action = %0.4g" % trans['action'])
            print("Action / Tnuc = %0.6g" % (trans['action']/trans['Tnuc']))
            if augmented:
                if trans['dS_dT'] is not None:
                    print("dS_dT = %0.4g" % trans['dS_dT'])
                    #print("high_T_safety = %s" % trans['high_T_safety'])
                    print("alpha_theta = %0.4g" % trans['alpha_theta'])
                    print("betaH = Tnuc*dS/dT = %0.4g" % trans['betaH'])
                else:
                    print("dS_dT = ", None)
                    #print("high_T_safety = %s" % trans['high_T_safety'])
                    print("alpha_theta = %0.4g" % trans['alpha_theta'])
                    print("betaH = Tnuc*dS/dT = ", None)
            print("")
            
            
    def gEff(self, T):
        """
        The effective number of degrees of freedom vs. temperature.
        
        This function should return the effective number of degrees of 
        freedom as a function of temperature for the model. The default
        implementation simply returns 106.75, which is OK for phase
        transitions near the electroweak scale. For phase transitions far
        away from this scale, this value may not be accurate.

        Parameters
        ----------
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).

        Returns
        -------
        The effective number of degrees of freedom.
        """
        return 106.75*np.ones(np.asarray(T).shape)
    
    
    def forbidPhaseCrit(self, X):
        """
        Returns True if a phase at point `X` should be discarded,
        False otherwise.

        The default implementation checks if the field point X is within the
        bound set by X4DMax in self.highTOptions, provided that enforceX4DMax 
        is set to True in the same dictionary. If a more elaborate imple-
        mentation is desired in a concrete subclass, the below code can simply
        be copied, or call generic_potential_DR.forbidPhaseCrit(self, X) in 
        the code.
        """
        # ret = np.any(np.abs(X) > self.XMax)
        # if self.highTOptions['enforceX4DMax']:
        #     return ret or np.any(np.abs(X) > self.highTOptions['X4DMax'])
        # else:
        #     return ret
        return False

                        
