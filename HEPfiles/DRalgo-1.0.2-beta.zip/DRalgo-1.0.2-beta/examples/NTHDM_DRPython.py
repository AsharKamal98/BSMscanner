from generic_potential_DR_class_based import generic_potential_DR
from numpy import array, sqrt, log, exp, pi
from numpy import asarray, zeros, ones, concatenate, empty
from numpy.linalg import eigh, eigvalsh
from modelDR_class_based import Lb as LbFunc
from modelDR_class_based import Lf as LfFunc
from modelDR_class_based import EulerGamma
from modelDR_class_based import Glaisher
import numpy as np

#This is the number of field dimensions (the Ndim parameter):
nVevs = 3

#No auxParams for this model.


class NTHDM(generic_potential_DR):
    """
    Insert class description here.
    """

    def RGFuncs4D(self, mu4D, params4D, *auxParams):
        """
        Returns the RHS of the RG-equation dp/dμ4D = β(p)/μ4D.
        
        This function returns an array_like object with the β-functions for
        the 4D-parameters divided by the RG-scale μ4D, i.e. the right-hand
        side in the RG-equation dp/dμ4D = β(p)/μ4D, where p denotes the array
        of 4D-parameters.
        
        Parameters
        ----------
        mu4D : float
            The 4D RG-scale parameter (i.e. μ4D) 
        params4D : array
            Array of the 4D-parameters at scale μ4D
        auxParams : tuple
            Tuple of auxiliary parameters
        
        Returns
        -------
        RHS of the RG-equation dp/dμ4D = β(p)/μ4D as an array
        """
        μ4D = mu4D
        
        gwsq, gYsq, gssq, λ1H, λ2H, λ3H, λ4H, λ5H, λ6H, λ7H, a123, yt1, m11, m12, m22, m33, mb = params4D
        
        
        βgwsq = (-3*gwsq**2)/(8.*pi**2)
        βgYsq = (7*gYsq**2)/(8.*pi**2)
        βgssq = (-7*gssq**2)/(8.*pi**2)
        βλ1H = (9*gwsq**2 + 3*gYsq**2 + 6*gwsq*(gYsq - 12*λ1H) - 24*gYsq*λ1H + 8*(24*λ1H**2 + 2*λ3H**2 + 2*λ3H*λ4H + λ4H**2 + λ6H**2))/(128.*pi**2)
        βλ2H = (9*gwsq**2 + 6*gwsq*(gYsq - 12*λ2H) + 3*(gYsq**2 - 8*gYsq*λ2H + 32*λ2H*(yt1**2 + 2*λ2H)) + 8*(-6*yt1**4 + 2*λ3H**2 + 2*λ3H*λ4H + λ4H**2 + λ7H**2))/(128.*pi**2)
        βλ3H = (9*gwsq**2 + 3*gYsq**2 - 12*gYsq*λ3H - 6*gwsq*(gYsq + 6*λ3H) + 8*(λ3H*(3*yt1**2 + 6*(λ1H + λ2H) + 2*λ3H) + 2*(λ1H + λ2H)*λ4H + λ4H**2 + λ6H*λ7H))/(64.*pi**2)
        βλ4H = (3*gwsq*(gYsq - 3*λ4H) + λ4H*(-3*gYsq + 6*yt1**2 + 4*(λ1H + λ2H + 2*λ3H + λ4H)))/(16.*pi**2)
        βλ5H = (5*λ5H**2 + 2*(λ6H**2 + λ7H**2))/(8.*pi**2)
        βλ6H = (-9*gwsq*λ6H - 3*gYsq*λ6H + 8*λ6H*(3*λ1H + λ5H + λ6H) + 4*(2*λ3H + λ4H)*λ7H)/(32.*pi**2)
        βλ7H = (8*λ3H*λ6H + 4*λ4H*λ6H + λ7H*(-9*gwsq - 3*gYsq + 12*yt1**2 + 8*(3*λ2H + λ5H + λ7H)))/(32.*pi**2)
        βa123 = (a123*(-9*gwsq - 3*gYsq + 6*yt1**2 + 4*(λ3H + 2*λ4H + λ6H + λ7H)))/(32.*pi**2)
        βyt1 = (yt1*(-96*gssq - 27*gwsq - 17*gYsq + 54*yt1**2))/(192.*pi**2)
        βm11 = (4*a123**2 - 3*m11*(3*gwsq + gYsq - 8*λ1H) + 4*m22*(2*λ3H + λ4H) + 4*m33*λ6H)/(32.*pi**2)
        βm12 = (m12*(-9*gwsq - 3*gYsq + 6*yt1**2 + 4*λ3H + 8*λ4H))/(32.*pi**2)
        βm22 = (4*a123**2 - 3*m22*(3*gwsq + gYsq - 4*yt1**2 - 8*λ2H) + 4*m11*(2*λ3H + λ4H) + 4*m33*λ7H)/(32.*pi**2)
        βm33 = (a123**2 + m33*λ5H + m11*λ6H + m22*λ7H)/(4.*pi**2)
        βmb = (mb*λ5H)/(8.*pi**2)
        
        return array([βgwsq, βgYsq, βgssq, βλ1H, βλ2H, βλ3H, βλ4H, βλ5H, βλ6H, βλ7H, βa123, βyt1, βm11, βm12, βm22, βm33, βmb])/μ4D
        

    def DebyeMassSq(self, T, mu4DH, params4D, order, *auxParams):
        """
        Returns the squared Debye masses.
        
        This function is used to calculate the squared Debye masses as a
        function of the temperature T, the hard matching scale mu4DH (μ4DH)
        and the values of the 4D-parameters at scale μ4DH. The masses can be
        calculated at LO or NLO (order = 0 and 1, respectively).
        
        Parameters
        ----------
        T : float
            The temperature
        mu4DH : float
            The hard matching scale (i.e. μ4DH)
        params4D : array
            Array of the 4D-parameters at scale μ4DH
        order : int
            The order at which the Debye masses are calculated (0 or 1)
        auxParams : tuple
            Tuple of auxiliary parameters
        
        Returns
        -------
        The squared Debye masses as an array
        """
        Lb = LbFunc(mu4DH,T)
        Lf = LfFunc(mu4DH,T)
        
        gwsq, gYsq, gssq, λ1H, λ2H, λ3H, λ4H, λ5H, λ6H, λ7H, a123, yt1, m11, m12, m22, m33, mb = params4D
        
        
        if order == 0:
            μsqSU2 = 2*gwsq*T**2
            μsqSU3 = 2*gssq*T**2
            μsqU1 = 2*gYsq*T**2
        elif order == 1:
            μsqSU2 = 2*gwsq*T**2 + (gwsq*(24*m11 + 24*m22 + T**2*(-72*gssq - 3*gYsq + gwsq*(115 + 168*Lb - 96*Lf) - 3*yt1**2 + 12*λ1H + 12*λ2H + 8*λ3H + 4*λ4H + 2*λ6H + 2*λ7H)))/(192.*pi**2)
            μsqSU3 = 2*gssq*T**2 + (gssq*T**2*(-27*gwsq - 11*gYsq + 24*gssq*(5 + 11*Lb - 4*Lf) - 12*yt1**2))/(192.*pi**2)
            μsqU1 = 2*gYsq*T**2 + (gYsq*(144*m11 + 144*m22 + T**2*(-528*gssq - 54*gwsq + gYsq*(502 - 48*Lb - 960*Lf) - 66*yt1**2 + 12*(6*λ1H + 6*λ2H + 4*λ3H + 2*λ4H + λ6H + λ7H))))/(1152.*pi**2)
        
        return array([μsqSU2, μsqSU3, μsqU1])
        

    def DRStep(self, T, mu4DH, mu3DS, params4D, order, *auxParams):
        """
        Returns the 3D-parameters in the ultrasoft limit.
        
        This function is used to perform the dimensional reduction to the
        ultrasoft limit. Thus, it calculates the values of the 3D parameters
        in the ultrasoft limit as a function of the temperature T, the hard
        matching scale mu4DH (μ4DH), the hard-to-soft matching scale mu3DS
        (μ3DS) and the values of the 4D-parameters at scale μ4DH.
        
        Parameters
        ----------
        T : float
            The temperature
        mu4DH : float
            The hard matching scale (i.e. μ4DH)
        mu3DS : float
            The hard-to-soft matching scale (i.e. μ3DS)
        params4D : array
            Array of the 4D-parameters at scale μ4DH
        order : int
            The order at which the dimensional reduction is performed (0 or 1)
        auxParams : tuple
            Tuple of auxiliary parameters
        
        Returns
        -------
        Array of the 3D parameters in the ultrasoft limit
        """
        μ = mu4DH
        μ3 = mu3DS
        μ3US = mu3DS #Temporary fix due to error in DRalgo notation
        Lb = LbFunc(mu4DH,T)
        Lf = LfFunc(mu4DH,T)
        
        gwsq, gYsq, gssq, λ1H, λ2H, λ3H, λ4H, λ5H, λ6H, λ7H, a123, yt1, m11, m12, m22, m33, mb = params4D
        
        
        #The couplings in the soft limit:
        gwsq3DS = gwsq*T + (gwsq**2*(2 + 21*Lb - 12*Lf)*T)/(48.*pi**2)
        gYsq3DS = gYsq*T - (gYsq**2*(Lb + 20*Lf)*T)/(48.*pi**2)
        gssq3DS = gssq*T + (gssq**2*(1 + 11*Lb - 4*Lf)*T)/(16.*pi**2)
        λ1H3DS = (T*((3*gwsq**2 + 2*gwsq*gYsq + gYsq**2)*(2 - 3*Lb) + 24*(3*gwsq + gYsq)*Lb*λ1H + 256*pi**2*λ1H - 8*Lb*(24*λ1H**2 + λ3H**2 + (λ3H + λ4H)**2 + λ6H**2)))/(256.*pi**2)
        λ2H3DS = (T*((3*gwsq**2 + 2*gwsq*gYsq + gYsq**2)*(2 - 3*Lb) + 48*Lf*yt1**4 + 256*pi**2*λ2H + 24*(3*gwsq*Lb + gYsq*Lb - 4*Lf*yt1**2)*λ2H - 8*Lb*(24*λ2H**2 + λ3H**2 + (λ3H + λ4H)**2 + λ7H**2)))/(256.*pi**2)
        λ3H3DS = -0.0078125*(T*(gYsq**2*(-2 + 3*Lb) + gwsq**2*(-6 + 9*Lb) - 12*gYsq*Lb*λ3H + gwsq*(gYsq*(4 - 6*Lb) - 36*Lb*λ3H) + 8*(-16*pi**2*λ3H + 3*Lf*yt1**2*λ3H + Lb*(2*λ3H*(3*(λ1H + λ2H) + λ3H) + 2*(λ1H + λ2H)*λ4H + λ4H**2 + λ6H*λ7H))))/pi**2
        λ4H3DS = (T*(gwsq*(gYsq*(2 - 3*Lb) + 9*Lb*λ4H) - λ4H*(-3*gYsq*Lb - 32*pi**2 + 6*Lf*yt1**2 + 4*Lb*(λ1H + λ2H + 2*λ3H + λ4H))))/(32.*pi**2)
        λ5H3DS = T*(λ5H - (Lb*(5*λ5H**2 + 2*(λ6H**2 + λ7H**2)))/(16.*pi**2))
        λ6H3DS = (T*λ6H*(9*gwsq*Lb + 3*gYsq*Lb + 64*pi**2 - 8*Lb*(3*λ1H + λ5H + λ6H)) - 4*Lb*T*(2*λ3H + λ4H)*λ7H)/(64.*pi**2)
        λ7H3DS = -0.015625*(T*(-64*pi**2*λ7H + 12*Lf*yt1**2*λ7H + Lb*(8*λ3H*λ6H + 4*λ4H*λ6H + λ7H*(-9*gwsq - 3*gYsq + 8*(3*λ2H + λ5H + λ7H)))))/pi**2
        a1233DS = (a123*sqrt(T)*(9*gwsq*Lb + 3*gYsq*Lb + 64*pi**2 - 6*Lf*yt1**2 - 4*Lb*(λ3H + 2*λ4H + λ6H + λ7H)))/(64.*pi**2)
        
        #The temporal scalar couplings:
        λVLL1 = (gssq**2*T)/(4.*pi**2)
        λVLL2 = (-3*gssq*gwsq*T)/(4.*pi**2)
        λVLL3 = (gwsq**2*T)/(4.*pi**2)
        λVLL4 = -0.25*(gssq**1.5*sqrt(gYsq)*T)/pi**2
        λVLL5 = (-11*gssq*gYsq*T)/(12.*pi**2)
        λVLL6 = -0.25*(gwsq*gYsq*T)/pi**2
        λVLL7 = (-181*gYsq**2*T)/(36.*pi**2)
        λVL1 = -0.25*(gssq*T*yt1**2)/pi**2
        λVL2 = (sqrt(gwsq)*sqrt(gYsq)*T*(gwsq*(5 + 21*Lb - 12*Lf) - gYsq*(-21 + Lb + 20*Lf) + 12*(8*pi**2 + 2*λ1H + λ4H)))/(192.*pi**2)
        λVL3 = (sqrt(gwsq)*sqrt(gYsq)*T*(gwsq*(5 + 21*Lb - 12*Lf) - gYsq*(-21 + Lb + 20*Lf) + 12*(8*pi**2 + yt1**2 + 2*λ2H + λ4H)))/(192.*pi**2)
        λVL4 = -0.005208333333333333*(gYsq*T*(-9*gwsq + gYsq*(-39 + 2*Lb + 40*Lf) - 12*(8*pi**2 + 6*λ1H + 2*λ3H + λ4H)))/pi**2
        λVL5 = -0.005208333333333333*(gYsq*T*(-9*gwsq + gYsq*(-39 + 2*Lb + 40*Lf) - 96*pi**2 + 68*yt1**2 - 12*(6*λ2H + 2*λ3H + λ4H)))/pi**2
        λVL6 = (gwsq*T*(gwsq*(73 + 42*Lb - 24*Lf) + 3*(gYsq + 4*(8*pi**2 + 6*λ1H + 2*λ3H + λ4H))))/(192.*pi**2)
        λVL7 = (gwsq*T*(gwsq*(73 + 42*Lb - 24*Lf) + 3*(gYsq + 4*(8*pi**2 - 3*yt1**2 + 6*λ2H + 2*λ3H + λ4H))))/(192.*pi**2)
        λVL8 = (gwsq*T*(λ6H + λ7H))/(8.*pi**2)
        λVL9 = (gYsq*T*(λ6H + λ7H))/(8.*pi**2)
        
        #The Debye masses:
        if order == 0:
            μsqSU2 = 2*gwsq*T**2
            μsqSU3 = 2*gssq*T**2
            μsqU1 = 2*gYsq*T**2
        elif order == 1:
            μsqSU2 = 2*gwsq*T**2 + (gwsq*(24*m11 + 24*m22 + T**2*(-72*gssq - 3*gYsq + gwsq*(115 + 168*Lb - 96*Lf) - 3*yt1**2 + 12*λ1H + 12*λ2H + 8*λ3H + 4*λ4H + 2*λ6H + 2*λ7H)))/(192.*pi**2)
            μsqSU3 = 2*gssq*T**2 + (gssq*T**2*(-27*gwsq - 11*gYsq + 24*gssq*(5 + 11*Lb - 4*Lf) - 12*yt1**2))/(192.*pi**2)
            μsqU1 = 2*gYsq*T**2 + (gYsq*(144*m11 + 144*m22 + T**2*(-528*gssq - 54*gwsq + gYsq*(502 - 48*Lb - 960*Lf) - 66*yt1**2 + 12*(6*λ1H + 6*λ2H + 4*λ3H + 2*λ4H + λ6H + λ7H))))/(1152.*pi**2)
        
        #The scalar masses in the soft limit:
        if order == 0:
            m113DS = m11 + (T**2*(9*gwsq + 3*gYsq + 4*(6*λ1H + 2*λ3H + λ4H + λ6H)))/48.
            m123DS = m12
            m223DS = m22 + (T**2*(9*gwsq + 3*gYsq + 4*(3*yt1**2 + 6*λ2H + 2*λ3H + λ4H + λ7H)))/48.
            m333DS = m33 + (T**2*(λ5H + λ6H + λ7H))/6.
            mb3DS = mb
        elif order == 1:
            m113DS = m11 + (T**2*(9*gwsq + 3*gYsq + 4*(6*λ1H + 2*λ3H + λ4H + λ6H)))/48. - (96*a123**2*Lb - 216*gwsq*Lb*m11 - 72*gYsq*Lb*m11 - 201*gwsq**2*T**2 - 225*EulerGamma*gwsq**2*T**2 + 18*gwsq*gYsq*T**2 + 90*EulerGamma*gwsq*gYsq*T**2 - 17*gYsq**2*T**2 + 27*EulerGamma*gYsq**2*T**2 + 252*gwsq**2*Lb*T**2 - 72*gwsq*gYsq*Lb*T**2 + 50*gYsq**2*Lb*T**2 - 36*gwsq**2*Lf*T**2 - 20*gYsq**2*Lf*T**2 + 576*Lb*m11*λ1H - 72*gwsq*T**2*λ1H - 432*EulerGamma*gwsq*T**2*λ1H - 24*gYsq*T**2*λ1H - 144*EulerGamma*gYsq*T**2*λ1H + 216*gwsq*Lb*T**2*λ1H + 72*gYsq*Lb*T**2*λ1H + 576*EulerGamma*T**2*λ1H**2 + 192*Lb*m22*λ3H - 24*gwsq*T**2*λ3H - 144*EulerGamma*gwsq*T**2*λ3H - 8*gYsq*T**2*λ3H - 48*EulerGamma*gYsq*T**2*λ3H + 72*gwsq*Lb*T**2*λ3H + 24*gYsq*Lb*T**2*λ3H + 72*Lb*T**2*yt1**2*λ3H - 24*Lf*T**2*yt1**2*λ3H + 96*Lb*T**2*λ1H*λ3H + 96*Lb*T**2*λ2H*λ3H + 96*EulerGamma*T**2*λ3H**2 - 16*Lb*T**2*λ3H**2 + 96*Lb*m22*λ4H - 12*gwsq*T**2*λ4H - 72*EulerGamma*gwsq*T**2*λ4H - 4*gYsq*T**2*λ4H - 24*EulerGamma*gYsq*T**2*λ4H + 36*gwsq*Lb*T**2*λ4H + 12*gYsq*Lb*T**2*λ4H + 36*Lb*T**2*yt1**2*λ4H - 12*Lf*T**2*yt1**2*λ4H + 48*Lb*T**2*λ1H*λ4H + 48*Lb*T**2*λ2H*λ4H + 96*EulerGamma*T**2*λ3H*λ4H - 16*Lb*T**2*λ3H*λ4H + 96*EulerGamma*T**2*λ4H**2 - 40*Lb*T**2*λ4H**2 + 96*Lb*m33*λ6H - 18*gwsq*Lb*T**2*λ6H - 6*gYsq*Lb*T**2*λ6H + 48*Lb*T**2*λ1H*λ6H + 16*Lb*T**2*λ5H*λ6H + 48*EulerGamma*T**2*λ6H**2 - 8*Lb*T**2*λ6H**2 + 16*Lb*T**2*λ3H*λ7H + 8*Lb*T**2*λ4H*λ7H + 16*Lb*T**2*λ6H*λ7H + 2700*gwsq**2*T**2*log(Glaisher) - 1080*gwsq*gYsq*T**2*log(Glaisher) - 324*gYsq**2*T**2*log(Glaisher) + 5184*gwsq*T**2*λ1H*log(Glaisher) + 1728*gYsq*T**2*λ1H*log(Glaisher) - 6912*T**2*λ1H**2*log(Glaisher) + 1728*gwsq*T**2*λ3H*log(Glaisher) + 576*gYsq*T**2*λ3H*log(Glaisher) - 1152*T**2*λ3H**2*log(Glaisher) + 864*gwsq*T**2*λ4H*log(Glaisher) + 288*gYsq*T**2*λ4H*log(Glaisher) - 1152*T**2*λ3H*λ4H*log(Glaisher) - 1152*T**2*λ4H**2*log(Glaisher) - 576*T**2*λ6H**2*log(Glaisher) + 6*(33*gwsq3DS**2 - 7*gYsq3DS**2 + 8*gYsq3DS*(6*λ1H3DS + 2*λ3H3DS + λ4H3DS) - 8*(24*λ1H3DS**2 + 4*λ3H3DS**2 + 4*λ3H3DS*λ4H3DS + 4*λ4H3DS**2 + 2*λ6H3DS**2 + 6*λVL2**2 + λVL4**2 + 3*λVL6**2) + 6*gwsq3DS*(-3*gYsq3DS + 4*(6*λ1H3DS + 2*λ3H3DS + λ4H3DS + 4*λVL6)))*log(μ3/μ))/(1536.*pi**2)
            m123DS = m12 + (m12*(9*gwsq*Lb + 3*gYsq*Lb - 6*Lf*yt1**2 - 4*Lb*λ3H - 8*Lb*λ4H))/(64.*pi**2)
            m223DS = m22 + (T**2*(9*gwsq + 3*gYsq + 4*(3*yt1**2 + 6*λ2H + 2*λ3H + λ4H + λ7H)))/48. - (288*a123**2*Lb - 648*gwsq*Lb*m22 - 216*gYsq*Lb*m22 - 603*gwsq**2*T**2 - 675*EulerGamma*gwsq**2*T**2 + 54*gwsq*gYsq*T**2 + 270*EulerGamma*gwsq*gYsq*T**2 - 51*gYsq**2*T**2 + 81*EulerGamma*gYsq**2*T**2 + 756*gwsq**2*Lb*T**2 - 216*gwsq*gYsq*Lb*T**2 + 150*gYsq**2*Lb*T**2 - 108*gwsq**2*Lf*T**2 - 60*gYsq**2*Lf*T**2 + 864*Lf*m22*yt1**2 + 576*gssq*T**2*yt1**2 + 54*gwsq*T**2*yt1**2 + 66*gYsq*T**2*yt1**2 + 192*gssq*Lb*T**2*yt1**2 - 189*gwsq*Lb*T**2*yt1**2 - 47*gYsq*Lb*T**2*yt1**2 - 768*gssq*Lf*T**2*yt1**2 + 27*gwsq*Lf*T**2*yt1**2 - 55*gYsq*Lf*T**2*yt1**2 - 108*Lb*T**2*yt1**4 + 1728*Lb*m22*λ2H - 216*gwsq*T**2*λ2H - 1296*EulerGamma*gwsq*T**2*λ2H - 72*gYsq*T**2*λ2H - 432*EulerGamma*gYsq*T**2*λ2H + 648*gwsq*Lb*T**2*λ2H + 216*gYsq*Lb*T**2*λ2H + 648*Lb*T**2*yt1**2*λ2H + 216*Lf*T**2*yt1**2*λ2H + 1728*EulerGamma*T**2*λ2H**2 + 576*Lb*m11*λ3H - 72*gwsq*T**2*λ3H - 432*EulerGamma*gwsq*T**2*λ3H - 24*gYsq*T**2*λ3H - 144*EulerGamma*gYsq*T**2*λ3H + 216*gwsq*Lb*T**2*λ3H + 72*gYsq*Lb*T**2*λ3H + 144*Lf*T**2*yt1**2*λ3H + 288*Lb*T**2*λ1H*λ3H + 288*Lb*T**2*λ2H*λ3H + 288*EulerGamma*T**2*λ3H**2 - 48*Lb*T**2*λ3H**2 + 288*Lb*m11*λ4H - 36*gwsq*T**2*λ4H - 216*EulerGamma*gwsq*T**2*λ4H - 12*gYsq*T**2*λ4H - 72*EulerGamma*gYsq*T**2*λ4H + 108*gwsq*Lb*T**2*λ4H + 36*gYsq*Lb*T**2*λ4H + 72*Lf*T**2*yt1**2*λ4H + 144*Lb*T**2*λ1H*λ4H + 144*Lb*T**2*λ2H*λ4H + 288*EulerGamma*T**2*λ3H*λ4H - 48*Lb*T**2*λ3H*λ4H + 288*EulerGamma*T**2*λ4H**2 - 120*Lb*T**2*λ4H**2 + 48*Lb*T**2*λ3H*λ6H + 24*Lb*T**2*λ4H*λ6H + 288*Lb*m33*λ7H - 54*gwsq*Lb*T**2*λ7H - 18*gYsq*Lb*T**2*λ7H + 72*Lf*T**2*yt1**2*λ7H + 144*Lb*T**2*λ2H*λ7H + 48*Lb*T**2*λ5H*λ7H + 48*Lb*T**2*λ6H*λ7H + 144*EulerGamma*T**2*λ7H**2 - 24*Lb*T**2*λ7H**2 + 8100*gwsq**2*T**2*log(Glaisher) - 3240*gwsq*gYsq*T**2*log(Glaisher) - 972*gYsq**2*T**2*log(Glaisher) + 15552*gwsq*T**2*λ2H*log(Glaisher) + 5184*gYsq*T**2*λ2H*log(Glaisher) - 20736*T**2*λ2H**2*log(Glaisher) + 5184*gwsq*T**2*λ3H*log(Glaisher) + 1728*gYsq*T**2*λ3H*log(Glaisher) - 3456*T**2*λ3H**2*log(Glaisher) + 2592*gwsq*T**2*λ4H*log(Glaisher) + 864*gYsq*T**2*λ4H*log(Glaisher) - 3456*T**2*λ3H*λ4H*log(Glaisher) - 3456*T**2*λ4H**2*log(Glaisher) - 1728*T**2*λ7H**2*log(Glaisher) + 18*(33*gwsq3DS**2 - 7*gYsq3DS**2 + 8*gYsq3DS*(6*λ2H3DS + 2*λ3H3DS + λ4H3DS) - 8*(24*λ2H3DS**2 + 4*λ3H3DS**2 + 4*λ3H3DS*λ4H3DS + 4*λ4H3DS**2 + 2*λ7H3DS**2 - 48*gssq3DS*λVL1 + 8*λVL1**2 + 6*λVL3**2 + λVL5**2 + 3*λVL7**2) + 6*gwsq3DS*(-3*gYsq3DS + 4*(6*λ2H3DS + 2*λ3H3DS + λ4H3DS + 4*λVL7)))*log(μ3/μ))/(4608.*pi**2)
            m333DS = m33 + (T**2*(λ5H + λ6H + λ7H))/6. - (48*a123**2*Lb + 48*Lb*m33*λ5H + 24*EulerGamma*T**2*λ5H**2 - 4*Lb*T**2*λ5H**2 + 48*Lb*m11*λ6H - 6*gwsq*T**2*λ6H - 36*EulerGamma*gwsq*T**2*λ6H - 2*gYsq*T**2*λ6H - 12*EulerGamma*gYsq*T**2*λ6H + 27*gwsq*Lb*T**2*λ6H + 9*gYsq*Lb*T**2*λ6H + 24*Lb*T**2*λ1H*λ6H + 8*Lb*T**2*λ3H*λ6H + 4*Lb*T**2*λ4H*λ6H + 8*Lb*T**2*λ5H*λ6H + 24*EulerGamma*T**2*λ6H**2 - 8*Lb*T**2*λ6H**2 + 48*Lb*m22*λ7H - 6*gwsq*T**2*λ7H - 36*EulerGamma*gwsq*T**2*λ7H - 2*gYsq*T**2*λ7H - 12*EulerGamma*gYsq*T**2*λ7H + 27*gwsq*Lb*T**2*λ7H + 9*gYsq*Lb*T**2*λ7H + 18*Lb*T**2*yt1**2*λ7H - 6*Lf*T**2*yt1**2*λ7H + 24*Lb*T**2*λ2H*λ7H + 8*Lb*T**2*λ3H*λ7H + 4*Lb*T**2*λ4H*λ7H + 8*Lb*T**2*λ5H*λ7H + 24*EulerGamma*T**2*λ7H**2 - 8*Lb*T**2*λ7H**2 - 288*T**2*λ5H**2*log(Glaisher) + 432*gwsq*T**2*λ6H*log(Glaisher) + 144*gYsq*T**2*λ6H*log(Glaisher) - 288*T**2*λ6H**2*log(Glaisher) + 432*gwsq*T**2*λ7H*log(Glaisher) + 144*gYsq*T**2*λ7H*log(Glaisher) - 288*T**2*λ7H**2*log(Glaisher) - 12*(4*λ5H3DS**2 - 2*gYsq3DS*λ6H3DS + 4*λ6H3DS**2 - 2*gYsq3DS*λ7H3DS + 4*λ7H3DS**2 + 3*λVL8**2 - 6*gwsq3DS*(λ6H3DS + λ7H3DS + 2*λVL8) + λVL9**2)*log(μ3/μ))/(384.*pi**2)
            mb3DS = mb - (Lb*mb*λ5H)/(16.*pi**2)
        
        #The couplings in the ultrasoft limit:
        λ1H3DUS = λ1H3DS - ((3*λVL6**2)/sqrt(μsqSU2) + (4*λVL2**2)/(sqrt(μsqSU2) + sqrt(μsqU1)) + λVL4**2/sqrt(μsqU1))/(32.*pi)
        λ2H3DUS = λ2H3DS - ((3*λVL7**2)/sqrt(μsqSU2) + (8*λVL1**2)/sqrt(μsqSU3) + (4*λVL3**2)/(sqrt(μsqSU2) + sqrt(μsqU1)) + λVL5**2/sqrt(μsqU1))/(32.*pi)
        λ3H3DUS = λ3H3DS - ((3*λVL6*λVL7)/sqrt(μsqSU2) + (λVL4*λVL5)/sqrt(μsqU1))/(16.*pi) + (λVL2*λVL3)/(4*pi*sqrt(μsqSU2) + 4*pi*sqrt(μsqU1))
        λ4H3DUS = λ4H3DS - (λVL2*λVL3)/(2.*pi*(sqrt(μsqSU2) + sqrt(μsqU1)))
        λ5H3DUS = -0.0625*(-16*pi*λ5H3DS + (3*λVL8**2)/sqrt(μsqSU2) + λVL9**2/sqrt(μsqU1))/pi
        λ6H3DUS = -0.0625*(-16*pi*λ6H3DS + (3*λVL6*λVL8)/sqrt(μsqSU2) + (λVL4*λVL9)/sqrt(μsqU1))/pi
        λ7H3DUS = -0.0625*(-16*pi*λ7H3DS + (3*λVL7*λVL8)/sqrt(μsqSU2) + (λVL5*λVL9)/sqrt(μsqU1))/pi
        gwsq3DUS = gwsq3DS - gwsq3DS**2/(24.*pi*sqrt(μsqSU2))
        gYsq3DUS = gYsq3DS
        a1233DUS = a1233DS
        
        #The scalar masses in the ultrasoft limit:
        if order == 0:
            m113DUS = m113DS - (3*λVL6*sqrt(μsqSU2) + λVL4*sqrt(μsqU1))/(8.*pi)
            m123DUS = m123DS
            m223DUS = m223DS - (3*λVL7*sqrt(μsqSU2) + 8*λVL1*sqrt(μsqSU3) + λVL5*sqrt(μsqU1))/(8.*pi)
            m333DUS = (m333DS - 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/2. + (m333DS + 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/2.
            mb3DUS = (m333DS + 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/4. + (-m333DS + 2*mb3DS + (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/4.
        elif order == 1:
            m113DUS = m113DS - (3*λVL6*sqrt(μsqSU2) + λVL4*sqrt(μsqU1))/(8.*pi) + (-12*λVL2**2 - 2*λVL4**2 + 12*gwsq3DS*λVL6 - 6*λVL6**2 + 15*λVL6*λVLL3 + λVL4*λVLL7 + (24*λVL6*λVLL2*sqrt(μsqSU3))/sqrt(μsqSU2) + (3*λVL4*λVLL6*sqrt(μsqSU2))/sqrt(μsqU1) + (8*λVL4*λVLL5*sqrt(μsqSU3))/sqrt(μsqU1) + (3*λVL6*λVLL6*sqrt(μsqU1))/sqrt(μsqSU2) - 6*(gwsq3DS**2 - 8*gwsq3DS*λVL6 + 2*λVL6**2)*log(μ3US/(2.*sqrt(μsqSU2))) - 24*λVL2**2*log(μ3US/(sqrt(μsqSU2) + sqrt(μsqU1))) - 4*λVL4**2*log(μ3US/(2.*sqrt(μsqU1))))/(128.*pi**2)
            m123DUS = m123DS
            m223DUS = m223DS - (3*λVL7*sqrt(μsqSU2) + 8*λVL1*sqrt(μsqSU3) + λVL5*sqrt(μsqU1))/(8.*pi) + (48*gssq3DS*λVL1 - 16*λVL1**2 - 12*λVL3**2 - 2*λVL5**2 + 12*gwsq3DS*λVL7 - 6*λVL7**2 + 80*λVL1*λVLL1 + 15*λVL7*λVLL3 + λVL5*λVLL7 + (24*λVL1*λVLL2*sqrt(μsqSU2))/sqrt(μsqSU3) + (24*λVL7*λVLL2*sqrt(μsqSU3))/sqrt(μsqSU2) + (3*λVL5*λVLL6*sqrt(μsqSU2))/sqrt(μsqU1) + (8*λVL5*λVLL5*sqrt(μsqSU3))/sqrt(μsqU1) + (3*λVL7*λVLL6*sqrt(μsqU1))/sqrt(μsqSU2) + (8*λVL1*λVLL5*sqrt(μsqU1))/sqrt(μsqSU3) - 6*(gwsq3DS**2 - 8*gwsq3DS*λVL7 + 2*λVL7**2)*log(μ3US/(2.*sqrt(μsqSU2))) + 32*(6*gssq3DS - λVL1)*λVL1*log(μ3US/(2.*sqrt(μsqSU3))) - 24*λVL3**2*log(μ3US/(sqrt(μsqSU2) + sqrt(μsqU1))) - 4*λVL5**2*log(μ3US/(2.*sqrt(μsqU1))))/(128.*pi**2)
            m333DUS = (m333DS - 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/2. + (m333DS + 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/2. + (12*gwsq3DS*λVL8 - 6*λVL8**2 - 2*λVL9**2 + 15*λVL8*λVLL3 + λVL9*λVLL7 + (24*λVL8*λVLL2*sqrt(μsqSU3))/sqrt(μsqSU2) + (3*λVL9*λVLL6*sqrt(μsqSU2))/sqrt(μsqU1) + (8*λVL9*λVLL5*sqrt(μsqSU3))/sqrt(μsqU1) + (3*λVL8*λVLL6*sqrt(μsqU1))/sqrt(μsqSU2) + 12*(4*gwsq3DS - λVL8)*λVL8*log(μ3US/(2.*sqrt(μsqSU2))) - 4*λVL9**2*log(μ3US/(2.*sqrt(μsqU1))))/(128.*pi**2)
            mb3DUS = (m333DS + 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/4. + (-m333DS + 2*mb3DS + (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/4.
        
        return array([λ1H3DUS, λ2H3DUS, λ3H3DUS, λ4H3DUS, λ5H3DUS, λ6H3DUS, λ7H3DUS, gwsq3DUS, gYsq3DUS, a1233DUS, m113DUS, m123DUS, m223DUS, m333DUS, mb3DUS])
        

    def VEff3DLO(self, X3D, params3DUS, *auxParams):
        """
        Returns the 3D effective potential at LO (tree-level).
        
        This function calculates the 3D effective potential at LO in terms of
        the vevs X3D and the 3D parameters in the ultrasoft limit. Note that
        the vevs X3D are assumed to live in three-dimensional space, so that
        they have mass dimension 1/2. The relation between the three-
        dimensional vevs X3D and the four-dimensional vevs X4D is given by
        X3D = X4D/√T, where T denotes the temperature.
        
        Parameters
        ----------
        X3D : array_like
            The 3D vevs as either a single point or an array of points
        params3DUS : array
            Array of the 3D-parameters in the ultrasoft limit
        auxParams : tuple
            Tuple of auxiliary parameters
        
        Returns
        -------
        The 3D effective potential at LO
        """
        X3D = asarray(X3D)
        phi1, phi2, phi3 = X3D[...,0], X3D[...,1], X3D[...,2]
        
        λ1H3DUS, λ2H3DUS, λ3H3DUS, λ4H3DUS, λ5H3DUS, λ6H3DUS, λ7H3DUS, gwsq3DUS, gYsq3DUS, a1233DUS, m113DUS, m123DUS, m223DUS, m333DUS, mb3DUS = params3DUS
        
        Veff = (a1233DUS*phi1*phi2*phi3)/sqrt(2) + (m113DUS*phi1**2 + 2*m123DUS*phi1*phi2 + m223DUS*phi2**2 + (m333DUS + 2*mb3DUS)*phi3**2)/2. + \
               (6*phi1**4*λ1H3DUS + 6*phi2**4*λ2H3DUS + 6*phi1**2*phi2**2*(λ3H3DUS + λ4H3DUS) + \
               3*phi3**4*λ5H3DUS + 6*phi1**2*phi3**2*λ6H3DUS + 6*phi2**2*phi3**2*λ7H3DUS)/24.
        
        
        return Veff
    


    def vectMassSq3DUSLO(self, X3D, params3DUS, *auxParams):
        """
        Returns the 3D field dependent vector boson masses.
        
        This function is used to calculate the 3D field dependent vector boson
        squared masses in the ultrasoft limit in terms of the vevs X3D and
        the 3D parameters in the ultrasoft limit. The masses are calculated at
        LO, i.e. from mass matrix derived from the LO potential VEff3DLO.
        
        Parameters
        ----------
        X3D : array_like
            The 3D vevs as either a single point or an array of points
        params3DUS : array
            Array of the 3D-parameters in the ultrasoft limit
        auxParams : tuple
            Tuple of auxiliary parameters
        
        Returns
        -------
        The 3D field dependent vector boson masses as an array
        """
        X3D = asarray(X3D)
        phi1, phi2, phi3 = X3D[...,0], X3D[...,1], X3D[...,2]
        _shape = phi1.shape
        
        λ1H3DUS, λ2H3DUS, λ3H3DUS, λ4H3DUS, λ5H3DUS, λ6H3DUS, λ7H3DUS, gwsq3DUS, gYsq3DUS, a1233DUS, m113DUS, m123DUS, m223DUS, m333DUS, mb3DUS = params3DUS
        
        _type = type(λ1H3DUS)
        
        #Vector boson masses which require no diagonalization:
        mVSq1 = (gwsq3DUS*(phi1**2 + phi2**2))/4.
        mVSq2 = (gwsq3DUS*(phi1**2 + phi2**2))/4.
        
        #Vector boson masses which require diagonalization:
        A1 = empty(_shape+(2,2), _type)
        A1[...,0,0] = (gwsq3DUS*(phi1**2 + phi2**2))/4.
        A1[...,0,1] = -0.25*(sqrt(gwsq3DUS)*sqrt(gYsq3DUS)*(phi1**2 + phi2**2))
        A1[...,1,0] = -0.25*(sqrt(gwsq3DUS)*sqrt(gYsq3DUS)*(phi1**2 + phi2**2))
        A1[...,1,1] = (gYsq3DUS*(phi1**2 + phi2**2))/4.
        A1_eig = eigvalsh(A1)
        mVSq3, mVSq4 = A1_eig[...,0], A1_eig[...,1]
        
        return array([mVSq1, mVSq2, mVSq3, mVSq4])
        

    def scalMassSq3DUSLO(self, X3D, params3DUS, *auxParams):
        """
        Returns the 3D field dependent scalar boson masses.
        
        This function is used to calculate the 3D field dependent scalar boson
        squared masses in the ultrasoft limit in terms of the vevs X3D and
        the 3D parameters in the ultrasoft limit. The masses are calculated at
        LO, i.e. from mass matrix derived from the LO potential VEff3DLO.
        
        Parameters
        ----------
        X3D : array_like
            The 3D vevs as either a single point or an array of points
        params3DUS : array
            Array of the 3D-parameters in the ultrasoft limit
        auxParams : tuple
            Tuple of auxiliary parameters
        
        Returns
        -------
        The 3D field dependent scalar boson masses as an array
        """
        X3D = asarray(X3D)
        phi1, phi2, phi3 = X3D[...,0], X3D[...,1], X3D[...,2]
        _shape = phi1.shape
        
        λ1H3DUS, λ2H3DUS, λ3H3DUS, λ4H3DUS, λ5H3DUS, λ6H3DUS, λ7H3DUS, gwsq3DUS, gYsq3DUS, a1233DUS, m113DUS, m123DUS, m223DUS, m333DUS, mb3DUS = params3DUS
        
        _type = type(λ1H3DUS)
        
        #Scalar boson masses which require no diagonalization:
        
        #Scalar boson masses which require diagonalization:
        A1 = empty(_shape+(6,6), _type)
        A1[...,0,0] = m113DUS + (6*λ1H3DUS*phi1**2 + (λ3H3DUS + λ4H3DUS)*phi2**2 + λ6H3DUS*phi3**2)/2.
        A1[...,0,1] = m123DUS + (λ3H3DUS + λ4H3DUS)*phi1*phi2
        A1[...,0,2] = -((a1233DUS*phi3)/sqrt(2))
        A1[...,0,3] = (a1233DUS*phi2)/sqrt(2)
        A1[...,0,4] = λ6H3DUS*phi1*phi3
        A1[...,0,5] = 0
        A1[...,1,0] = m123DUS + (λ3H3DUS + λ4H3DUS)*phi1*phi2
        A1[...,1,1] = m223DUS + ((λ3H3DUS + λ4H3DUS)*phi1**2 + 6*λ2H3DUS*phi2**2 + λ7H3DUS*phi3**2)/2.
        A1[...,1,2] = 0
        A1[...,1,3] = (a1233DUS*phi1)/sqrt(2)
        A1[...,1,4] = λ7H3DUS*phi2*phi3
        A1[...,1,5] = (a1233DUS*phi3)/sqrt(2)
        A1[...,2,0] = -((a1233DUS*phi3)/sqrt(2))
        A1[...,2,1] = 0
        A1[...,2,2] = m223DUS + ((λ3H3DUS + λ4H3DUS)*phi1**2 + 2*λ2H3DUS*phi2**2 + λ7H3DUS*phi3**2)/2.
        A1[...,2,3] = 0
        A1[...,2,4] = -((a1233DUS*phi1)/sqrt(2))
        A1[...,2,5] = m123DUS
        A1[...,3,0] = (a1233DUS*phi2)/sqrt(2)
        A1[...,3,1] = (a1233DUS*phi1)/sqrt(2)
        A1[...,3,2] = 0
        A1[...,3,3] = m333DUS + (4*mb3DUS + λ6H3DUS*phi1**2 + λ7H3DUS*phi2**2 + λ5H3DUS*phi3**2)/2.
        A1[...,3,4] = 0
        A1[...,3,5] = 0
        A1[...,4,0] = λ6H3DUS*phi1*phi3
        A1[...,4,1] = λ7H3DUS*phi2*phi3
        A1[...,4,2] = -((a1233DUS*phi1)/sqrt(2))
        A1[...,4,3] = 0
        A1[...,4,4] = m333DUS + (-4*mb3DUS + λ6H3DUS*phi1**2 + λ7H3DUS*phi2**2 + 3*λ5H3DUS*phi3**2)/2.
        A1[...,4,5] = (a1233DUS*phi2)/sqrt(2)
        A1[...,5,0] = 0
        A1[...,5,1] = (a1233DUS*phi3)/sqrt(2)
        A1[...,5,2] = m123DUS
        A1[...,5,3] = 0
        A1[...,5,4] = (a1233DUS*phi2)/sqrt(2)
        A1[...,5,5] = m113DUS + (2*λ1H3DUS*phi1**2 + (λ3H3DUS + λ4H3DUS)*phi2**2 + λ6H3DUS*phi3**2)/2.
        A1_eig = eigvalsh(A1)
        mVSq1, mVSq2, mVSq3, mVSq4, mVSq5, mVSq6 = A1_eig[...,0], A1_eig[...,1], A1_eig[...,2], A1_eig[...,3], A1_eig[...,4], A1_eig[...,5]
        
        A2 = empty(_shape+(4,4), _type)
        A2[...,0,0] = m113DUS + (2*λ1H3DUS*phi1**2 + λ3H3DUS*phi2**2 + λ6H3DUS*phi3**2)/2.
        A2[...,0,1] = m123DUS + (λ4H3DUS*phi1*phi2)/2.
        A2[...,0,2] = -((a1233DUS*phi3)/sqrt(2))
        A2[...,0,3] = 0
        A2[...,1,0] = m123DUS + (λ4H3DUS*phi1*phi2)/2.
        A2[...,1,1] = m223DUS + (λ3H3DUS*phi1**2 + 2*λ2H3DUS*phi2**2 + λ7H3DUS*phi3**2)/2.
        A2[...,1,2] = 0
        A2[...,1,3] = (a1233DUS*phi3)/sqrt(2)
        A2[...,2,0] = -((a1233DUS*phi3)/sqrt(2))
        A2[...,2,1] = 0
        A2[...,2,2] = m223DUS + (λ3H3DUS*phi1**2 + 2*λ2H3DUS*phi2**2 + λ7H3DUS*phi3**2)/2.
        A2[...,2,3] = m123DUS + (λ4H3DUS*phi1*phi2)/2.
        A2[...,3,0] = 0
        A2[...,3,1] = (a1233DUS*phi3)/sqrt(2)
        A2[...,3,2] = m123DUS + (λ4H3DUS*phi1*phi2)/2.
        A2[...,3,3] = m113DUS + (2*λ1H3DUS*phi1**2 + λ3H3DUS*phi2**2 + λ6H3DUS*phi3**2)/2.
        A2_eig = eigvalsh(A2)
        mVSq7, mVSq8, mVSq9, mVSq10 = A2_eig[...,0], A2_eig[...,1], A2_eig[...,2], A2_eig[...,3]
        
        return array([mVSq1, mVSq2, mVSq3, mVSq4, mVSq5, mVSq6, mVSq7, mVSq8, mVSq9, mVSq10])
        

    def pressure3DUS(self, T, mu4DH, mu3DS, params4D, order, *auxParams):
        """
        Returns the pressure in the 3D effective theory in the ultrasoft limit.
        
        This function is used to calculate the pressure in the 3D effective
        theory in the ultrasoft limit, in terms of the temperature T, the hard
        matching scale mu4DH (μ4DH), the hard-to-soft matching scale mu3DS
        (μ3DS) and the values of the 4D-parameters at scale μ4DH.
        
        Parameters
        ----------
        T : float
            The temperature
        mu4DH : float
            The hard matching scale (i.e. μ4DH)
        mu3DS : float
            The hard-to-soft matching scale (i.e. μ3DS)
        params4D : array
            Array of the 4D-parameters at scale μ4DH
        order : int
            The order at which the dimensional reduction is performed (0 or 1)
        auxParams : tuple
            Tuple of auxiliary parameters
        
        Returns
        -------
        The pressure in the 3D effective theory in the ultrasoft limit
        """
        μ = mu4DH
        μ3 = mu3DS
        μ3US = mu3DS #Temporary fix due to error in DRalgo notation
        Lb = LbFunc(mu4DH,T)
        Lf = LfFunc(mu4DH,T)
        
        gwsq, gYsq, gssq, λ1H, λ2H, λ3H, λ4H, λ5H, λ6H, λ7H, a123, yt1, m11, m12, m22, m33, mb, a123, m12 = params4D
        
        
        #The couplings in the soft limit:
        gwsq3DS = gwsq*T + (gwsq**2*(2 + 21*Lb - 12*Lf)*T)/(48.*pi**2)
        gYsq3DS = gYsq*T - (gYsq**2*(Lb + 20*Lf)*T)/(48.*pi**2)
        gssq3DS = gssq*T + (gssq**2*(1 + 11*Lb - 4*Lf)*T)/(16.*pi**2)
        λ1H3DS = (T*((3*gwsq**2 + 2*gwsq*gYsq + gYsq**2)*(2 - 3*Lb) + 24*(3*gwsq + gYsq)*Lb*λ1H + 256*pi**2*λ1H - 8*Lb*(24*λ1H**2 + λ3H**2 + (λ3H + λ4H)**2 + λ6H**2)))/(256.*pi**2)
        λ2H3DS = (T*((3*gwsq**2 + 2*gwsq*gYsq + gYsq**2)*(2 - 3*Lb) + 48*Lf*yt1**4 + 256*pi**2*λ2H + 24*(3*gwsq*Lb + gYsq*Lb - 4*Lf*yt1**2)*λ2H - 8*Lb*(24*λ2H**2 + λ3H**2 + (λ3H + λ4H)**2 + λ7H**2)))/(256.*pi**2)
        λ3H3DS = -0.0078125*(T*(gYsq**2*(-2 + 3*Lb) + gwsq**2*(-6 + 9*Lb) - 12*gYsq*Lb*λ3H + gwsq*(gYsq*(4 - 6*Lb) - 36*Lb*λ3H) + 8*(-16*pi**2*λ3H + 3*Lf*yt1**2*λ3H + Lb*(2*λ3H*(3*(λ1H + λ2H) + λ3H) + 2*(λ1H + λ2H)*λ4H + λ4H**2 + λ6H*λ7H))))/pi**2
        λ4H3DS = (T*(gwsq*(gYsq*(2 - 3*Lb) + 9*Lb*λ4H) - λ4H*(-3*gYsq*Lb - 32*pi**2 + 6*Lf*yt1**2 + 4*Lb*(λ1H + λ2H + 2*λ3H + λ4H))))/(32.*pi**2)
        λ5H3DS = T*(λ5H - (Lb*(5*λ5H**2 + 2*(λ6H**2 + λ7H**2)))/(16.*pi**2))
        λ6H3DS = (T*λ6H*(9*gwsq*Lb + 3*gYsq*Lb + 64*pi**2 - 8*Lb*(3*λ1H + λ5H + λ6H)) - 4*Lb*T*(2*λ3H + λ4H)*λ7H)/(64.*pi**2)
        λ7H3DS = -0.015625*(T*(-64*pi**2*λ7H + 12*Lf*yt1**2*λ7H + Lb*(8*λ3H*λ6H + 4*λ4H*λ6H + λ7H*(-9*gwsq - 3*gYsq + 8*(3*λ2H + λ5H + λ7H)))))/pi**2
        a1233DS = (a123*sqrt(T)*(9*gwsq*Lb + 3*gYsq*Lb + 64*pi**2 - 6*Lf*yt1**2 - 4*Lb*(λ3H + 2*λ4H + λ6H + λ7H)))/(64.*pi**2)
        
        #The temporal scalar couplings:
        λVLL1 = (gssq**2*T)/(4.*pi**2)
        λVLL2 = (-3*gssq*gwsq*T)/(4.*pi**2)
        λVLL3 = (gwsq**2*T)/(4.*pi**2)
        λVLL4 = -0.25*(gssq**1.5*sqrt(gYsq)*T)/pi**2
        λVLL5 = (-11*gssq*gYsq*T)/(12.*pi**2)
        λVLL6 = -0.25*(gwsq*gYsq*T)/pi**2
        λVLL7 = (-181*gYsq**2*T)/(36.*pi**2)
        λVL1 = -0.25*(gssq*T*yt1**2)/pi**2
        λVL2 = (sqrt(gwsq)*sqrt(gYsq)*T*(gwsq*(5 + 21*Lb - 12*Lf) - gYsq*(-21 + Lb + 20*Lf) + 12*(8*pi**2 + 2*λ1H + λ4H)))/(192.*pi**2)
        λVL3 = (sqrt(gwsq)*sqrt(gYsq)*T*(gwsq*(5 + 21*Lb - 12*Lf) - gYsq*(-21 + Lb + 20*Lf) + 12*(8*pi**2 + yt1**2 + 2*λ2H + λ4H)))/(192.*pi**2)
        λVL4 = -0.005208333333333333*(gYsq*T*(-9*gwsq + gYsq*(-39 + 2*Lb + 40*Lf) - 12*(8*pi**2 + 6*λ1H + 2*λ3H + λ4H)))/pi**2
        λVL5 = -0.005208333333333333*(gYsq*T*(-9*gwsq + gYsq*(-39 + 2*Lb + 40*Lf) - 96*pi**2 + 68*yt1**2 - 12*(6*λ2H + 2*λ3H + λ4H)))/pi**2
        λVL6 = (gwsq*T*(gwsq*(73 + 42*Lb - 24*Lf) + 3*(gYsq + 4*(8*pi**2 + 6*λ1H + 2*λ3H + λ4H))))/(192.*pi**2)
        λVL7 = (gwsq*T*(gwsq*(73 + 42*Lb - 24*Lf) + 3*(gYsq + 4*(8*pi**2 - 3*yt1**2 + 6*λ2H + 2*λ3H + λ4H))))/(192.*pi**2)
        λVL8 = (gwsq*T*(λ6H + λ7H))/(8.*pi**2)
        λVL9 = (gYsq*T*(λ6H + λ7H))/(8.*pi**2)
        
        #The Debye masses:
        if order == 0:
            μsqSU2 = 2*gwsq*T**2
            μsqSU3 = 2*gssq*T**2
            μsqU1 = 2*gYsq*T**2
        elif order == 1:
            μsqSU2 = 2*gwsq*T**2 + (gwsq*(24*m11 + 24*m22 + T**2*(-72*gssq - 3*gYsq + gwsq*(115 + 168*Lb - 96*Lf) - 3*yt1**2 + 12*λ1H + 12*λ2H + 8*λ3H + 4*λ4H + 2*λ6H + 2*λ7H)))/(192.*pi**2)
            μsqSU3 = 2*gssq*T**2 + (gssq*T**2*(-27*gwsq - 11*gYsq + 24*gssq*(5 + 11*Lb - 4*Lf) - 12*yt1**2))/(192.*pi**2)
            μsqU1 = 2*gYsq*T**2 + (gYsq*(144*m11 + 144*m22 + T**2*(-528*gssq - 54*gwsq + gYsq*(502 - 48*Lb - 960*Lf) - 66*yt1**2 + 12*(6*λ1H + 6*λ2H + 4*λ3H + 2*λ4H + λ6H + λ7H))))/(1152.*pi**2)
        
        #The scalar masses in the soft limit:
        if order == 0:
            m113DS = m11 + (T**2*(9*gwsq + 3*gYsq + 4*(6*λ1H + 2*λ3H + λ4H + λ6H)))/48.
            m123DS = m12
            m223DS = m22 + (T**2*(9*gwsq + 3*gYsq + 4*(3*yt1**2 + 6*λ2H + 2*λ3H + λ4H + λ7H)))/48.
            m333DS = m33 + (T**2*(λ5H + λ6H + λ7H))/6.
            mb3DS = mb
        elif order == 1:
            m113DS = m11 + (T**2*(9*gwsq + 3*gYsq + 4*(6*λ1H + 2*λ3H + λ4H + λ6H)))/48. - (96*a123**2*Lb - 216*gwsq*Lb*m11 - 72*gYsq*Lb*m11 - 201*gwsq**2*T**2 - 225*EulerGamma*gwsq**2*T**2 + 18*gwsq*gYsq*T**2 + 90*EulerGamma*gwsq*gYsq*T**2 - 17*gYsq**2*T**2 + 27*EulerGamma*gYsq**2*T**2 + 252*gwsq**2*Lb*T**2 - 72*gwsq*gYsq*Lb*T**2 + 50*gYsq**2*Lb*T**2 - 36*gwsq**2*Lf*T**2 - 20*gYsq**2*Lf*T**2 + 576*Lb*m11*λ1H - 72*gwsq*T**2*λ1H - 432*EulerGamma*gwsq*T**2*λ1H - 24*gYsq*T**2*λ1H - 144*EulerGamma*gYsq*T**2*λ1H + 216*gwsq*Lb*T**2*λ1H + 72*gYsq*Lb*T**2*λ1H + 576*EulerGamma*T**2*λ1H**2 + 192*Lb*m22*λ3H - 24*gwsq*T**2*λ3H - 144*EulerGamma*gwsq*T**2*λ3H - 8*gYsq*T**2*λ3H - 48*EulerGamma*gYsq*T**2*λ3H + 72*gwsq*Lb*T**2*λ3H + 24*gYsq*Lb*T**2*λ3H + 72*Lb*T**2*yt1**2*λ3H - 24*Lf*T**2*yt1**2*λ3H + 96*Lb*T**2*λ1H*λ3H + 96*Lb*T**2*λ2H*λ3H + 96*EulerGamma*T**2*λ3H**2 - 16*Lb*T**2*λ3H**2 + 96*Lb*m22*λ4H - 12*gwsq*T**2*λ4H - 72*EulerGamma*gwsq*T**2*λ4H - 4*gYsq*T**2*λ4H - 24*EulerGamma*gYsq*T**2*λ4H + 36*gwsq*Lb*T**2*λ4H + 12*gYsq*Lb*T**2*λ4H + 36*Lb*T**2*yt1**2*λ4H - 12*Lf*T**2*yt1**2*λ4H + 48*Lb*T**2*λ1H*λ4H + 48*Lb*T**2*λ2H*λ4H + 96*EulerGamma*T**2*λ3H*λ4H - 16*Lb*T**2*λ3H*λ4H + 96*EulerGamma*T**2*λ4H**2 - 40*Lb*T**2*λ4H**2 + 96*Lb*m33*λ6H - 18*gwsq*Lb*T**2*λ6H - 6*gYsq*Lb*T**2*λ6H + 48*Lb*T**2*λ1H*λ6H + 16*Lb*T**2*λ5H*λ6H + 48*EulerGamma*T**2*λ6H**2 - 8*Lb*T**2*λ6H**2 + 16*Lb*T**2*λ3H*λ7H + 8*Lb*T**2*λ4H*λ7H + 16*Lb*T**2*λ6H*λ7H + 2700*gwsq**2*T**2*log(Glaisher) - 1080*gwsq*gYsq*T**2*log(Glaisher) - 324*gYsq**2*T**2*log(Glaisher) + 5184*gwsq*T**2*λ1H*log(Glaisher) + 1728*gYsq*T**2*λ1H*log(Glaisher) - 6912*T**2*λ1H**2*log(Glaisher) + 1728*gwsq*T**2*λ3H*log(Glaisher) + 576*gYsq*T**2*λ3H*log(Glaisher) - 1152*T**2*λ3H**2*log(Glaisher) + 864*gwsq*T**2*λ4H*log(Glaisher) + 288*gYsq*T**2*λ4H*log(Glaisher) - 1152*T**2*λ3H*λ4H*log(Glaisher) - 1152*T**2*λ4H**2*log(Glaisher) - 576*T**2*λ6H**2*log(Glaisher) + 6*(33*gwsq3DS**2 - 7*gYsq3DS**2 + 8*gYsq3DS*(6*λ1H3DS + 2*λ3H3DS + λ4H3DS) - 8*(24*λ1H3DS**2 + 4*λ3H3DS**2 + 4*λ3H3DS*λ4H3DS + 4*λ4H3DS**2 + 2*λ6H3DS**2 + 6*λVL2**2 + λVL4**2 + 3*λVL6**2) + 6*gwsq3DS*(-3*gYsq3DS + 4*(6*λ1H3DS + 2*λ3H3DS + λ4H3DS + 4*λVL6)))*log(μ3/μ))/(1536.*pi**2)
            m123DS = m12 + (m12*(9*gwsq*Lb + 3*gYsq*Lb - 6*Lf*yt1**2 - 4*Lb*λ3H - 8*Lb*λ4H))/(64.*pi**2)
            m223DS = m22 + (T**2*(9*gwsq + 3*gYsq + 4*(3*yt1**2 + 6*λ2H + 2*λ3H + λ4H + λ7H)))/48. - (288*a123**2*Lb - 648*gwsq*Lb*m22 - 216*gYsq*Lb*m22 - 603*gwsq**2*T**2 - 675*EulerGamma*gwsq**2*T**2 + 54*gwsq*gYsq*T**2 + 270*EulerGamma*gwsq*gYsq*T**2 - 51*gYsq**2*T**2 + 81*EulerGamma*gYsq**2*T**2 + 756*gwsq**2*Lb*T**2 - 216*gwsq*gYsq*Lb*T**2 + 150*gYsq**2*Lb*T**2 - 108*gwsq**2*Lf*T**2 - 60*gYsq**2*Lf*T**2 + 864*Lf*m22*yt1**2 + 576*gssq*T**2*yt1**2 + 54*gwsq*T**2*yt1**2 + 66*gYsq*T**2*yt1**2 + 192*gssq*Lb*T**2*yt1**2 - 189*gwsq*Lb*T**2*yt1**2 - 47*gYsq*Lb*T**2*yt1**2 - 768*gssq*Lf*T**2*yt1**2 + 27*gwsq*Lf*T**2*yt1**2 - 55*gYsq*Lf*T**2*yt1**2 - 108*Lb*T**2*yt1**4 + 1728*Lb*m22*λ2H - 216*gwsq*T**2*λ2H - 1296*EulerGamma*gwsq*T**2*λ2H - 72*gYsq*T**2*λ2H - 432*EulerGamma*gYsq*T**2*λ2H + 648*gwsq*Lb*T**2*λ2H + 216*gYsq*Lb*T**2*λ2H + 648*Lb*T**2*yt1**2*λ2H + 216*Lf*T**2*yt1**2*λ2H + 1728*EulerGamma*T**2*λ2H**2 + 576*Lb*m11*λ3H - 72*gwsq*T**2*λ3H - 432*EulerGamma*gwsq*T**2*λ3H - 24*gYsq*T**2*λ3H - 144*EulerGamma*gYsq*T**2*λ3H + 216*gwsq*Lb*T**2*λ3H + 72*gYsq*Lb*T**2*λ3H + 144*Lf*T**2*yt1**2*λ3H + 288*Lb*T**2*λ1H*λ3H + 288*Lb*T**2*λ2H*λ3H + 288*EulerGamma*T**2*λ3H**2 - 48*Lb*T**2*λ3H**2 + 288*Lb*m11*λ4H - 36*gwsq*T**2*λ4H - 216*EulerGamma*gwsq*T**2*λ4H - 12*gYsq*T**2*λ4H - 72*EulerGamma*gYsq*T**2*λ4H + 108*gwsq*Lb*T**2*λ4H + 36*gYsq*Lb*T**2*λ4H + 72*Lf*T**2*yt1**2*λ4H + 144*Lb*T**2*λ1H*λ4H + 144*Lb*T**2*λ2H*λ4H + 288*EulerGamma*T**2*λ3H*λ4H - 48*Lb*T**2*λ3H*λ4H + 288*EulerGamma*T**2*λ4H**2 - 120*Lb*T**2*λ4H**2 + 48*Lb*T**2*λ3H*λ6H + 24*Lb*T**2*λ4H*λ6H + 288*Lb*m33*λ7H - 54*gwsq*Lb*T**2*λ7H - 18*gYsq*Lb*T**2*λ7H + 72*Lf*T**2*yt1**2*λ7H + 144*Lb*T**2*λ2H*λ7H + 48*Lb*T**2*λ5H*λ7H + 48*Lb*T**2*λ6H*λ7H + 144*EulerGamma*T**2*λ7H**2 - 24*Lb*T**2*λ7H**2 + 8100*gwsq**2*T**2*log(Glaisher) - 3240*gwsq*gYsq*T**2*log(Glaisher) - 972*gYsq**2*T**2*log(Glaisher) + 15552*gwsq*T**2*λ2H*log(Glaisher) + 5184*gYsq*T**2*λ2H*log(Glaisher) - 20736*T**2*λ2H**2*log(Glaisher) + 5184*gwsq*T**2*λ3H*log(Glaisher) + 1728*gYsq*T**2*λ3H*log(Glaisher) - 3456*T**2*λ3H**2*log(Glaisher) + 2592*gwsq*T**2*λ4H*log(Glaisher) + 864*gYsq*T**2*λ4H*log(Glaisher) - 3456*T**2*λ3H*λ4H*log(Glaisher) - 3456*T**2*λ4H**2*log(Glaisher) - 1728*T**2*λ7H**2*log(Glaisher) + 18*(33*gwsq3DS**2 - 7*gYsq3DS**2 + 8*gYsq3DS*(6*λ2H3DS + 2*λ3H3DS + λ4H3DS) - 8*(24*λ2H3DS**2 + 4*λ3H3DS**2 + 4*λ3H3DS*λ4H3DS + 4*λ4H3DS**2 + 2*λ7H3DS**2 - 48*gssq3DS*λVL1 + 8*λVL1**2 + 6*λVL3**2 + λVL5**2 + 3*λVL7**2) + 6*gwsq3DS*(-3*gYsq3DS + 4*(6*λ2H3DS + 2*λ3H3DS + λ4H3DS + 4*λVL7)))*log(μ3/μ))/(4608.*pi**2)
            m333DS = m33 + (T**2*(λ5H + λ6H + λ7H))/6. - (48*a123**2*Lb + 48*Lb*m33*λ5H + 24*EulerGamma*T**2*λ5H**2 - 4*Lb*T**2*λ5H**2 + 48*Lb*m11*λ6H - 6*gwsq*T**2*λ6H - 36*EulerGamma*gwsq*T**2*λ6H - 2*gYsq*T**2*λ6H - 12*EulerGamma*gYsq*T**2*λ6H + 27*gwsq*Lb*T**2*λ6H + 9*gYsq*Lb*T**2*λ6H + 24*Lb*T**2*λ1H*λ6H + 8*Lb*T**2*λ3H*λ6H + 4*Lb*T**2*λ4H*λ6H + 8*Lb*T**2*λ5H*λ6H + 24*EulerGamma*T**2*λ6H**2 - 8*Lb*T**2*λ6H**2 + 48*Lb*m22*λ7H - 6*gwsq*T**2*λ7H - 36*EulerGamma*gwsq*T**2*λ7H - 2*gYsq*T**2*λ7H - 12*EulerGamma*gYsq*T**2*λ7H + 27*gwsq*Lb*T**2*λ7H + 9*gYsq*Lb*T**2*λ7H + 18*Lb*T**2*yt1**2*λ7H - 6*Lf*T**2*yt1**2*λ7H + 24*Lb*T**2*λ2H*λ7H + 8*Lb*T**2*λ3H*λ7H + 4*Lb*T**2*λ4H*λ7H + 8*Lb*T**2*λ5H*λ7H + 24*EulerGamma*T**2*λ7H**2 - 8*Lb*T**2*λ7H**2 - 288*T**2*λ5H**2*log(Glaisher) + 432*gwsq*T**2*λ6H*log(Glaisher) + 144*gYsq*T**2*λ6H*log(Glaisher) - 288*T**2*λ6H**2*log(Glaisher) + 432*gwsq*T**2*λ7H*log(Glaisher) + 144*gYsq*T**2*λ7H*log(Glaisher) - 288*T**2*λ7H**2*log(Glaisher) - 12*(4*λ5H3DS**2 - 2*gYsq3DS*λ6H3DS + 4*λ6H3DS**2 - 2*gYsq3DS*λ7H3DS + 4*λ7H3DS**2 + 3*λVL8**2 - 6*gwsq3DS*(λ6H3DS + λ7H3DS + 2*λVL8) + λVL9**2)*log(μ3/μ))/(384.*pi**2)
            mb3DS = mb - (Lb*mb*λ5H)/(16.*pi**2)
        
        #The couplings in the ultrasoft limit:
        λ1H3DUS = λ1H3DS - ((3*λVL6**2)/sqrt(μsqSU2) + (4*λVL2**2)/(sqrt(μsqSU2) + sqrt(μsqU1)) + λVL4**2/sqrt(μsqU1))/(32.*pi)
        λ2H3DUS = λ2H3DS - ((3*λVL7**2)/sqrt(μsqSU2) + (8*λVL1**2)/sqrt(μsqSU3) + (4*λVL3**2)/(sqrt(μsqSU2) + sqrt(μsqU1)) + λVL5**2/sqrt(μsqU1))/(32.*pi)
        λ3H3DUS = λ3H3DS - ((3*λVL6*λVL7)/sqrt(μsqSU2) + (λVL4*λVL5)/sqrt(μsqU1))/(16.*pi) + (λVL2*λVL3)/(4*pi*sqrt(μsqSU2) + 4*pi*sqrt(μsqU1))
        λ4H3DUS = λ4H3DS - (λVL2*λVL3)/(2.*pi*(sqrt(μsqSU2) + sqrt(μsqU1)))
        λ5H3DUS = -0.0625*(-16*pi*λ5H3DS + (3*λVL8**2)/sqrt(μsqSU2) + λVL9**2/sqrt(μsqU1))/pi
        λ6H3DUS = -0.0625*(-16*pi*λ6H3DS + (3*λVL6*λVL8)/sqrt(μsqSU2) + (λVL4*λVL9)/sqrt(μsqU1))/pi
        λ7H3DUS = -0.0625*(-16*pi*λ7H3DS + (3*λVL7*λVL8)/sqrt(μsqSU2) + (λVL5*λVL9)/sqrt(μsqU1))/pi
        gwsq3DUS = gwsq3DS - gwsq3DS**2/(24.*pi*sqrt(μsqSU2))
        gYsq3DUS = gYsq3DS
        a1233DUS = a1233DS
        {λ1H3DUS, λ2H3DUS, λ3H3DUS, λ4H3DUS, λ5H3DUS, λ6H3DUS, λ7H3DUS, gwsq3DUS, gYsq3DUS, a1233DUS}[[11]] = Part(List(λ1H3DS - ((3*λVL6**2)/sqrt(μsqSU2) + (4*λVL2**2)/(sqrt(μsqSU2) + sqrt(μsqU1)) + λVL4**2/sqrt(μsqU1))/(32.*pi),λ2H3DS - ((3*λVL7**2)/sqrt(μsqSU2) + (8*λVL1**2)/sqrt(μsqSU3) + (4*λVL3**2)/(sqrt(μsqSU2) + sqrt(μsqU1)) + λVL5**2/sqrt(μsqU1))/(32.*pi),λ3H3DS - ((3*λVL6*λVL7)/sqrt(μsqSU2) + (λVL4*λVL5)/sqrt(μsqU1))/(16.*pi) + (λVL2*λVL3)/(4*pi*sqrt(μsqSU2) + 4*pi*sqrt(μsqU1)),λ4H3DS - (λVL2*λVL3)/(2.*pi*(sqrt(μsqSU2) + sqrt(μsqU1))),-0.0625*(-16*pi*λ5H3DS + (3*λVL8**2)/sqrt(μsqSU2) + λVL9**2/sqrt(μsqU1))/pi,-0.0625*(-16*pi*λ6H3DS + (3*λVL6*λVL8)/sqrt(μsqSU2) + (λVL4*λVL9)/sqrt(μsqU1))/pi,-0.0625*(-16*pi*λ7H3DS + (3*λVL7*λVL8)/sqrt(μsqSU2) + (λVL5*λVL9)/sqrt(μsqU1))/pi,gwsq3DS - gwsq3DS**2/(24.*pi*sqrt(μsqSU2)),gYsq3DS,a1233DS),11)
        
        #The scalar masses in the ultrasoft limit:
        if order == 0:
            m113DUS = m113DS - (3*λVL6*sqrt(μsqSU2) + λVL4*sqrt(μsqU1))/(8.*pi)
            m123DUS = m123DS
            m223DUS = m223DS - (3*λVL7*sqrt(μsqSU2) + 8*λVL1*sqrt(μsqSU3) + λVL5*sqrt(μsqU1))/(8.*pi)
            m333DUS = (m333DS - 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/2. + (m333DS + 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/2.
            mb3DUS = (m333DS + 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/4. + (-m333DS + 2*mb3DS + (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/4.
        elif order == 1:
            m113DUS = m113DS - (3*λVL6*sqrt(μsqSU2) + λVL4*sqrt(μsqU1))/(8.*pi) + (-12*λVL2**2 - 2*λVL4**2 + 12*gwsq3DS*λVL6 - 6*λVL6**2 + 15*λVL6*λVLL3 + λVL4*λVLL7 + (24*λVL6*λVLL2*sqrt(μsqSU3))/sqrt(μsqSU2) + (3*λVL4*λVLL6*sqrt(μsqSU2))/sqrt(μsqU1) + (8*λVL4*λVLL5*sqrt(μsqSU3))/sqrt(μsqU1) + (3*λVL6*λVLL6*sqrt(μsqU1))/sqrt(μsqSU2) - 6*(gwsq3DS**2 - 8*gwsq3DS*λVL6 + 2*λVL6**2)*log(μ3US/(2.*sqrt(μsqSU2))) - 24*λVL2**2*log(μ3US/(sqrt(μsqSU2) + sqrt(μsqU1))) - 4*λVL4**2*log(μ3US/(2.*sqrt(μsqU1))))/(128.*pi**2)
            m123DUS = m123DS
            m223DUS = m223DS - (3*λVL7*sqrt(μsqSU2) + 8*λVL1*sqrt(μsqSU3) + λVL5*sqrt(μsqU1))/(8.*pi) + (48*gssq3DS*λVL1 - 16*λVL1**2 - 12*λVL3**2 - 2*λVL5**2 + 12*gwsq3DS*λVL7 - 6*λVL7**2 + 80*λVL1*λVLL1 + 15*λVL7*λVLL3 + λVL5*λVLL7 + (24*λVL1*λVLL2*sqrt(μsqSU2))/sqrt(μsqSU3) + (24*λVL7*λVLL2*sqrt(μsqSU3))/sqrt(μsqSU2) + (3*λVL5*λVLL6*sqrt(μsqSU2))/sqrt(μsqU1) + (8*λVL5*λVLL5*sqrt(μsqSU3))/sqrt(μsqU1) + (3*λVL7*λVLL6*sqrt(μsqU1))/sqrt(μsqSU2) + (8*λVL1*λVLL5*sqrt(μsqU1))/sqrt(μsqSU3) - 6*(gwsq3DS**2 - 8*gwsq3DS*λVL7 + 2*λVL7**2)*log(μ3US/(2.*sqrt(μsqSU2))) + 32*(6*gssq3DS - λVL1)*λVL1*log(μ3US/(2.*sqrt(μsqSU3))) - 24*λVL3**2*log(μ3US/(sqrt(μsqSU2) + sqrt(μsqU1))) - 4*λVL5**2*log(μ3US/(2.*sqrt(μsqU1))))/(128.*pi**2)
            m333DUS = (m333DS - 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/2. + (m333DS + 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/2. + (12*gwsq3DS*λVL8 - 6*λVL8**2 - 2*λVL9**2 + 15*λVL8*λVLL3 + λVL9*λVLL7 + (24*λVL8*λVLL2*sqrt(μsqSU3))/sqrt(μsqSU2) + (3*λVL9*λVLL6*sqrt(μsqSU2))/sqrt(μsqU1) + (8*λVL9*λVLL5*sqrt(μsqSU3))/sqrt(μsqU1) + (3*λVL8*λVLL6*sqrt(μsqU1))/sqrt(μsqSU2) + 12*(4*gwsq3DS - λVL8)*λVL8*log(μ3US/(2.*sqrt(μsqSU2))) - 4*λVL9**2*log(μ3US/(2.*sqrt(μsqU1))))/(128.*pi**2)
            mb3DUS = (m333DS + 2*mb3DS - (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/4. + (-m333DS + 2*mb3DS + (3*λVL8*sqrt(μsqSU2) + λVL9*sqrt(μsqU1))/(8.*pi))/4.
        
        if order == 0:
            return μsqSU2**1.5/(4.*pi) + (2*μsqSU3**1.5)/(3.*pi) + μsqU1**1.5/(12.*pi)
        elif order == 1:
            return μsqSU2**1.5/(4.*pi) + (2*μsqSU3**1.5)/(3.*pi) + μsqU1**1.5/(12.*pi) - (15*λVLL3*μsqSU2 + 48*λVLL2*sqrt(μsqSU2)*sqrt(μsqSU3) + 80*λVLL1*μsqSU3 + 6*λVLL6*sqrt(μsqSU2)*sqrt(μsqU1) + 16*λVLL5*sqrt(μsqSU3)*sqrt(μsqU1) + λVLL7*μsqU1)/(2048.*pi) - (3*gwsq3DS*(6*μsqSU2 + 8*μsqSU2*log(μ3/(2.*sqrt(μsqSU2)))))/(64.*pi**2) - (3*gssq3DS*(6*μsqSU3 + 8*μsqSU3*log(μ3/(2.*sqrt(μsqSU3)))))/(16.*pi**2)
        



def calculateParams4DRef():
    """
    Returns the reference value params4DRef for the 4D MS-bar parameters.
    
    This is a template for a function that can be used to calculate the
    reference value params4DRef at the reference scale mu4DRef in terms
    of suitable physical parameters. The main purpose of the template
    function is to ensure that the output has the right format (in 
    particular that the parameters appear in the right order.)
    
    Parameters
    ----------
    mu4DRef : float
        The reference value of the 4D RG scale parameter μ4D
    *args
        To be filled in
    **kwargs
        To be filled in
    
    Returns
    -------
    The reference value params4DRef as an array
    """

    Pi = np.pi
    Sin = np.sin
    Cos = np.cos
    Sqrt = np.sqrt
    Tan = np.tan
    
    def Csc(x):
        return 1/np.sin(x)
    def Sec(x):
        return 1/np.cos(x)
    def Cot(x):
        return 1/np.tan(x)
    
    mH1sq = 125.25**2
    mH2sq, mH3sq = np.random.uniform(200, 1500)**2, np.random.uniform(200, 1500)**2
    mAh2sq, mAh3sq = np.random.uniform(200, 1500)**2, np.random.uniform(200, 1500)**2
    mCh = np.random.uniform(200, 1500)**2

    γ1 = np.random.uniform(0, 2*np.pi)
    β = np.random.uniform(1, 15)
    a1 = β + Pi/2
    a2, a3 = 0., 0.
    v = 246.
    v1, v2 = v*np.cos(β), v*np.sin(β)
    v3 = np.random.uniform(300, 5000)

    gwsq = pow(0.65100, 2)
    gYsq = pow(0.357254, 2)
    gssq = pow(1.2104, 2)
    a123 = (Sqrt(2)*(mAh2sq - mAh3sq)*Cos(γ1)*Sin(γ1))/v
    m12 = ((-mAh2sq + mAh3sq)*v3*Cos(γ1)*Sin(γ1))/v - Cos(β)*Sin(β)*(mAh2sq*Cos(γ1)**2 + mAh3sq*Sin(γ1)**2)
    λ1H = (Sec(β)**2*(Sin(a1)**2*(mH2sq*Cos(a3)**2 + mH3sq*Sin(a3)**2) \
          + Cos(a1)**2*(mH1sq*Cos(a2)**2 + Sin(a2)**2*(mH3sq*Cos(a3)**2 + mH2sq*Sin(a3)**2)) \
          + (mH2sq - mH3sq)*Cos(a1)*Sin(a1)*Sin(a2)*Sin(2*a3) - Sin(β)**2*(mAh2sq*Cos(γ1)**2 \
          + mAh3sq*Sin(γ1)**2)))/(2.*v**2)
    λ2H = (Csc(β)**2*(Cos(a1)**2*(mH2sq*Cos(a3)**2 + mH3sq*Sin(a3)**2) + Sin(a1)**2*(mH1sq*Cos(a2)**2 \
          + Sin(a2)**2*(mH3sq*Cos(a3)**2 + mH2sq*Sin(a3)**2)) + (-mH2sq + mH3sq)*Cos(a1)*Sin(a1)*Sin(a2)*Sin(2*a3) \
          - Cos(β)**2*(mAh2sq*Cos(γ1)**2 + mAh3sq*Sin(γ1)**2)))/(2.*v**2)
    λ3H = (2*mCh + mAh2sq*Cos(γ1)**2 + (Csc(β)*Sec(β)*(8*(Sqrt(2)*v3*a123 + 2*m12) \
          + 2*(-2*mH1sq + mH2sq + mH3sq)*Cos(a2)**2*Sin(2*a1) + (mH2sq - mH3sq)*(-((-3 \
          + Cos(2*a2))*Cos(2*a3)*Sin(2*a1)) + 4*Cos(2*a1)*Sin(a2)*Sin(2*a3))))/8. + mAh3sq*Sin(γ1)**2)/v**2
    λ4H = (-2*(mCh + (Sqrt(2)*v3*a123 + 2*m12)*Csc(2*β)))/v**2
    λ5H = (mH1sq*v3*Sin(a2)**2 + v3*Cos(a2)**2*(mH3sq*Cos(a3)**2 + mH2sq*Sin(a3)**2) \
          + (mAh2sq - mAh3sq)*v*Cos(β)*Cos(γ1)*Sin(β)*Sin(γ1))/(2.*v3**3)
    λ6H = (Cos(a2)*Sec(β)*((-mH2sq + mH3sq)*Cos(a3)*Sin(a1)*Sin(a3) +  Cos(a1)*Sin(a2)*(mH1sq \
          - mH3sq*Cos(a3)**2 - mH2sq*Sin(a3)**2)) + (-mAh2sq + mAh3sq)*Cos(γ1)*Sin(γ1)*Tan(β))/(v*v3)
    λ7H = (Cos(a2)*Csc(β)*((-mH2sq + mH3sq)*Cos(a1)*Cos(a3)*Sin(a3) + Sin(a1)*Sin(a2)*(-mH1sq \
          + mH3sq*Cos(a3)**2 + mH2sq*Sin(a3)**2)) + (-mAh2sq + mAh3sq)*Cos(γ1)*Cot(β)*Sin(γ1))/(v*v3)
    yt1 = np.sqrt(2)*168.26/v2
    m11 = -(2*v1**3*λ1H + v1*v2**2*(λ3H + λ4H) + v1*v3**2*λ6H + v2*(Sqrt(2)*v3*a123 + 2*m12))/(2.*v1) 
    m22 = -(2*v2**3*λ2H + v1**2*v2*(λ3H + λ4H) + v2*v3**2*λ7H + v1*(Sqrt(2)*v3*a123 + 2*m12))/(2.*v2)
    mb = -(mAh3sq*v3*Cos(γ1)**2 + (mAh2sq - mAh3sq)*v*Cos(β)*Cos(γ1)*Sin(β)*Sin(γ1) + mAh2sq*v3*Sin(γ1)**2)/(2.*v3)
    m33 = -(Sqrt(2)*v1*v2*a123 + 2*v3**3*λ5H + v1**2*v3*λ6H + v2**2*v3*λ7H + 2*v3*mb)/(2.*v3)

    return array([gwsq, gYsq, gssq, λ1H, λ2H, λ3H, λ4H, λ5H, λ6H, λ7H, a123, yt1, m11, m12, m22, m33, mb])

params4DRef = calculateParams4DRef()
#params4DRef = np.array([ 4.23801000e-01,  1.27630421e-01,  1.46506816e+00, -2.82959837e+00,
#                         -9.44126695e+00,  1.12704527e+01, -1.26950921e-01,  3.01886373e-02,
#                          2.08640774e-01,  3.46939854e-01,  1.57675444e+03,  1.57846418e+00,
#                         -1.52218285e+06, -4.24764514e+06, -2.49442150e+06, -1.10703531e+04,
#                         -5.07357423e+05])

m = NTHDM(Ndim = nVevs, mu4DMin = 246, mu4DMax = 10_000, mu4DRef = 246.,
         params4DRef = params4DRef, highTOptions = {}, 
         solve4DRGOptions = {}, 
         params3DUSInterpolOptions = {}, scaleFactor = 1, mu3DSPreFactor = 1,
         auxParams = None, Tmin = None, Tmax = None, order = 0)

print("============= START CT =============")
m.findAllTransitions()
m.prettyPrintTnTrans() 


