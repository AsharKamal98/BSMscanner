#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import division
from __future__ import print_function
from solve_intermediate_vp import solve_intermediate_vp
from abc import ABC, abstractmethod
from scipy.interpolate import CubicSpline
import numpy as np
import matplotlib.pyplot as plt


#TO DO:
#Treat order consistently?
#Change mu to mu4H

#Some parameters
EulerGamma = 0.57721566490153286554943
Glaisher = 1.28242712910062262032795
Lb = lambda mu,T : 2*EulerGamma - 2*np.log(4*np.pi) + 2*np.log(mu/T)
Lf = lambda mu,T: Lb(mu, T) + 4*np.log(2)  

class modelDR(ABC):
    """
    Implements a model and its effective potential using dimensional reduction.
    
    This class implements a generic model and its effective potential using
    dimensional reduction. By calculating the effective potential at finite 
    temperature, the class can easily be interfaced with various tools for 
    calculating the bounce action, such as CosmoTransitions. 
    
    The class is an abstract class, and the following functions must be
    specified (by overriding) in any concrete subclass:
        RGFuncs4D
        DebyeMassSq
        DRStep
        VEff3DLO
        vectMassSq3DUS
        scalMassSq3DUS
        pressure3DUS
        
    Optionally, the user *may* also override the function VEff3DNLO. This can
    be useful e.g. when doing an implementation in general Rξ (Fermi) gauge,
    rather than Landau gauge (ξ = 0), which is assumed in this implementation.
    
    The class is written to be used with the Mathematica package DRalgo by
    Ekstedt, Schicho and Tenkanen (see: https://arxiv.org/abs/2205.08815v1)
    Thus, the DRalgo package should be used to specify the above functions
    in the concrete subclass for any particular model. In principle, the 
    required expressions can of course also be obtained by other means. 
    
    The setup is based on the setup in the example file ah-thermo.m in the
    DRalgo package, and works as follows:
    1) At a given temperature T, define the hard matching scale μ4DH by
       μ4DH = scaleFactor * π * T, where scaleFactor defaults to 1, but can be
       set to another positive value.
    2) Obtain the parameters of the 4D Lagrangian at the 4D RG scale μ4DH by 
       solving the RG equations, as defined by the function RGFuncs4D. In
       practice, this is done by solving the RG equations *once* during setup,
       and defining a function that can be called for any value of μ4D in a 
       user-defined range by means of interpolation. The solution of the RG
       equations requires a reference value, params4DRef, of the 4D MSbar 
       parameters at a given value, mu4DRef, of the 4D RG scale μ4D.
       Optionally, the user can specify minimum and maximum values for the
       4D parameters through the parameters params4DMin and params4DMax in the
       parameter solve4DRGOptions. This will force the RG solver to terminate
       when a limit for at least one parameter is reached. This can be used
       to avoid issues with Landau poles, and to impose e.g. perturbativity
       constraints.
    3) Calculate the 3D scale μ3DS for the hard-to-soft matching for the 
       dimensional reduction. This is handled by the function mu3DS, which
       sets μ3DS to mu3DSPreFactor * mDMin, where mu3DSPreFactor is a user-
       defined  prefactor (which defaults to 1), and mDMin is the smallest 
       Debye mass at the given temperature.
    4) Calculate the parameters of the effective 3D Lagrangian in the ultra-
       soft limit, using the function DRStep. 
    5) Calculate the 3D effective potential at the given 3D parameters and 3D
       field values X3D using the functions VEff3DLO or VEff3DNLO.
    6) Calculate the thermal effective potential (if so desired, e.g. for
       convenient usage in CosmoTransitions) as T*VEff3D, with the 4D field
       values related to the 3D field values by X3D = X4D/√T.
       
    During setup, a finite range [mu4DMinLow, mu4DMaxHigh] for the 4D RG scale 
    parameter μ4D has to be specified (with a corresponding implied *maximum*
    range for the temperature through the relation μ4DH = scaleFactor * π * T).
    The range should be large enough to ensure that any possible phase 
    transition of interest can be captured. If the parameters params4DMin or
    params4DMax are set (see above), it may be that the RG solver terminates
    above mu4DMinLow or below mu4DMaxHigh. The minimum and maximum values of
    μ4D are stored in the attributes mu4DMin and mu4DMax, respectively.
    
    During setup, a lower limit for the minimum temperature as well as an
    upper limit for the maximum temperature are calculated, and stored as the
    attributes TMinLow and TMaxHigh, respectively. The corresponding range 
    [TMinLow, TMaxHigh] gives the largest possible temperature range over 
    which the model can be safely used. The parameter TMaxHigh is simply
    calculated based on the largest possible value of μ4DH, and is given by
    TMaxHigh = mu4DMax/(scaleFactor * π). Meanwhile, the parameter TMinLow is 
    calculated based on the following three considerations. First of all, 
    TMinLow has to be greater than or equal to mu4DMin/(scaleFactor * π).
    Second, it has to be ensured that the minimum temperature is large enough 
    that all squared Debye masses are positive. This condition is imposed non-
    optionally. Third, we can also optionally try to ensure that the minimum 
    temperature is large enough that the high-temperature expansion is valid. 
    At temperature  T and a 3D field point X3D, the high temperature expansion
    is considered valid if the following inequality holds 
        m(T,X3D) < (1/safetyFactor) * scaleFactor * π * T, 
    where m(T, X3D) denotes the largest field dependent boson mass and
    safetyFactor is a user-defined safety factor (which defaults to 1). In 
    order to impose the high-temperature expansion check on TMinLow, the 
    relevant options in the optional dictionary highTOptions should be 
    specified. In particular, an estimate X4DMax of the largest extent in 4D 
    field space that needs to be covered should be specified. The high 
    temperature check will then be imposed at X3D = X4DMax/√T.
    
    After setup, the validity of the high temperature expansion can also be
    checked explicitly for any point in 3D or 4D field space using the 
    functions checkHighTSafety3D and checkHighTSafety4D, respectively.
    
    During setup, the user can decide (using the options in the optional
    dictionary params3DUSInterpolOptions) to perform an interpolation of the 
    3D parameters over the range [TMinLow, TMaxHigh] for T. This can be useful
    for later speeding up calculations when repeatedly calculating the
    effective potential at the same temperature, and thereby the same 3D
    parameters, but at different field values.
           
    One final parameter requires some explanation, namely the auxParams
    parameter. This can be used to specify auxiliary parameters appearing as
    parameters in the Lagrangian, e.g. gauge charges which are not given 
    numerical values in the model implementation in (e.g.) DRalgo. All such 
    auxiliary parameters must be known when the class is initialized and 
    should be specified by a single tuple.     
    
    Attributes
    ----------
    params4DVsMu4D : callable
        A callable which returns the 4D Lagrangian parameters as an array_like
        object as a function of the 4D RG scale parameter μ4D.
    mu4DMin : float
        The smallest value of μ4D for which the 4D parameters have been 
        calculated through the RG running.
    mu4DMax : float
        The largest value of μ4D for which the 4D parameters have been 
        calculated through the RG running.
    TMinLow : float
        The lowest minimum temperature for which the model can be safely used.
    TMaxHigh : float
        The largest maximum temperature for which the model can be safely used.
    
    """

    def __init__(self, mu4DMinLow, mu4DMaxHigh, mu4DRef, params4DRef, 
                 highTOptions = {}, solve4DRGOptions = {}, 
                 params3DUSInterpolOptions = {}, scaleFactor = 1, 
                 mu3DSPreFactor = 1, auxParams = None):
        """
        Initialization method for the modelDR class.        
             
        Parameters
        ----------
        mu4DMinLow : float
            The minimum value of μ4D (initial lower limit for the RG solver)
        mu4DMaxHigh : float, optional
            The maximum value of μ4D (initial upper limit for the RG solver)
        mu4DRef : float
            The reference value of the 4D RG scale parameter μ4D
        params4DRef : array
            The values of the 4D Lagrangian parameters at the scale mu4DRef        
        highTOptions : dictionary, optional
            An optional dictionary with some parameters pertaining to checking
            that the high temperature expansion is valid. The high temperature
            expansion is considered valid at temperature T and 3D field point 
            X3D if m(T,X3D) < (1/safetyFactor) * scaleFactor * π * T, where 
            m(T,X3D) denotes the largest field dependent boson mass at 
            temperature T and field point X3D. The following parameters can be
            specified in the dictionary:
                
            adjustTMinLow : bool
                If True, then the value of TMinLow will (if needed) be adjusted 
                so that the high temperature expansion is estimated to be 
                valid for all T ≥ TMinLow. 
            X4DMax : array_like
                The parameter must be set if adjustTMinLow is set to True. 
                If so, the parameter should be a point in 4D field space which 
                provides an estimate of the maximum extent of field space that 
                needs to be covered. The value of X3D that will be used in the
                high temperature check is then X3D = X4D/√T.
            safetyFactor : float, optional
                A safety factor which appears in the high temperature check 
                (see above). Defaults to 1.
        solve4DRGOptions : dictionary, optional
            An optional dictionary with parameters to use for the solve_ivp
            method used for solving the 4D RG equations. The following 
            options can be specified in the dictionary:
            
            params4DMin : array, optional
                Optional array with minimum values for the 4D Lagrangian
                parameters. The solver will terminate when the minimum for
                at least one parameter is crossed.
            params4DMax : array, optional
                Optional array with maximum values for the 4D Lagrangian
                parameters. The solver will terminate when the maximum for
                at least one parameter is crossed.
            method: string or OdeSolver, optional
                The integration method to use when solving the RG equations. 
                Check the documentation for scipy.integrate.solve_ivp for 
                details. Defaults to RK45.
            mu4DVals: array_like, optional
                The values of μ4D where the solution will be computed. Must be
                sorted and lie within the range [mu4DMinLow, mu4DMaxHigh].
                Corresponds to the option t_eval in scipy.integrate.solve_ivp.
                Defaults to None, in which case the solver picks the values.
            options: dictionary
                Options passed to a chosen solver. Check the documentation for
                scipy.integrate.solve_ivp for details.
        params3DUSInterpolOptions : dictionary, optional
            An optional dictionary with parameters to use for interpolation of
            the 3D parameters in the ultrasoft limit. If interpolation is used
            (as defined by the flag option 'interpolate'), a cubic spline 
            interpolation, using the function scipy.interpolate.CubicSpline, 
            will be made over the T-range [TMinLow, TMaxHigh] for each of the 
            3D parameters in the ultrasoft limit. This interpolation can 
            subsequently be used when calling the functions VEff3DComplex, 
            VEff3D, VThermalComplex and VThermal. The following options can be
            specified in the dictionary:
                
            interpolate : bool, optional
                Choose whether or not the 3D parameters should be evaluated
                through interpolation. Defaults to True.
            TVals: array_like, optional
                The values of T at which the 3D parameters will be computed
                for the interpolation. The values must cover the range 
                [TMinLow, TMaxHigh]. Defaults to None, in which case the 
                values are picked over the range [TMinLow, TMaxHigh] using the
                options below.
            nVals: int, optional
                The number of values of μ to be used for the interpolation.
                Defaults to int((TMaxHigh-TMinLow)/10).            
            scale: string, optional
                The scale to be used for the distribution. Can be either 'lin'
                (linear) or 'log' (logarithmic). Defaults to 'log'.   
        scaleFactor : float, optional
            A scale factor defined by the relation μ4DH = scaleFactor * pi * T.
            Defaults to 1.
        mu3DSPreFactor : float, optional
            The prefactor in the relation between the hard-to-soft matching 
            scale μ3DS and the smallest Debye mass mDMin according to the
            relation μ3DS = mu3DSPreFactor * mDMin. Defaults to 1.
        auxParams : tuple, optional
            A tuple of any auxiliary parameters appearing in the Lagrangian 
            Defaults to None.
            
        Raises
        ------
        ValueError
            A ValueError is raised if the parameters fail some basic sanity
            checks. An absence of a ValueError does not guarantee that all of
            the parameter values are sensible.
        """
        
        if scaleFactor <= 0:
            raise ValueError("The scaleFactor must be strictly positive.")
        self.scaleFactor = scaleFactor
                      
        if mu3DSPreFactor <= 0:
            raise ValueError("The mu3DSPreFactor must be strictly positive.")
        self.mu3DSPreFactor = mu3DSPreFactor      
            
        if auxParams is not None:
            self.auxParams = auxParams
        else:
            #Simple fix to avoid having to separate self.auxParams being None
            #or not.
            self.auxParams = ()
            
        self.params4DRef = params4DRef
        self.nParams4D = len(self.params4DRef)
        
        self.highTOptions = highTOptions
        if 'adjustTMinLow' not in self.highTOptions:
            self.highTOptions['adjustTMinLow'] = False
        if self.highTOptions['adjustTMinLow'] and 'X4DMax' not in             \
           self.highTOptions:
           raise ValueError("If adjustTMinLow is set to True in highTOptions" \
                            " then X4DMax must be specified.")                       
        if 'safetyFactor' in self.highTOptions and                            \
            self.highTOptions['safetyFactor'] <= 0:
            raise ValueError("The safetyFactor must be strictly positive.")
        else:
            self.highTOptions['safetyFactor'] = 1
        
        if mu4DRef <= 0:
            raise ValueError("The reference value mu4DRef must be strictly"   \
                             "positive.")
        self.mu4DRef = mu4DRef
        
        if not (mu4DMinLow > 0 and mu4DMinLow <= self.mu4DRef):                                            
            raise ValueError("The parameter mu4DMinLow must satisfy "         \
                             "0 < mu4DMinLow <= mu4DRef.")
        self.mu4DMinLow = mu4DMinLow
        
        if mu4DMaxHigh <= self.mu4DRef:                                            
            raise ValueError("The parameter mu4DMaxHigh must satisfy "        \
                             "mu4DRef <= mu4DMaxHigh ")
                
        mDebSqMuMax = self.DebyeMassSq(mu4DMaxHigh/(self.scaleFactor * np.pi),
                                       mu4DMaxHigh, self.params4DRef, 1,
                                       *self.auxParams)
        if not np.min(mDebSqMuMax) > 0:
            raise ValueError("At least one squared Debye mass is negative at "\
                             "μ = mu4DMaxHigh. This indicates that the value "\
                             "of mu4DMax is too small.")
            
        self.mu4DMaxHigh = mu4DMaxHigh
        
        
        self.solve4DRGOptions = solve4DRGOptions
        events = []
        if 'params4DMin' in self.solve4DRGOptions:
            for i in range(0,self.nParams4D):
                if self.solve4DRGOptions['params4DMin'][i] > -np.inf:
                    events += [lambda t,y,*args,_index=i: y[_index] - 
                               self.solve4DRGOptions['params4DMin'][_index]]
                    events[-1].terminal = True
                    events[-1].direction = -1
                    if events[-1](self.mu4DRef, self.params4DRef) <= 0:
                        raise ValueError("The entry {} (at index i = {}) in " \
                                         "params4DRef must be greater than "  \
                                         "the corresponding minimum {} in "   \
                                         "params4DMin".format(
                                         self.params4DRef[i], i, 
                                         self.solve4DRGOptions['params4DMin']
                                         [i]))
        if 'params4DMax' in self.solve4DRGOptions:
            for i in range(0,self.nParams4D):
                if self.solve4DRGOptions['params4DMax'][i] < np.inf:
                    events += [lambda t,y,*args,_index=i: y[_index] - 
                               self.solve4DRGOptions['params4DMax'][_index]]
                    events[-1].terminal = True
                    events[-1].direction = +1
                    if events[-1](self.mu4DRef, self.params4DRef) >= 0:
                        raise ValueError("The entry {} (at index i = {}) in " \
                                         "params4DRef must be lower than "    \
                                         "the corresponding maximum {} in "   \
                                         "params4DMax".format(
                                         self.params4DRef[i], i, 
                                         self.solve4DRGOptions['params4DMax']
                                         [i])) 

        if 'method' not in self.solve4DRGOptions:
            self.solve4DRGOptions['method'] = 'RK45'
        if 'mu4DVals' not in self.solve4DRGOptions:
            self.solve4DRGOptions['mu4DVals'] = None
        elif (self.solve4DRGOptions['mu4DVals'][0] < self.muMinLow) or        \
             (self.solve4DRGOptions['mu4DVals'][-1] > self.muMax):
                 raise ValueError("The mu4DVals must fit in the range "       \
                                  "[mu4DMin, mu4DMax]")
        if 'options' not in self.solve4DRGOptions:
            self.solve4DRGOptions['options'] = {}
            
        params4DVsMu4DSol =                                                   \
            solve_intermediate_vp(self.RGFuncs4D, (self.mu4DMinLow, 
                                  self.mu4DRef, self.mu4DMaxHigh), 
                                  self.params4DRef, 
                                  method = self.solve4DRGOptions['method'],
                                  t_eval = self.solve4DRGOptions['mu4DVals'],
                                  dense_output = True, events = events, 
                                  args = self.auxParams,
                                  **self.solve4DRGOptions['options']) 

        self.mu4DMin = params4DVsMu4DSol.t[0]
        self.mu4DMax = params4DVsMu4DSol.t[-1]
        
        #Awkward way to also allow [[*]] as input
        self.params4DVsMu4D = np.vectorize(params4DVsMu4DSol.sol,
                                           signature='()->(n)')
        
        
        self.TMaxHigh = self.mu4DMax / (self.scaleFactor * np.pi)
                
        #Event function to detect when the squared Debye masses go negative
        def Debye_event(T):
            mu4D = self.scaleFactor * np.pi * T
            params4D = self.params4DVsMu4D(mu4D)
            mDebSqMu = self.DebyeMassSq(T, mu4D, params4D, 1, *self.auxParams)
            return np.min(mDebSqMu)
        
        a = self.mu4DMin / (self.scaleFactor * np.pi)
        print("mu4DMinLow: ",mu4DMinLow)
        print("mu4DMin: ",self.mu4DMin)
        print("a: ",a)
        b = self.TMaxHigh
        for i in range(0,15):
            mid = 0.5*(a+b)
            if Debye_event(mid) > 0:
                b = mid
            else:
                a = mid
        self.TMinLow = b 
        print("TMinLow: ",self.TMinLow)
        print("Debye event: ",Debye_event(self.TMinLow))
          
        if highTOptions['adjustTMinLow']:            
            #Event function to detect when high-T expansion breaks down
            def highT_event(T):
                mu4D = self.scaleFactor * np.pi * T
                params4D = self.params4DVsMu4D(mu4D)
                # We have to calculate mu3S "manually" here in order to allow 
                # for a simplified signature of the mu3DS function
                mDMin = np.min(self.DebyeMassSq(T, mu4D, params4D, 1,
                                                *self.auxParams))
                mu3DS = self.mu3DSPreFactor * mDMin
                params3DUS = self.DRStep(T, mu4D, mu3DS, params4D, 1, 
                                       *self.auxParams) 
                X3D = self.highTOptions['X4DMax']/np.sqrt(T)
                mVectSqMu = np.real(self.vectMassSq3DUSLO(X3D, params3DUS, 
                                                          *self.auxParams))
                mScalSqMu = np.real(self.scalMassSq3DUSLO(X3D, params3DUS, 
                                                          *self.auxParams))
                return (mu4D / self.highTOptions['safetyFactor']) ** 2 -          \
                       max(np.max(mVectSqMu), np.max(mScalSqMu))
                   
            if highT_event(self.TMaxHigh) <= 0:            
                raise ValueError("It appears that the high temperature "      \
                                 "expansion is not valid at mu4DMax for the " \
                                 "given value of X4DMax. This indicates that "\
                                 "mu4DMax is too low, that X4DMax is too "    \
                                 "high or possibly that the params4DMin or "  \
                                 "params4DMax constraints are too tight.")

            a = self.TMinLow
            b = self.TMaxHigh
            for i in range(0,15):
                mid = 0.5*(a+b)
                if highT_event(mid) > 0:
                    b = mid
                else:
                    a = mid
            self.TMinLow = b
            
            
        #Awkward way to find number of 3D US parameters
        T = self.TMinLow 
        mu4D = self.scaleFactor * np.pi * T
        mu3DS = self.mu3DS(T, 1)
        params4D = self.params4DVsMu4D(mu4D)
        params3DUS = self.DRStep(T, mu4D, mu3DS, params4D, 1, *self.auxParams) 
        self.nParams3D = len(params3DUS) 
                        
        self.params3DUSInterpolOptions = params3DUSInterpolOptions
        if 'interpolate' not in self.params3DUSInterpolOptions:
            self.params3DUSInterpolOptions['interpolate'] = False #CHANGE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        if 'nVals' not in self.params3DUSInterpolOptions:
            self.params3DUSInterpolOptions['nVals'] = int((self.TMaxHigh - 
                                                         self.TMinLow)/10)
        if 'scale' in self.params3DUSInterpolOptions:
            if not (self.params3DUSInterpolOptions['scale'] == 'log' or       \
                    self.params3DUSInterpolOptions['scale'] == 'lin'):
                raise ValueError("The scale parameter must be \'log\' or "    \
                                 "\'lin\' if it is set.")
        else:
            self.params3DUSInterpolOptions['scale'] = 'log'
        if 'TVals' in self.params3DUSInterpolOptions:
            TVals = self.params3DUSInterpolOptions['TVals']
            TVals = TVals[TVals >= self.TMinLow]
            TVals = TVals[TVals <= self.TMaxHigh]
            if TVals.size < 2 and                                             \
               self.params3DUSInterpolOptions['interpolate']:
                raise ValueError("The TVals array in params3DUSInterpol"      \
                                 "Options must have at least two points in "  \
                                 "the range [{},{}]".format(self.TMinLow,
                                                            self.TMaxHigh))
            self.params3DUSInterpolOptions['TVals'] = TVals
        else:
            if self.params3DUSInterpolOptions['scale'] == 'lin':
                TVals = np.linspace(self.TMinLow, self.TMaxHigh, 
                                    self.params3DUSInterpolOptions['nVals'])
            else:
                TVals = np.logspace(np.log10(self.TMinLow), 
                                    np.log10(self.TMaxHigh), 
                                    self.params3DUSInterpolOptions['nVals'])
            self.params3DUSInterpolOptions['TVals'] = TVals

        if self.params3DUSInterpolOptions['interpolate']:
            T = self.params3DUSInterpolOptions['TVals']            
            params3DUSLO = np.empty((T.size,self.nParams3D))
            params3DUSNLO = np.empty((T.size,self.nParams3D))
            for i in range(0, T.size):
                mu4DH = self.scaleFactor * np.pi * T[i]
                params4D = self.params4DVsMu4D(mu4DH)
                mu3DSLO = self.mu3DS(T[i], order = 0)
                mu3DSNLO = self.mu3DS(T[i], order = 1)
                params3DUSLO[i] = self.DRStep(T[i], mu4DH, mu3DSLO, params4D,
                                              0, *self.auxParams)
                params3DUSNLO[i] = self.DRStep(T[i], mu4DH, mu3DSNLO, params4D,
                                               1, *self.auxParams) 

            self.params3DUSVsTInterpolLO = CubicSpline(T, params3DUSLO)
            #Awkward way to also allow [[*]] as input
            self.params3DUSVsTInterpolLO =                                    \
                np.vectorize(self.params3DUSVsTInterpolLO,
                             signature='()->(n)')
            self.params3DUSVsTInterpolNLO = CubicSpline(T, params3DUSNLO)
            #Awkward way to also allow [[*]] as input
            self.params3DUSVsTInterpolNLO =                                   \
                np.vectorize(self.params3DUSVsTInterpolNLO,
                             signature='()->(n)')
        else:
            self.params3DUSVsMuInterpolLO = None
            self.params3DUSVsMuInterpolNLO = None

    
    # @abstractmethod
    # def _params4DNames(self, indices):
    #     """
    #     Returns the 4D parameter names at given indices.
        
    #     This is an auxiliary function which simply returns the 4D parameter 
    #     names at given parameter indices. 

    #     Parameters
    #     ----------
    #     indices : array_like
    #         An array_like object with the indices of the sought 4D parameter
    #         names.

    #     Returns
    #     -------
    #     The 4D parameter names at the given indices as an array_like object
    #     """
    #     pass
        

    # @abstractmethod
    # def _params3DNames(self, indices, limit):
    #     """
    #     Returns the 3D parameter names at given indices.
        
    #     This is an auxiliary function which simply returns the 3D parameter 
    #     names at given parameter indices. Parameters names can be either in
    #     the soft limit (limit='S') or ultrasoft limit (limit='US'), as 
    #     controlled by the parameter limit.

    #     Parameters
    #     ----------
    #     indices : array_like
    #         An array_like object with the indices of the sought 4D parameter
    #         names.
    #     limit : string
    #         Specifies if the 3D names should be in the soft (limit='S') or
    #         ultrasoft (limit='US' limit).

    #     Returns
    #     -------
    #     The 3D parameter names at the given indices as an array_like object
    #     """
    #     pass


    # @abstractmethod
    # def _params4DIndices(self, names):
    #     """
    #     Returns the 4D parameter indices at given parameter names.
        
    #     This is an auxiliary function which simply returns the indices of the 
    #     4D parameters at given parameter names. 

    #     Parameters
    #     ----------
    #     names : array_like
    #         An array_like object with the names of the sought 4D parameter
    #         indices.

    #     Returns
    #     -------
    #     The 4D parameter indices at the given names as an array_like object
    #     """
    #     pass


    # @abstractmethod
    # def _params3DIndices(self, names):
    #     """
    #     Returns the 3D parameter indices at given parameter names.
        
    #     This is an auxiliary function which simply returns the indices of the 
    #     3D parameters at given parameter names. Parameters names can be either
    #     in the soft limit or ultrasoft limit.

    #     Parameters
    #     ----------
    #     names : array_like
    #         An array_like object with the names of the sought 3D parameter
    #         indices.

    #     Returns
    #     -------
    #     The 3D parameter indices at the given names as an array_like object
    #     """
    #     pass
        
        
    @abstractmethod
    def RGFuncs4D(self, mu4D, params4D, *auxParams):
        """
        Returns the RHS of the RG-equation dp/dμ4D = β(p)/μ4D.

        This function returns an array_like object with the β-functions for 
        the 4D-parameters divided by the RG-scale μ4D, i.e. the right-hand 
        side in the RG-equation dp/dμ4D = β(p)/μ4D, where p denotes the array 
        of 4D-parameters.

        Parameters
        ----------
        mu4D : float
            The 4D RG-scale parameter (i.e. μ4D) 
        params4D : array
            Array of the 4D-parameters at scale μ4D
        auxParams : tuple
            Tuple of auxiliary parameters

        Returns
        ----------
        RHS of the RG-equation dp/dμ4D = β(p)/μ4D as an array_like object
        """
        pass
    
    
    @abstractmethod    
    def DebyeMassSq(self, T, mu4DH, params4D, order, *auxParams):
        """
        Returns the squared Debye masses.

        This function is used to calculate the squared Debye masses as a 
        function of the temperature T, the hard matching scale mu4DH (μ4DH) 
        and the values of the 4D-parameters at scale μ4DH. The masses can be 
        calculated at LO or NLO (order = 0 and 1, respectively).

        Parameters
        ----------
        T : float
            The temperature 
        mu4DH : float
            The hard matching scale (i.e. μ4DH) 
        params4D : array
            Array of the 4D-parameters at scale μ4DH   
        order : int
            The order at which the Debye masses are calculated (0 or 1)
        auxParams : tuple
            Tuple of auxiliary parameters

        Returns
        ----------
        The squared Debye masses as an array_like object
        """
        pass
    
        
    def mu3DS(self, T, order):
        """
        Returns the hard-to-soft matching scale.

        This function is used to calculate the hard-to-soft matching μ3DS as a 
        function of the temperature T, the hard matching scale mu4DH (μ4DH) 
        and the values of the 4D-parameters at scale μ4DH. The value of μ3DS 
        is calculated as self.mu3DSPreFactor * mDMin, where  mDMin denotes the
        smallest Debye mass, calculated at the given order. At LO, mDMin is 
        approximately g*T, where g denotes the smallest gauge coupling.
        
        Subclasses may override this method to investigate the impact of
        different choices of μ3DS. The default implementation, however, gives 
        a reasonable choice. One can also assess the impact of the value
        of μ3DS by varying the mu3DSPreFactor (which defaults to 1), as 
        defined above.

        Parameters
        ----------
        mu4DH : float
            The hard matching scale (i.e. μ4DH) 
        order : int
            The order at which the Debye masses are calculated (0 or 1)
        
        Returns
        ----------
        The hard-to-soft matching scale μ3DS 
        """
        mu4DH = self.scaleFactor * np.pi * T 
        params4D = self.params4DVsMu4D(mu4DH).reshape(self.nParams4D,)
        mDMin = np.min(self.DebyeMassSq(T, mu4DH, params4D, order,
                                        *self.auxParams))
        return self.mu3DSPreFactor * np.sqrt(mDMin)

 
    @abstractmethod
    def DRStep(self, T, mu4DH, mu3DS, params4D, order, *auxParams):
        """
        Returns the 3D-parameters in the ultrasoft limit.

        This function is used to perform the dimensional reduction to the 
        ultrasoft limit. Thus, it calculates the values of the 3D parameters 
        in the ultrasoft limit as a function of the temperature T, the hard 
        matching scale mu4DH (μ4DH), the hard-to-soft matching scale mu3DS 
        (μ3DS) and the values of the 4D-parameters at scale μ4DH. 

        Parameters
        ----------
        T : float 
            The temperature 
        mu4DH : float
            The hard matching scale (i.e. μ4DH) 
        mu3DS : float
            The hard-to-soft matching scale (i.e. μ3DS) 
        params4D : array
            Array of the 4D-parameters at scale μ4DH
        order : int
            The order at which the dimensional reduction is performed (0 or 1)
        auxParams : tuple
            Tuple of auxiliary parameters

        Returns
        ----------
        Array of the 3D parameters in the ultrasoft limit
        """
        pass
        
    #Add limit as option S or US or split into separate functions??
    def params3DUSVsT(self, T, order, interpolate):
        """
        Returns the 3D-parameters in the ultrasoft limit.

        This function calculates the value of the 3D parameters in the 
        ultrasoft limit as a function of temperature T. The 3D parameters can 
        be calculated by interpolation (if that optional was enabled upon 
        instantiation) or exactly.

        Parameters
        ----------
        T : float
            The temperature
        order : int
            The order at which the 3D parameters are calculated (0 or 1).
        interpolate : bool
            Boolean flag to choose whether or not the 3D parameters should be
            calculated by interpolation (if possible)

        Returns
        ----------
        Array object of the 3D parameters in the ultrasoft limit
        """
        if interpolate and self.params3DUSInterpolOptions['interpolate']:
            if order == 0:
                return self.params3DUSVsTInterpolLO(T).reshape(self.nParams3D,)
            else:
                return                                                        \
                    self.params3DUSVsTInterpolNLO(T).reshape(self.nParams3D,)
        else:
            mu4DH = self.scaleFactor * np.pi * T
            params4D = self.params4DVsMu4D(mu4DH).reshape(self.nParams4D,)           
            mu3DS = self.mu3DS(T, order)                     
            params3DUS = self.DRStep(T, mu4DH, mu3DS, params4D, order, 
                                   *self.auxParams)
            return np.array(params3DUS) #Array conversin maybe not needed

    
    @abstractmethod
    def VEff3DLO(self, X3D, params3DUS, *auxParams):
        """
        Returns the 3D effective potential at LO (tree-level).
        
        This function calculates the 3D effective potential at LO in terms of 
        the vevs X3D and the 3D parameters in the ultrasoft limit. Note that 
        the vevs X3D are assumed to live in three-dimensional space, so that 
        they have mass dimension 1/2. The relation between the three-
        dimensional vevs X3D and the four-dimensional vevs X4D is given by 
        X3D = X4D/√T, where T denotes the temperature. 

        Parameters
        ----------
        X3D : array_like
            The 3D vevs as either a single point or an array of points 
        params3DUS : array
            Array of the 3D-parameters in the ultrasoft limit
        auxParams : tuple
            Tuple of auxiliary parameters

        Returns
        ----------
        The 3D effective potential at LO
        """
        pass


    @abstractmethod    
    def vectMassSq3DUSLO(self, X3D, params3DUS, *auxParams):
        """
        Returns the 3D field dependent vector boson masses.

        This function is used to calculate the 3D field dependent vector boson
        squared masses in the ultrasoft limit in terms of the vevs X3D and 
        the 3D parameters in the ultrasoft limit. The masses are calculated at
        LO, i.e. from mass matrix derived from the LO potential VEff3DLO.

        Parameters
        ----------
        X3D : array_like
            The 3D vevs as either a single point or an array of points 
        params3DUS : array
            Array object of the 3D-parameters in the ultrasoft limit
        auxParams : tuple
            Tuple of auxiliary parameters

        Returns
        ----------
        The 3D field dependent vector boson masses as an array
        """
        pass
    

    @abstractmethod    
    def scalMassSq3DUSLO(self, X3D, params3D, *auxParams):
        """
        Returns the 3D field dependent scalar boson masses.

        This function is used to calculate the 3D field dependent scalar boson
        squared masses in the ultrasoft limit in terms of the vevs X3D and 
        the 3D parameters in the ultrasoft limit. The masses are calculated at
        LO, i.e. from mass matrix derived from the LO potential VEff3DLO.

        Parameters
        ----------
        X3D : array_like
            The 3D vevs as either a single point or an array of points 
        params3DUS : array
            Array of the 3D-parameters in the ultrasoft limit
        auxParams : tuple
            Tuple of auxiliary parameters

        Returns
        ----------
        The 3D field dependent scalar boson masses as an array_like object
        """
        pass    


    def VEff3DNLO(self, X3D, params3DUS):
        """
        Returns the 3D effective potential at NLO in Landau gauge.

        This function calculates the 3D effective potential at NLO in Landau
        gauge in terms of the vevs X3D and the 3D parameters in the ultrasoft 
        limit. Note that the vevs X3D are assumed to live in three-
        dimensional space, so that they have mass dimension 1/2. The relation 
        between the three-dimensional vevs X3D and the four-dimensional vevs 
        X4D is X3D = X4D/√T, where T denotes the temperature. 

        Parameters
        ----------
        X3D : array_like
            The 3D vevs as either a single point or an array of points 
        params3DUS : array
            Array of the 3D-parameters in the ultrasoft limit
        mu3DS : float
            The hard-to-soft matching scale (i.e. μ3DS)

        Returns
        ----------
        The 3D effective potential at NLO
        """
        mVSq = self.vectMassSq3DUSLO(X3D, params3DUS, *self.auxParams)
        mSSq = self.scalMassSq3DUSLO(X3D, params3DUS, *self.auxParams)
        return self.VEff3DLO(X3D, params3DUS, *self.auxParams) +              \
            (-2/(12*np.pi)) * np.sum(np.power(mVSq,3/2), axis = 0) +          \
            (-1/(12*np.pi)) * np.sum(np.power(mSSq,3/2), axis = 0)  
            
            
    def VEff3DNLOComplex(self, X3D, params3DUS):
        """
        Returns the 3D effective potential at NLO in Landau gauge.

        This function calculates the 3D effective potential at NLO in Landau
        gauge in terms of the vevs X3D and the 3D parameters in the ultrasoft 
        limit. The value of the potential is returned as a complex number and
        may have a nonzero imaginary part. Note that the vevs X3D are assumed 
        to live in three-dimensional space, so that they have mass dimension 
        1/2. The relation between the three-dimensional vevs X3D and the four-
        dimensional vevs X4D is X3D = X4D/√T, where T denotes the temperature. 

        Parameters
        ----------
        X3D : array_like
            The 3D vevs as either a single point or an array of points 
        params3DUS : array
            Array of the 3D-parameters in the ultrasoft limit
        mu3DS : float
            The hard-to-soft matching scale (i.e. μ3DS)

        Returns
        ----------
        The 3D effective potential at NLO as a complex number
        """
        params3DUS_c = params3DUS.astype(complex)
        mVSq = self.vectMassSq3DUSLO(X3D, params3DUS_c,
                                     *self.auxParams).astype(complex)
        mSSq = self.scalMassSq3DUSLO(X3D, params3DUS_c,
                                     *self.auxParams).astype(complex)
        return self.VEff3DLO(X3D, params3DUS, *self.auxParams) +              \
            (-2/(12*np.pi)) * np.sum(np.power(mVSq,3/2), axis = 0) +          \
            (-1/(12*np.pi)) * np.sum(np.power(mSSq,3/2), axis = 0)             
       
    
    def VEffThermalComplex(self, X4D, T, orderDR, orderVEff, interpolate):
        """
        The thermal effective potentiat at LO or NLO in Landau gauge.
        
        This function calculates the thermal effective potential, at LO or NLO
        in Landau gauge, for the given 4D field values and the given 
        temperature. The value of the potential is returned as a complex
        number and may have a nonzero imaginary part. More specifically, the 
        function returns the value of T*VEff3D, where VEff3D is the 3D 
        effective potential at the given temperature and with the field values
        X3D = X4D/√T. Thus, the return value has mass dimension 4.
        
        Parameters
        ----------
        X4D : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
        orderDR : int
            The order at which the dimensional reduction (i.e. the mathcing)
            is performed (0 or 1).
        orderVEff : int
            The order at which the potential is calculated (0 or 1).
        interpolate : bool
            Boolean flag to choose whether or not the 3D parameters should be
            calculated by interpolation (if possible, i.e. if the option
            params3DInterpolOptions['interpolate'] was set to True).
            
        Returns
        -------
        The value of the effective potential as a complex number  
        """
        #Ensure that computations are carried out in the complex domain        
        params3DUS = self.params3DUSVsT(T, orderDR,
                                        interpolate).astype(complex) 
        X3D = X4D / np.sqrt(T)
        if orderVEff == 0:
            VEff3D = self.VEff3DLO(X3D, params3DUS, *self.auxParams)
        else:
            VEff3D = self.VEff3DNLOComplex(X3D, params3DUS)
        return T * VEff3D
        

    def VEffThermal(self, X4D, T, orderDR, orderVEff, interpolate):
        """
        The thermal effective potentiat at LO or NLO in Landau gauge.
        
        This function calculates the thermal effective potential, at LO or NLO
        in Landau gauge, for the given 4D field values and the given 
        temperature. More specifically, the function returns the value of 
        T*VEff3D, where VEff3D is the 3D effective potential at the given 
        temperature and with the field values X3D = X4D/√T. Thus, the return 
        value has mass dimension 4.
        
        Parameters
        ----------
        X4D : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
        orderDR : int
            The order at which the dimensional reduction (i.e. the mathcing)
            is performed (0 or 1).
        orderVEff : int
            The order at which the potential is calculated (0 or 1).
        interpolate : bool
            Boolean flag to choose whether or not the 3D parameters should be
            calculated by interpolation (if possible, i.e. if the option
            params3DInterpolOptions['interpolate'] was set to True).
            
        Returns
        -------
        The real part of the effective potential
        """
        # print("")
        # print("X4D: ",X4D)
        # print("T: ",T)
        params3DUS = self.params3DUSVsT(T, orderDR,
                                        interpolate).astype(complex)
        X3D = X4D / np.sqrt(T)
        if orderVEff == 0:
            VEff3D = self.VEff3DLO(X3D, params3DUS, *self.auxParams)
        else:
            VEff3D = self.VEff3DNLOComplex(X3D, params3DUS)
        return T * np.real(VEff3D)


    def checkHighTSafety3D(self, X3D, T, orderDR, interpolate, safetyFactor):
        """
        Checks if the high temperature expansion is ok (in 3D).
        
        This function is used to estimate whether the high temperature 
        expansion is safe at the given 3D field value X3D and at the given 
        temperature T. To do so, it checks if all the field dependent vector
        boson and scalar masses m(X3D,T) satisfy the following inequality: 
            m(X3D,T) < (1/safetyFactor) * μ4DH 
        where μ4DH = scaleFactor * π * T. The function returns a tuple where
        the first entry is a (array_like of) bool, showing whether the
        above inequality holds, and where the second entry is a (array_like 
        of) float with the ratio 
            [m(X3D,T) - (1/safetyFactor) * μ4DH] / [(1/safetyFactor) * μ4DH]
        for the largest boson mass m(X3D,T). Hence, a positive value of this
        ratio indicates that the high temperature expansion is invalid.

        Parameters
        ----------
        X3D : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
        orderDR : int
            The order at which the dimensional reduction (i.e. the mathcing)
            is performed (0 or 1).
        interpolate : bool
            Boolean flag to choose whether or not the 3D parameters should be
            calculated by interpolation (if possible, i.e. if the option
            params3DInterpolOptions['interpolate'] was set to True).
        safetyFactor : float
            The safety factor in the inequality which controls the validity
            of the high temperature expansion.

        Returns
        -------
        tuple
            A tuple where the first entry shows if the high teperature 
            expansion is valid and the second entry shows (for positive 
            values) by how much the expansion is violated.

        """
        mu4DH = self.scaleFactor * np.pi * T
        mu4DH = np.asarray(mu4DH)
        params3DUS = self.params3DUSVsT(T, orderDR, interpolate)      
        mVSqMax = np.max(self.vectMassSq3DUSLO(X3D, params3DUS, 
                                               *self.auxParams))
        mSSqMax = np.max(self.scalMassSq3DUSLO(X3D, params3DUS, 
                                               *self.auxParams))
        mMax = np.sqrt(np.max((mVSqMax, mSSqMax)))
        boolEntry = np.all(mMax < mu4DH[...,None]/safetyFactor, axis = -1)
        ratioEntry = np.max((mMax - (mu4DH[...,None]/safetyFactor)) /         \
                            (mu4DH[...,None]/safetyFactor), axis = -1)
        return boolEntry, ratioEntry

        
    def checkHighTSafety4D(self, X4D, T, orderDR, interpolate, safetyFactor):
        """
        Checks if the high temperature expansion is ok (in 4D).
        
        This function is used to estimate whether the high temperature 
        expansion is safe at the given 4D field value X4D and at the given 
        temperature T. To do so, it checks if all the field dependent vector
        boson and scalar masses m(X3D,T) satisfy the following inequality: 
            m(X3D,T) < (1/safetyFactor) * μ4DH 
        where the 3D field valuex X3D are related to the 4D field values by
        X3D = X4D/√T and where μ4DH = scaleFactor * π * T. The function 
        returns a tuple where the first entry is a (array_like of) bool, 
        showing whether the above inequality holds, and where the second entry
        is a (array_like of) float with the ratio 
            [m(X3D,T) - (1/safetyFactor) * μ4DH] / [(1/safetyFactor) * μ4DH]
        for the largest boson mass m(X3D,T). Hence, a positive value of this
        ratio indicates that the high temperature expansion is invalid.

        Parameters
        ----------
        X4D : array_like
            Field value(s).
            Either a single point (with length `Ndim`), or an array of points.
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
        orderDR : int
            The order at which the dimensional reduction (i.e. the mathcing)
            is performed (0 or 1).
        interpolate : bool, optional
            Boolean flag to choose whether or not the 3D parameters should be
            calculated by interpolation (if possible, i.e. if the option
            params3DInterpolOptions['interpolate'] was set to True).
        safetyFactor : float
            The safety factor in the inequality which controls the validity
            of the high temperature expansion.

        Returns
        -------
        tuple
            A tuple where the first entry shows if the high teperature 
            expansion is valid and the second entry shows (for positive 
            values) by how much the expansion is violated.

        """
        X3D = X4D / np.sqrt(T)
        return self.checkHighTSafety3D(X3D, T, orderDR, interpolate, 
                                       safetyFactor)


    #NOTE: Possibly, mu4DH is not needed below!
    @abstractmethod
    def pressure3DUS(self, T, mu4DH, mu3DS, params4D, order, *auxParams):
        """
        Returns the pressure in the 3D effective theory in the ultrasoft limit.

        This function is used to calculate the pressure in the 3D effective
        theory in the ultrasoft limit, in terms of the temperature T, the hard 
        matching scale mu4DH (μ4DH), the hard-to-soft matching scale mu3DS 
        (μ3DS) and the values of the 4D-parameters at scale μ4DH. 

        Parameters
        ----------
        T : float 
            The temperature 
        mu4DH : float
            The hard matching scale (i.e. μ4DH) 
        mu3DS : float
            The hard-to-soft matching scale (i.e. μ3DS) 
        params4D : array
            Array of the 4D-parameters at scale μ4DH
        order : int
            The order at which the dimensional reduction is performed (0 or 1)
        auxParams : tuple
            Tuple of auxiliary parameters

        Returns
        ----------
        The pressure in the 3D effective theory in the ultrasoft limit
        """
        pass   
    
    
    def pressure(self, T, order, interpolate):
        """
        Returns the pressure in the 4D theory.

        This function is used to calculate the pressure in the 4D theory.
        The pressure p4D in the 4D theory is related to the pressure p3D in
        the 3D theory by p4D = T * p3D. The pressure can be calculated at LO 
        or NLO (order = 0 and 1, respectively)

        Parameters
        ----------
        T : float or array_like
            The temperature. The shapes of `X` and `T`
            should be such that ``X.shape[:-1]`` and ``T.shape`` are
            broadcastable (that is, ``X[...,0]*T`` is a valid operation).
        order : int
            The order at which the pressure is calculated
        interpolate : bool
            Boolean flag to choose whether or not the 3D parameters should be
            calculated by interpolation (if possible, i.e. if the option
            params3DInterpolOptions['interpolate'] was set to True).

        Returns
        ----------
        The pressure in the 4D theory
        """
        params3DUS = self.params3DVsT(T, order, interpolate)  
        return T * self.pressure3DUS(params3DUS, order, *self.auxParams)
    
    
    def plotParams4D(self, paramSelection, mu4DMin = None, mu4DMax = None,
                     num = 50, yMin = None, yMax = None, xscale = "linear",
                     yscale = "linear", xlabel = 'μ4D/GeV',
                     ylabel = '4D parameter', title = None):
        """
        Plots (a selection of) the 4D parameters vs. the 4D scale μ4D.
        
        This function plots a selection of the 4D Lagrangian parameters vs.
        the 4D scale μ4D in a single graph. The selection of the 4D parameters
        is specified by the parameter paramSelection, and must be given either
        as a selection of indices (if the type is int) or as a selection of 
        names (if the type is str). In the former case, parameter names for
        the legend will be taken from the function '_params4DNames'. In the 
        latter case, the actual parameters will be determined through the 
        function '_params4DIndices'. 
        
        Note that no check is being made if the selection of parameters is 
        compatible or not. For example, choosing a dimensionless coupling 
        together with a dimensionful mass parameter will give a plot, even 
        though it is not necessarily a sensible one.
        
        The plot will use the following styles: 'b','g','r','c','m','y','k',
        'b--','g--','r--','c--','m--','y--','k--','b-.','g-.','r-.','c-.',
        'm-.','y-.','k-.','b:','g:','r:','c:','m:','y:','k:'. Thus, the
        selection can contain at most 28 parameters.

        Parameters
        ----------
        paramSelection : list
            A list with either the indices or the names of the selection of 
            the 4D parameters to be plotted. Must not contain more than 28 
            elements.
        mu4DMin : float, optional
            The minimum value of μ4D for the plot. Defaults to None, which
            means that the value self.mu4DMin will be used.
        mu4DMax : float, optional
            The maximum value of μ4D for the plot. Defaults to None, which
            means that the value self.mu4DMax will be used.
        num : int, optional
            The number of values of μ4D to use for the plot. Defaults to 50.
        yMin : float, optional
            The minimum y-value for the plot. Defaults to None, in which case
            the minimum is determined from the range of the plotted parameter 
            values.
        yMax : float, optional
            The maximum y-value for the plot. Defaults to None, in which case
            the maximum is determined from the range of the plotted parameter
            values.
        xscale : string, optional
            The xscale (i.e. μ4D scale) for the plot. Defaults to "linear". 
            See the options in matplotlib.pyplot.xscale. Defaults to "linear".
        yscale : string, optional
            The yscale for the plot. Defaults to "linear". See the options in 
            matplotlib.pyplot.yscale.
        title : string, optional
            The title to use for the plot. Defaults to None, in which case a
            default descriptive title based on the parameter names will be 
            used. In order not to print a title, use the empty string.
        """
        if len(paramSelection) > 28:
            raise ValueError("The parameter paramSelection cannot have more " \
                             "than 28 elements.")
        if all(isinstance(n, int) for n in paramSelection):
            indices = paramSelection
            paramNames = self._params4DNames(indices)
        elif all(isinstance(n, str) for n in paramSelection):
            indices = self._params4DIndices(paramSelection)
            paramNames = paramSelection
        else:
            raise ValueError("The parameter paramSelection must be a list "   \
                             "of either int or str.")
        if mu4DMin == None:
            mu4DMin = self.mu4DMin
        if mu4DMax == None:
            mu4DMax = self.mu4DMax            
        muArr = np.linspace(mu4DMin, mu4DMax, num)
        
        styles = ['b','g','r','c','m','y','k','b--','g--','r--','c--','m--',
                  'y--','k--','b-.','g-.','r-.','c-.','m-.','y-.','k-.','b:',
                  'g:','r:','c:','m:','y:','k:']
        
        for i in range(0,len(indices)):
            pArr = np.array([self.params4DVsMu4D(mu)[indices[i]]
                             for mu in muArr])
            plt.plot(muArr, pArr, styles[i], label = paramNames[i])
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        plt.xscale(xscale)
        plt.yscale(yscale)
        if yMin is not None:
            plt.ylim(bottom = yMin)
        if yMax is not None:
            plt.ylim(top = yMax)
            
        if title != "": #Use a title
            if title is None: #Use default title
                title = "The 4D parameters " + ' '.join(paramNames) +         \
                        " as function of the 4D RG scale μ4D"
            plt.title(title)
        plt.legend()
        plt.show()
        
        
    # def plotParams3D(self, paramSelection, interpolate = True, TMin = None,
    #                  TMax = None, num = 50, yMin = None, yMax = None,
    #                  xscale = "linear", yscale = "linear", xlabel = 'T/GeV',
    #                  ylabel = '3D parameter', title = None):
    #     """
    #     Plots (a selection of) the 3D parameters vs. the temperature T.
        
    #     This function plots a selection of the 3D parameters vs. the 
    #     temperature T in a single graph. The selection of the 3D parameters
    #     is specified by the parameter paramSelection, and is given by a 
    #     selection of names. Each name should be the name of a 3D parameter
    #     in the soft or ultrasoft limit (corresponding to the options 'S' and
    #     'US', respectively, in the function '_params3DIndices'). Each name 
    #     could be appended with "_LO" or "_NLO" to indicate the order at which
    #     the parameter should be calculated (corresponding to order = 0 and
    #     order = 1, respectively, in the 'DRStep' function). If not specified,
    #     the order will be taken to be NLO. 
        
    #     Note that no check is being made if the selection of parameters is 
    #     compatible or not. For example, choosing a coupling with mass 
    #     dimension 1 together with a mass parameter with mass dimension 2 will
    #     give a plot, even though it is not necessarily a sensible one.
        
    #     The plot will use the following styles: 'b','g','r','c','m','y','k',
    #     'b--','g--','r--','c--','m--','y--','k--','b-.','g-.','r-.','c-.',
    #     'm-.','y-.','k-.','b:','g:','r:','c:','m:','y:','k:'. Thus, the
    #     selection can contain at most 28 parameters.

    #     Parameters
    #     ----------
    #     paramSelection : list
    #         A list with the names of the selection of the 3D parameters to be
    #         plotted. Must not contain more than 28 elements.
    #     interpolate : bool, default
    #         Controls whether the 3D parameters are calculated by interpolation
    #         or not. Defaults to True.
    #     TMin : float, optional
    #         The minimum value of T for the plot. Defaults to None, which
    #         means that the value self.TMinLow will be used.
    #     TMax : float, optional
    #         The maximum value of T for the plot. Defaults to None, which
    #         means that the value self.TMaxHigh will be used.
    #     num : int, optional
    #         The number of values of T to use for the plot. Defaults to 50.
    #     yMin : float, optional
    #         The minimum y-value for the plot. Defaults to None, in which case
    #         the minimum is determined from the range of the plotted parameter 
    #         values.
    #     yMax : float, optional
    #         The maximum y-value for the plot. Defaults to None, in which case
    #         the maximum is determined from the range of the plotted parameter
    #         values.
    #     xscale : string, optional
    #         The xscale (i.e. T scale) for the plot. Defaults to "linear". 
    #         See the options in matplotlib.pyplot.xscale. Defaults to "linear".
    #     yscale : string, optional
    #         The yscale for the plot. Defaults to "linear". See the options in 
    #         matplotlib.pyplot.yscale.
    #     title : string, optional
    #         The title to use for the plot. Defaults to None, in which case a
    #         default descriptive title based on the parameter names will be 
    #         used. In order not to print a title, use the empty string.
    #     """
    #     if len(paramSelection) > 28:
    #         raise ValueError("The parameter paramSelection cannot have more " \
    #                          "than 28 elements.")
    #     if TMin == None:
    #         TMin = self.TMinLow
    #     if TMax == None:
    #         TMax = self.TMaxHigh            
    #     TArr = np.linspace(TMin, TMax, num)
        
    #     styles = ['b','g','r','c','m','y','k','b--','g--','r--','c--','m--',
    #               'y--','k--','b-.','g-.','r-.','c-.','m-.','y-.','k-.','b:',
    #               'g:','r:','c:','m:','y:','k:']
        
    #     for i in range(0,len(paramSelection)):
    #         name = paramSelection[i]
    #         order = 1
    #         NLO = paramSelection[i].find('_NLO')
    #         if NLO > 0:
    #             name = paramSelection[i][:NLO]
    #         else:
    #             LO = paramSelection[i].find('_LO')
    #             if LO > 0:
    #                 name = paramSelection[i][:LO]
    #                 order = 0
    #         index = self._params3DIndices(name)
    #         if order == 0:
                      
    #         pArr = np.array([self.params4DVsMu4D(mu)[indices[i]]
    #                          for mu in muArr])
    #         plt.plot(muArr, pArr, styles[i], label = paramNames[i])
    #     plt.xlabel(xlabel)
    #     plt.ylabel(ylabel)
    #     plt.xscale(xscale)
    #     plt.yscale(yscale)
    #     if yMin is not None:
    #         plt.ylim(bottom = yMin)
    #     if yMax is not None:
    #         plt.ylim(top = yMax)
            
    #     if title != "": #Use a title
    #         if title is None: #Use default title
    #             title = "The 4D parameters " + ' '.join(paramNames) +         \
    #                     " as function of the 4D RG scale μ4D"
    #         plt.title(title)
    #     plt.legend()
    #     plt.show()