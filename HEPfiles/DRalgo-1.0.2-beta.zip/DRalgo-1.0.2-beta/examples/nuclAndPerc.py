#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from scipy.integrate import quad
import numpy as np


MPl = 1.220890 * 10**19 #Planck mass in GeV

def HRadVsT(T, gEff):
    """
    The Hubble parameter vs temperature for a radiation dominated universe.

    Parameters
    ----------
    T : float
        The temperature
    gEff : callable
        The effective number of degrees of freedom as function of temperature.

    Returns
    -------
    The Hubble parameter as a float.
    """
    return np.sqrt(gEff(T) * 8 * np.pi**3 / 90) * T**2 / MPl


def nuclCrit(S, T, A0 = 1, gEff = 106.75, betaH = 100):
    """
    An approximate nucleation criterion in terms of S/T.

    This function gives an approximate nucleation criterion in terms of
    S/T. For reference, see the paper S.J. Huber and T. Konstandin, 
    "Production of gravitational waves in the NMSSM", JCAP 05 (2008) 017 
    [arXiv:0709.2091]
    
    Aside from S and T, the function takes the factor A0 in the parametrization
    A(T) = A0*T^4 for the nucleation prefactor, the effective number of 
    degrees of freedom gEff near the nucleation temperature and the value of 
    the inverse duration parameter betaH = β/H. These parameters are of course
    not known a priori, but for a phase transition around the electroweak 
    scale, the default values should give a reasonable approximation.
    
    The function returns a callable that can be passed as the nuclCriterion
    parameter in the dictionary tunnelFromPhase_args when calling the
    CosmoTransitions functions generic_potential.findAllTransitions and
    transitionFinder.findAllTransitions. 

    Parameters
    ----------
    A0 : float, optional
        The factor A0 in A(T) = A0*T^4 for the nucleation prefactor. 
        Defaults to 1.
    gEff : float, optional
        The effective number of degrees of freedom at the nucleation
        temperature. Defaults to 106.75.
    betaH : float, optional
        The inverse duration parameter β/H. The default is 100.

    Returns
    -------
    A nuclCriterion for nucleation onset as a callable with signature f(S,T)
    """
    #The constant K below is approximately the familiar number 140 when
    #gEff = 106.75, as in the case of the SM at the EW transitions.
    K = 4*np.log(np.sqrt(90 / (gEff * 8 * np.pi**3)) * MPl / 100) -           \
        2*np.log(10)
    lambda S,T : S/T - K - np.log(A0) + 4*np.log(T/100)  + np.log(betaH/100)


def percCrit(S, T, A0 = 1, gEff = 106.75, betaH = 100, vWall = 1):
    """
    An approximate percolation criterion in terms of S/T.

    This function gives an approximate percolation criterion in terms of
    S/T. For reference, see the paper S.J. Huber and T. Konstandin, 
    "Production of gravitational waves in the NMSSM", JCAP 05 (2008) 017 
    [arXiv:0709.2091]
    
    Aside from S and T, the function takes the factor A0 in the parametrization
    A(T) = A0*T^4 for the nucleation prefactor, the effective number of 
    degrees of freedom gEff near the nucleation temperature, the value of the 
    inverse duration parameter betaH = β/H as well as the speed vWall (in 
    natural units) of the bubble wall. These parameters are of course not 
    known a priori, but for a phase transition around the electroweak scale, 
    the default values should give a reasonable approximation. 
    
    The function returns a callable that can be passed as the nuclCriterion
    parameter in the dictionary tunnelFromPhase_args when calling the
    CosmoTransitions functions generic_potential.findAllTransitions and
    transitionFinder.findAllTransitions. 

    Parameters
    ----------
    A0 : float, optional
        The factor A0 in A(T) = A0*T^4 for the nucleation prefactor. 
        Defaults to 1.
    betaH : float, optional
        The inverse duration parameter β/H. Defaults to 100.
    vWall : float, optional
        The bubble wall speed (in natural units). Defaults to 1.

    Returns
    -------
    A nuclCriterion for percolation as a callable with signature f(S,T)
    """
    #The constant K below is approximately the familiar number 130 when
    #gEff = 106.75, as in the case of the SM at the EW transitions.
    K = 4*np.log(np.sqrt(90 / (gEff * 8 * np.pi**3)) * MPl / 100) -           \
        8*np.log(10) + np.log(8*np.pi) #130
    
    return lambda S,T : S/T - K - np.log(A0) + 4*np.log(T/100) +              \
                        4*np.log(betaH/100) + 3*np.log(vWall)
                        
                        
def _integrateToTarget(f, target, aLow, aHigh, b, nBisMax = 20, epsabs = 1e-6,
                       epsrel = 1e-6):
    """
    Find the lower integration limit for an integral to reach a target value.
    
    This auxiliary function is used to find the lower integration limit a,
    in the range [aLow,aHigh], such that the integral of the function f(x) 
    with respect to x from a to b equals a certain target value. The value a
    is adjusted by bisection in the range [aLow,aHigh] until the estimated 
    integral I satisfies abs(I-target) < max(epsabs, epsrel*abs(target)) or
    until the maximum number of bisection steps has been reached.
 
    Parameters
    ----------
    f : callable
        A callable with signature f(x)
    target : float
        The target value of the integration.
    aLow : float
        Lower limit for the lower integration limit a to be found.
    aHigh : float
        Upper limit for the lower integration limit a to be found.
    b : float
        The fixed upper integration limit for the integral.
    nBisMax : int, optional
        The maximum number of bisection steps to take. Defaults to 20.
    epsabs : float, optional
        Absolute error tolerance. Defaults to 1e-6.
    epsrel : float, optional
        Relative error tolerance. Defaults to 1e-6.

    Raises
    ------
    ValueError
        A ValueError is raised if the integral cannot reach the target value
        for TMin in the range [TMinLow,TMinHigh].

    Returns
    -------
    a : float
        The found lower integration limit.
    I : float
        The integral from a to b
    nBis : int
        The number of bisection steps made.
    success : bool
        Indicates whether or not the target value for the integral could be
        reached to the desired tolerance within nBisMax bisection steps.

    """
    ILow = quad(f, aLow, b, epsabs = epsabs, epsrel = epsrel)[0]
    IHigh = quad(f, aHigh, b, epsabs = epsabs, epsrel = epsrel)[0]
    if not (ILow >= target >= IHigh or ILow <= target <= IHigh):
        raise ValueError("The integral does not reach the target value for a "\
                         "in the range [{},{}]".format(aLow,aHigh))   
    nBis = 0
    I = IHigh
    while True:
        aMid = (aLow + aHigh)/2 
        dI = quad(f, aMid, aHigh, epsabs = epsabs, epsrel = epsrel)[0]
        if abs(I + dI) >= abs(target):
            aLow = aMid
        else:
            aHigh = aMid
            I += dI
        nBis += 1
        if abs(I-target) < max(epsabs, epsrel*abs(target)):
            success = True
            break
        elif nBis >= nBisMax:
            success = False  
            break        
        
    return aHigh, I, nBis, success

                        
def calculateNuclTemp(S, A, gEff, TnLow, TnHigh, TMax, nBisMax = 20, 
                      epsabs = 1e-6, epsrel = 1e-6):
    """
    Calculates the nucleation temperature.
    
    This function calculates the nucleation temperature (assuming a radiation
    dominated universe throughout) given a function S (signature S(T)) with 
    the action S = S3/T as a function of temperature, a function A (signature 
    A(S,T)) for the nucleation rate as a function of the action S = S3/T and 
    the temperature, and a function gEff (signature gEff(T)) for the effective
    number of degrees of freedom as a function of  temperature.
    
    The lower integration limit TMin is adjusted between TMinLow and TMinHigh
    by bisection until the integral from TMin to TMax of A*e^(-S)*H^(-4)*dT/T
    equals 1, within a tolerance set by the parameters epsabs and epsrel. The
    parameter nBisMax sets the maximum number of bisection adjustments.     

    Parameters
    ----------
    S : callable
        The action S3/T as a function of temperature. Signature: S(T).
    A : callable
        The prefactor A as a function of S = S3/T and T. Signature: A(S,T).
    gEff : callable
        The effective number of degrees of freedom as a function of 
        temperature. Signature: gEff(T).
    TnLow : float
        Lower limit for the nucleation temperature.
    TnHigh : float
        Upper limit for the nucleation temperature.
    TMax : float
        The fixed upper integration limit.
    nBisMax : int, optional
        The maximum number of bisection steps. Defaults to 20.
    epsabs : float, optional
        The absolute error tolerance. Defaults to 1e-6.
    epsrel : float, optional
        The relative error tolerance. Defaults to 1e-6.

    Returns
    -------
    Tn : float
        The found nucleation temperature
    I : float
        The integral from Tn to TMax
    nBis : int
        The number of bisection steps made.
    success : bool
        Indicates whether or not the target value for the integral could be
        reached to the desired tolerance within nBisMax bisection steps.

    """
    f = lambda T : A(S(T),T) * np.exp(-S(T)) * HRadVsT(T, gEff(T))**(-4) / T
    Tn, I, nBis, success =  _integrateToTarget(f, 1, TnLow, TnHigh, TMax, 
                                               nBisMax, epsabs, epsrel)
    return Tn, I, nBis, success


def calculatePercTemp(S, A, gEff, TpLow, TpHigh, TMax, vWall = 1, nBisMax = 20, 
                      epsabs = 1e-6, epsrel = 1e-6):
    """
    Calculates the percolation temperature.
    
    This function calculates the percolation temperature (assuming a radiation
    dominated universe throughout) given a function S (signature S(T)) with 
    the action S = S3/T as a function of temperature, a function A (signature 
    A(S,T)) for the nucleation rate as a function of the action S = S3/T and 
    the temperature, and a function gEff (signature gEff(T)) for the effective
    number of degrees of freedom as a function of  temperature.
    
    NOTE: An inefficient implementation. Just for testing purposes. Also, the
    tolerances are not used in a completely consistent way.

    Parameters
    ----------
    S : callable
        The action S3/T as a function of temperature. Signature: S(T).
    A : callable
        The prefactor A as a function of S = S3/T and T. Signature: A(S,T).
    gEff : callable
        The effective number of degrees of freedom as a function of 
        temperature. Signature: gEff(T).
    TpLow : float
        Lower limit for the percolation temperature.
    TpHigh : float
        Upper limit for the percolation temperature.
    TMax : float
        The fixed upper integration limit.
    vWall : float, optional
        The bubble wall speed (in natural units). Defaults to 1.
    nBisMax : int, optional
        The maximum number of bisection steps. Defaults to 20.
    epsabs : float, optional
        The absolute error tolerance. Defaults to 1e-6.
    epsrel : float, optional
        The relative error tolerance. Defaults to 1e-6.

    Returns
    -------
    Tn : float
        The found nucleation temperature
    I : float
        The integral from Tn to TMax
    nBis : int
        The number of bisection steps made.
    success : bool
        Indicates whether or not the target value for the integral could be
        reached to the desired tolerance within nBisMax bisection steps.

    """
    g = lambda T: vWall * HRadVsT(T, gEff(T))**(-1)
    gInt = lambda T,Tp : quad(g, Tp, T, epsabs = epsabs, epsrel = epsrel)[0]
    f = lambda T,Tp : A(S(T),T) * np.exp(-S(T)) * HRadVsT(T, gEff(T))**(-1) * \
                      gInt(T,Tp)**3 / T
    fInt = lambda Tp : quad(f, Tp, TMax, epsabs = epsabs, epsrel = epsrel)[0]
    
    target = 0.34
    ILow = fInt(TpLow)
    IHigh = fInt(TpHigh)
    if not (ILow >= target >= IHigh or ILow <= target <= IHigh):
        raise ValueError("The integral does not reach the target value for Tp"\
                         "in the range [{},{}]".format(TpLow,TpHigh))  
    
    nBis = 0
    I = IHigh    
    while True:
        TpMid = (TpLow + TpHigh)/2 
        dI = fInt(TpMid) - IHigh
        if abs(I + dI) >= abs(target):
            TpLow = TpMid
        else:
            TpHigh = TpMid
            I += dI
        nBis += 1
        if abs(I-target) < max(epsabs, epsrel*abs(target)):
            success = True
            break
        elif nBis >= nBisMax:
            success = False  
            break    
        
    return TpHigh, I, nBis, success
