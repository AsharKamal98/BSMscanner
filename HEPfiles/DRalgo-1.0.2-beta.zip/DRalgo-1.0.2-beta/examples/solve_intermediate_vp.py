#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
from scipy.optimize import OptimizeResult
from scipy.integrate import solve_ivp, OdeSolution
import matplotlib.pyplot as plt

class OdeResult(OptimizeResult):
    pass

def solve_intermediate_vp(fun, t_span, yi, method = 'RK45', t_eval = None, 
                          dense_output = False, events = None, 
                          vectorized = False, args = None, **options):
    """
    Solves an intermediate value problem for a system of ODEs.
    
    This function is a helper function to numerically solve an intermediate
    value problem for a system of ODEs. By an intermediate value problem
    we mean a problem of the form dy/dt = f(t,y) for t in [t0,tf], with y = yi
    specified at the point t = ti, i.e. y(ti) = yi. For t in [t0,tf] we have a 
    final value problem and for t in [t0,ti] we have an initial value problem.
    The full solution is found by joining these two solutions together.
    
    The function uses the scipy function scipy.integrate.solve_ivp to solve 
    the final value and initial value problems. We refer to the documentation
    for scipy.integrate.solve_ivp for further details on the parameters.

    Parameters
    ----------
    fun : callable
        Right-hand side of the system. The calling signature is fun(t, y).
    t_span : 3-tuple of floats
        The integration range in the form (t0, ti, tf), where ti is the point
        in time where the intermediate value yi is specified. If ti = t0, it
        is purely an initial value problem, and if ti = tf it is purely a
        final value problem.
    yi : array_like, shape (n,)
        Intermediate value at t = ti.
    method : string or OdeSolver, optional
        Integration method to use. The default is 'RK45'.
    t_eval : array_like or None, optional
        Times at which to store the computed solution, must be sorted and lie 
        within t_span. If None (default), use points selected by the solver.
    dense_output : bool, optional
        Whether to compute a continuous solution. Default is False.
    events : callable, or list of callables, optional
        Events to track. If None (default), no events will be tracked.
    vectorized : bool, optional
        Whether fun is implemented in a vectorized fashion. Default is False.
    args : tuple, optional
        Additional arguments to pass to the user-defined functions. If given, 
        the additional arguments are passed to all user-defined functions.
    **options
        Options passed to a chosen solver. See the scipy documentation for
        the possible options.

    Returns
    -------
    Bunch object with the following fields defined:
    t : ndarray, shape (n_points,)
        Time points.
    y : ndarray, shape (n, n_points)
        Values of the solution at t.
    sol : OdeSolution or None
        Found solution as OdeSolution instance; None if dense_output was set 
        to False.
    t_events : list of ndarray or None
        Contains for each event type a list of arrays at which an event of 
        that type event was detected. None if events was None.
    y_events : list of ndarray or None
        For each value of t_events, the corresponding value of the solution. 
        None if events was None.
    nfev : int
        Number of evaluations of the right-hand side.
    njev : int
        Number of evaluations of the Jacobian.
    nlu : int
        Number of LU decompositions.
    status : int
        Reason for algorithm termination:
            -1: Integration step failed, either in the final or the initial
                value problem.
             0: The solver successfully reached the end of the time span for
                both the initial and the final value problem.
             1: A termination event occurred, either in the final or the
                initial value problem.
    message : string
        Human-readable description of the termination reason.
    success : bool
        True if the solver reached the interval end or a termination event
        occurred for both the final and the initial value problem 
        (i.e. status >= 0).
    """
    if t_span[1] == t_span[0]: #Pure initial value problem
        return solve_ivp(fun, [t_span[1],t_span[2]], yi, method, t_eval, 
                         dense_output, events, vectorized, args, **options)
    elif t_span[1] == t_span[2]: #Pure final value problem
        if t_eval is not None:
            t_eval_rev = t_eval[::-1]
        else:
            t_eval_rev = None
        sol_rev = solve_ivp(fun, [t_span[1],t_span[0]], yi, method, t_eval_rev,
                            dense_output, events, vectorized, args, **options)

        sol_rev.t = sol_rev.t[::-1]
        sol_rev.y = sol_rev.y[:,::-1]
        if sol_rev.t_events is not None:
            for i in range(0,len(sol_rev.t_events)):
                sol_rev.t_events[i] = sol_rev.t_events[i][::-1]
                sol_rev.y_events[i] = sol_rev.y_events[i][:,::-1]
            
        return sol_rev
    
    elif t_span[0] < t_span[1] < t_span[2]: #Intermediate value problem
        if t_eval is not None:
            #The more elegant
            #t_eval_for = t_eval[t_eval >= t_span[1]]
            #t_eval_rev = t_eval[t_eval >= t_span[1]][::-1]
            #does not work if t_eval is a list.
            t_eval_for = [t for t in t_eval if t >= t_span[1]]
            t_eval_rev = [t for t in t_eval if t <= t_span[1]][::-1]
            
        else:
            t_eval_for = None
            t_eval_rev = None
        sol_for = solve_ivp(fun, [t_span[1],t_span[2]], yi, method, t_eval_for, 
                            dense_output, events, vectorized, args, **options)
        sol_rev = solve_ivp(fun, [t_span[1],t_span[0]], yi, method, t_eval_rev,
                            dense_output, events, vectorized, args, **options)
        
        #Assemble the combined t and y from both solutions.
        if sol_rev.t is None and sol_for.t is None:
            t = None
            y = None
        elif sol_rev.t is not None and sol_for.t is not None:
            if sol_rev.t.size > 0 and sol_for.t.size > 0 and                  \
               sol_rev.t[0] == sol_for.t[0]: #Redundancy
                t = np.concatenate((sol_rev.t[:0:-1], sol_for.t))
                y = np.concatenate((sol_rev.y[:,:0:-1], sol_for.y), axis = 1)
            else:
                t = np.concatenate((sol_rev.t[::-1], sol_for.t))
                y = np.concatenate((sol_rev.y[:,::-1],sol_for.y), axis = 1)
        elif sol_rev.t is None:
            t = sol_for.t
            y = sol_for.y
        else:
            t = sol_rev.t[::-1]
            y = sol_rev.y[:,::-1]
        
        #Assemble, if needed, the combined dense_output from both solutions.
        if dense_output:
            if sol_rev.sol.ts.size > 0 and sol_for.sol.ts.size > 0 and        \
               sol_rev.sol.ts[0] == sol_for.sol.ts[0]: #Redundancy
                ts = np.concatenate((sol_rev.sol.ts[:0:-1], sol_for.sol.ts))
            else:
                ts = np.concatenate((sol_rev.sol.ts[::-1], sol_for.sol.ts))
            interpolants = sol_rev.sol.interpolants[::-1] +                   \
                           sol_for.sol.interpolants
            sol = OdeSolution(ts, interpolants)
        else:
            sol = None
        
        #Assemble, if needed, the combined t_events from both solutions.    
        if events is None:
            t_events = None
            y_events = None
        else:
            if isinstance(events, list):
                n_events = len(events)
            else:
                n_events = 1
            t_events = [np.empty(0)] * n_events
            y_events = [np.empty(0)] * n_events
            for i in range(0,n_events):
                if sol_rev.t_events[i].size > 0 and                           \
                   sol_for.t_events[i].size > 0:
                       if sol_rev.t_events[i][0] == sol_for.t_events[i][0]: 
                       #Redundancy
                           t_events[i] = np.concatenate((
                                             sol_rev.t_events[i][:0:-1],
                                             sol_for.t_events[i]))
                           y_events[i] = np.concatenate((
                                             sol_rev.y_events[i][:0:-1,:],
                                             sol_for.y_events[i]), axis = 0)
                       else:
                           t_events[i] = np.concatenate((
                                             sol_rev.t_events[i][::-1],
                                             sol_for.t_events[i]))
                           y_events[i] = np.concatenate((
                                             sol_rev.y_events[i][::-1,:],
                                             sol_for.y_events[i]), axis = 0)                           
                elif sol_rev.t_events[i].size > 0:
                    t_events[i] = sol_rev.t_events[i][::-1]
                    y_events[i] = sol_rev.y_events[i][::-1,:]
                elif sol_for.t_events[i].size > 0:
                    t_events[i] = sol_for.t_events[i]
                    y_events[i] = sol_rev.y_events[i]

        nfev = sol_rev.nfev + sol_for.nfev
        njev = sol_rev.njev + sol_for.njev
        nlu = sol_rev.nlu + sol_for.nlu
        
        if sol_rev.status == -1 or sol_for.status == -1:
            status = -1
        elif sol_rev.status == 0 and sol_for.status == 0:
            status = 0
        else:
            status = 1
            
        message = "FVP: " + sol_rev.message + " IVP: " + sol_for.message
        
        success = sol_rev.success and sol_for.success
        
        return OdeResult(t = t, y = y, sol = sol, t_events = t_events, 
                         y_events = y_events, nfev = nfev, njev = njev, 
                         nlu = nlu, status = status, message = message, 
                         success = success)                   
                           
    else:
        raise ValueError("The elements of t_span must be increasing.")

# def f(t,y):
#     return y

# #Forward solution (IVP)
# sol_for = solve_ivp(f,[1,3],[1],dense_output=True)

# t_arr_for = np.linspace(1,3)
# y_arr_for = sol_for.sol(t_arr_for)[0]

# plt.plot(t_arr_for, y_arr_for, 'r')
# plt.xlabel("t")
# plt.ylabel("y")
# plt.title("Solution of the IVP $dy/dt = y$, $t \in [1,3]$, $y(1) = 1$" + 
#           "\n using solve_ivp")
# plt.show()

# #Reverse (backward) solution (FVP)
# sol_rev = solve_ivp(f,[1,-1],[1],dense_output=True)

# t_arr_rev = np.linspace(-1,1)
# y_arr_rev = sol_rev.sol(t_arr_rev)[0]

# plt.plot(t_arr_rev, y_arr_rev, 'b')
# plt.xlabel("t")
# plt.ylabel("y")
# plt.title("Solution of the FVP $dy/dt = y$, $t \in [-1,1]$, $y(1) = 1$" + 
#           "\n using solve ivp")
# plt.show()

# #Combined plot
# plt.plot(t_arr_for, y_arr_for, 'r', label="IVP")
# plt.plot(t_arr_rev, y_arr_rev, 'b', label="FVP")
# plt.xlabel("t")
# plt.ylabel("y")
# plt.legend()
# plt.title("Solution of the ODE $dy/dt = y$, $t \in [-1,3]$, $y(1) = 1$ " + 
#           "\n using solve_ivp")
# plt.show()

# #Full solution as an intermediate value problem
# sol_int = solve_intermediate_vp(f, [-1,1,3], [1], dense_output = True)
# t_arr_int = np.linspace(-1,3)
# y_arr_int = sol_int.sol(t_arr_int)[0]

# plt.plot(t_arr_int, y_arr_int, 'k')
# plt.xlabel("t")
# plt.ylabel("y")
# plt.title("Solution of the ODE $dy/dt = y$, $t \in [-1,3]$, $y(1) = 1$ " + 
#           "\n using solve_intermediate_vp")
# plt.show()

# #Full solution as an intermediate value problem with event for y = 0.5
# g = lambda t,y : y[0]-0.5
# sol_int = solve_intermediate_vp(f, [-1,1,3], [1], dense_output = True, 
#                                 events = g)
# t_arr_int = np.linspace(-1,3)
# y_arr_int = sol_int.sol(t_arr_int)[0]

# print("Without termination: t = ",sol_int.t)

# plt.plot(t_arr_int, y_arr_int, 'k')
# plt.xlabel("t")
# plt.ylabel("y")
# plt.title("Solution of the ODE $dy/dt = y$, $t \in [-1,3]$, $y(1) = 1$ " + 
#           "\n using solve_intermediate_vp")
# plt.show()

# #Full solution as an intermediate value problem with event for y = 0.5
# #with termination and directionality
# g = lambda t,y : y[0]-0.5
# g.terminal = True
# g.direction = -1
# sol_int = solve_intermediate_vp(f, [-1,1,3], [1], dense_output = True, 
#                                 events = g)
# t_arr_int = np.linspace(-1,3)
# y_arr_int = sol_int.sol(t_arr_int)[0]

# print("With termination: t = ",sol_int.t)

# plt.plot(t_arr_int, y_arr_int, 'k')
# plt.xlabel("t")
# plt.ylabel("y")
# plt.title("Solution of the ODE $dy/dt = y$, $t \in [-1,3]$, $y(1) = 1$ " + 
#           "\n using solve_intermediate_vp")
# plt.show()