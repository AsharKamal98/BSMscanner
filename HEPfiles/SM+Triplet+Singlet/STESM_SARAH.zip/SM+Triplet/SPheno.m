OnlyLowEnergySPheno = True;

MINPAR={
        {1,L1Input},
        {2,L2Input},
        {3,L3Input}, 
        {4,L4Input},
        {5,L5Input},
        {6,L6Input},
        {7,L7Input},
        {8,L8Input},
        {9,L9Input},
        {10,L10Input},
        {11,L11Input},
        {12,mTInput},
	{13,mSSSInput}
       };

ParametersToSolveTadpoles = {mu2};

DEFINITION[MatchingConditions]= {
 {Ye, YeSM},
 {Yd, YdSM},
 {Yu, YuSM},
 {g1, g1SM},
 {g2, g2SM},
 {g3, g3SM},
(* {v,  Sqrt[vSM^2-vTinput^2]}*)
 {v,  vSM}
 };


AddTreeLevelUnitarityLimits=True;


BoundaryLowScaleInput={
  {mT,  mTInput},
  {mSSS,  mSSSInput},
  {L1,  L1Input},
  {L2,  L2Input},
  {L3,  L3Input},
  {L4,  L4Input},
  {L5,  L5Input},
  {L6,  L6Input},
  {L7,  L7Input},
  {L8,  L8Input},
  {L9,  L9Input},
  {L10, L10Input},
  {L11, L11Input}



};


ListDecayParticles = {Fu,Fe,Fd,hh,Hpm};
ListDecayParticles3B = {{Fu,"Fu.f90"},{Fe,"Fe.f90"},{Fd,"Fd.f90"}};

(*DefaultInputValues ={LHInput -> 0.1, LTInput -> 0.2, LTHInput -> 0.2, KInput->0.1, MTInput->0.27 };*)


RenConditionsDecays={
{dCosTW, 1/2*Cos[ThetaW] * (PiVWp/(MVWp^2) - PiVZ/(mVZ^2)) },
{dSinTW, -dCosTW/Tan[ThetaW]},
{dg2, 1/2*g2*(derPiVPheavy0 + PiVPlightMZ/MVZ^2 - (-(PiVWp/MVWp^2) + PiVZ/MVZ^2)/Tan[ThetaW]^2 + (2*PiVZVP*Tan[ThetaW])/MVZ^2)  },
{dg1, dg2*Tan[ThetaW]+g2*dSinTW/Cos[ThetaW]- dCosTW*g2*Tan[ThetaW]/Cos[ThetaW]}
};
