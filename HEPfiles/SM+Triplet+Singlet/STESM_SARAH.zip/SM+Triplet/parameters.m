ParameterDefinitions = { 

{g1,        { Description -> "Hypercharge-Coupling"}},
{g2,        { Description -> "Left-Coupling"}},
{g3,        { Description -> "Strong-Coupling"}},    
{AlphaS,    {Description -> "Alpha Strong"}},	
{e,         { Description -> "electric charge"}}, 

{Gf,        { Description -> "Fermi's constant"}},
{aEWinv,    { Description -> "inverse weak coupling constant at mZ"}},

{Yu,        { Description -> "Up-Yukawa-Coupling",
			 DependenceNum ->  Sqrt[2]/v* {{Mass[Fu,1],0,0},
             									{0, Mass[Fu,2],0},
             									{0, 0, Mass[Fu,3]}}}}, 
             									
{Yd,        { Description -> "Down-Yukawa-Coupling",
			  DependenceNum ->  Sqrt[2]/v* {{Mass[Fd,1],0,0},
             									{0, Mass[Fd,2],0},
             									{0, 0, Mass[Fd,3]}}}},
             									
{Ye,        { Description -> "Lepton-Yukawa-Coupling",
			  DependenceNum ->  Sqrt[2]/v* {{Mass[Fe,1],0,0},
             									{0, Mass[Fe,2],0},
             									{0, 0, Mass[Fe,3]}}}}, 
                                                                            
                                                                           
{mu2,         { Description -> "SM Mu Parameter",
        LesHouches -> {HMIX,2}}},                                        

{LH,  { Description -> "SM Higgs Selfcouplings",
               DependenceNum -> Mass[hh]^2/(v^2)},
        LesHouches -> {HMIX,1} },

{v,          { Description -> "EW-VEV",
               DependenceNum -> Sqrt[4*Mass[VWp]^2/(g2^2)],
               DependenceSPheno -> None  }},

(*{vT,  { LaTeX -> "v_T",
        Real -> True,
        OutputName -> vT,
        LesHouches -> {HMIX,21} }},*)
(*
{MT,  { LaTeX -> "\\mu_T",
        OutputName -> MT,
        LesHouches -> {HMIX,15} }},

{KHT,  { LaTeX -> "\\kappa",
        OutputName -> Kap,
        LesHouches -> {HMIX,20} }},

{LT,  { LaTeX -> "\\lambda_T",
        OutputName -> LT,
        LesHouches -> {HMIX,17} }},

{LT2,  { LaTeX -> "{\\lambda'}_T",
        OutputName -> LT2,
        LesHouches -> {HMIX,18} }},        

{LHT,  { LaTeX -> "\\lambda_{HT}",
        OutputName -> LHT,
        LesHouches -> {HMIX,19} }},        
*)

{mT,  { LaTeX -> "\\m^2_T",
        OutputName -> mT,
        LesHouches -> {HMIX,15} }},

{mSSS,  { LaTeX -> "\\m^2_S",
        OutputName -> mSSS,
        LesHouches -> {HMIX,29} }},

{L1,  { LaTeX -> "\\lambda_1",
        OutputName -> L1,
        LesHouches -> {HMIX,17} }},

{L2,  { LaTeX -> "\\lambda_2",
        OutputName -> L2,
        LesHouches -> {HMIX,18} }},

{L3,  { LaTeX -> "\\lambda_3",
        OutputName -> L3,
        LesHouches -> {HMIX,19} }},

{L4,  { LaTeX -> "\\lambda_4",
        OutputName -> L4,
        LesHouches -> {HMIX,20} }},

{L5,  { LaTeX -> "\\lambda_5",
        OutputName -> L5,
        LesHouches -> {HMIX,21} }},

{L6,  { LaTeX -> "\\lambda_6",
        OutputName -> L6,
        LesHouches -> {HMIX,22} }},

{L7,  { LaTeX -> "\\lambda_7",
        OutputName -> L7,
        LesHouches -> {HMIX,23} }},

{L8,  { LaTeX -> "\\lambda_8",
        OutputName -> L8,
        LesHouches -> {HMIX,24} }},

{L9,  { LaTeX -> "\\lambda_9",
       OutputName -> L9,
        LesHouches -> {HMIX,25} }},

{L10,  { LaTeX -> "\\lambda_10",
        OutputName -> L10,
        LesHouches -> {HMIX,26} }},

{L11,  { LaTeX -> "\\lambda_11",
        OutputName -> L11,
        LesHouches -> {HMIX,27} }},

{L12,  { LaTeX -> "\\lambda_12",
        OutputName -> L12,
        LesHouches -> {HMIX,28} }},




{ThetaW,    { Description -> "Weinberg-Angle",
              DependenceNum -> ArcSin[Sqrt[1 - Mass[VWp]^2/Mass[VZ]^2]]}},

{ZZ, {Description -> "Photon-Z Mixing Matrix"}},
{ZW, {Description -> "W Mixing Matrix",
       Dependence ->   1/Sqrt[2] {{1, 1},
                  {\[ImaginaryI],-\[ImaginaryI]}} }},

{ZH,  { Description->"Scalar-Mixing-Matrix",
        Real->True,
        LesHouches -> ZH,
        OutputName -> ZH,
        LaTeX->"Z^H", 
        Dependence -> None,
        DependenceOptional -> None,
        DependenceNum -> None}},



{ZP,        { Description->"Charged-Mixing-Matrix", 
                Dependence -> None,
               DependenceOptional -> None,
               DependenceNum -> None}}, 


{Vu,        {Description ->"Left-Up-Mixing-Matrix"}},
{Vd,        {Description ->"Left-Down-Mixing-Matrix"}},
{Uu,        {Description ->"Right-Up-Mixing-Matrix"}},
{Ud,        {Description ->"Right-Down-Mixing-Matrix"}}, 
{Ve,        {Description ->"Left-Lepton-Mixing-Matrix"}},
{Ue,        {Description ->"Right-Lepton-Mixing-Matrix"}},

{ZA,  { Description->"Pseudo-Scalar-Mixing-Matrix"}},



{\[Beta],   { Description -> "Pseudo Scalar mixing angle"  }},
{\[Alpha],  { Description -> "Scalar mixing angle" }}


 }; 
 

