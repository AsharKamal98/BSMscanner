

ParticleDefinitions[GaugeES] = {
      {H0,  { 
                 PDG -> {0},
                 Width -> 0, 
                 Mass -> Automatic,
                 FeynArtsNr -> 1,
                 LaTeX -> "H^0",
                 OutputName -> "H0" }},                         
      
      
      {Hp,  {   
                 PDG -> {0},
                 Width -> 0, 
                 Mass -> Automatic,
                 FeynArtsNr -> 2,
                 LaTeX -> "H^+",
                 OutputName -> "Hp" }}, 
                 
      {T0,  {    PDG -> {0},
                 Width -> 0,
                 Mass -> Automatic,
                 LaTeX -> "T^0",
                 FeynArtsNr -> 4,
                 OutputName -> "T0" }},


      {Tm,  {    PDG -> {0},
                 Width -> 0,
                 Mass -> Automatic,
                 LaTeX -> "T^-",
                 FeynArtsNr -> 10,
                 OutputName -> "Tm" }},

      {f0,  {    PDG -> {0},
                 Width -> 0,
                 Mass -> Automatic,
                 LaTeX -> "f",
                 FeynArtsNr -> 60,
                 OutputName -> "f0" }},
               
    
      {VB,   { Description -> "B-Boson"}},                                                   
      {VG,   { Description -> "Gluon"}},          
      {VWB,  { Description -> "W-Bosons"}},          
      {gB,   { Description -> "B-Boson Ghost"}},                                                   
      {gG,   { Description -> "Gluon Ghost" }},          
      {gWB,  { Description -> "W-Boson Ghost"}},


  {eL,{
        Description -> "Left Electron",
        Mass -> LesHouches,
        Width -> Automatic,
        FeynArtsNr -> 12,
        LaTeX -> "e_L",
        OutputName -> "eL" }},

    {vL,{
        Description -> "Left Neutrino",
        Mass -> LesHouches,
        Width -> Automatic,
        FeynArtsNr -> 23,
        LaTeX -> "\\nu_{e_L}",
        OutputName -> "vL" }},

     {eR,{
        Description -> "Right Electron",
        Mass -> LesHouches,
        Width -> Automatic,
        FeynArtsNr -> 14,
        LaTeX -> "e_R",
        OutputName -> "eR" }},

     {dL,{
        Description -> "Left Down-Quark",
        Mass -> LesHouches,
        Width -> Automatic,
        FeynArtsNr -> 7,
        LaTeX -> "d_L",
        OutputName -> "dL" }},

     {dR,{
        Description -> "Right Down-Quark",
        Mass -> LesHouches,
        Width -> Automatic,
        FeynArtsNr -> 8,
        LaTeX -> "d_R",
        OutputName -> "dR" }},

     {uL,{
        Description -> "Left Up-Quark",
        Mass -> LesHouches,
        Width -> Automatic,
        FeynArtsNr -> 19,
        LaTeX -> "u_L",
        OutputName -> "uL" }},

     {uR,{
        Description -> "Right Up-Quark",
        Mass -> LesHouches,
        Width -> Automatic,
        FeynArtsNr -> 21,
        LaTeX -> "u_R",
        OutputName -> "uR" }},

(* ----------------------------------- Dirac fermions -----------------------------------*)
    {Fld,{
        Description -> "Dirac Left Down-Quarks",
        FeynArtsNr -> 121,
        LaTeX -> "\\Psi_{d}",
        Mass -> LesHouches,
        OutputName -> "dDL",
        Width -> {0, 0, 0}}},

     {Frd,{
        Description -> "Dirac Right Down-Quarks",
        FeynArtsNr -> 122,
        LaTeX -> "\\Chi_{d}",
        Mass -> LesHouches,
        OutputName -> "dDR",
        Width -> {0, 0, 0}}},

     {FLe,{
        Description -> "Dirac Left Electrons",
        FeynArtsNr -> 131,
        LaTeX -> "\\Psi_{e}",
        Mass -> LesHouches,
        OutputName -> "eDL",
        Width -> {0, 0, 0}}},

     {FLr,{
        Description -> "Dirac Right Electrons",
        FeynArtsNr -> 133,
        LaTeX -> "\\Chi_{e}",
        Mass -> LesHouches,
        OutputName -> "eDR",
        Width -> {0, 0, 0}}},

     {FLu,{
        Description -> "Dirac Left Up-Quarks",
        FeynArtsNr -> 111,
        LaTeX -> "\\Psi_{u}",
        Mass -> LesHouches,
        OutputName -> "uDL",
        Width -> {0, 0, 0}}},

     {FRu,{
        Description -> "Dirac Right Up-Quarks",
        FeynArtsNr -> 113,
        LaTeX -> "\\Chi_{u}",
        Mass -> LesHouches,
        OutputName -> "uDR",
        Width -> {0, 0, 0}}}



      
      };
      
      
      
      
  ParticleDefinitions[EWSB] = {
            
      
    {hh   ,  {  Description -> "Higgs",
                 PDG -> {25,35,62},
                 PDG.IX -> {101000001,101000002,101000010},
		 ElectricCharge -> 0 }}, 
                 
     {Ah   ,  {  Description -> "Pseudo-Scalar Higgs",
                 PDG -> {0},
                 PDG.IX ->{0},
                 Mass -> {0},
                 Width -> {0} }},                       
      
      
     {Hpm,     { Description -> "Charged Higgs", 
                 PDG -> {0,37},
                 PDG.IX ->{0, 100000601},
                 Width -> {0, External}, 
                 Mass -> {0, LesHouches},
                 LaTeX -> {"H^+","H^-"},
                 ElectricCharge -> 1,                 
                 OutputName -> {"Hp","Hm"}
                 }},          
(*
      {f0,  {    PDG -> {0},
                 Width -> {External},
                 Mass -> {LesHouches},
                 LaTeX -> {"f"},
		 ElectricCharge -> {0},
                 FeynArtsNr -> 60,
                 OutputName -> "fG0" }},
*)
      
      {VP,   { Description -> "Photon"}}, 
      {VZ,   { Description -> "Z-Boson",
      			 Goldstone -> Ah }}, 
      {VG,   { Description -> "Gluon" }},          
      {VWp,  { Description -> "W+ - Boson",
      			Goldstone -> Hpm[{1}] }},         
      {gP,   { Description -> "Photon Ghost"}},                                                   
      {gWp,  { Description -> "Positive W+ - Boson Ghost"}}, 
      {gWpC, { Description -> "Negative W+ - Boson Ghost" }}, 
      {gZ,   { Description -> "Z-Boson Ghost" }},
      {gG,   { Description -> "Gluon Ghost" }},          
                               
                 
      {Fd,   { Description -> "Down-Quarks"}},   
      {Fu,   { Description -> "Up-Quarks"}},   
      {Fe,   { Description -> "Leptons" }},
      {Fv,   { Description -> "Neutrinos" }}                                                              
     
        };    
        
        
        
 WeylFermionAndIndermediate = {
     
    {H,      { 
                 PDG -> 0,
                 Width -> 0, 
                 Mass -> Automatic,
                 LaTeX -> "H",
                 OutputName -> "" }},

   {phiH, {LaTeX -> "\\phi_H"}},

   {dR,     {LaTeX -> "d_R" }},
   {eR,     {LaTeX -> "e_R" }},
   {lep,     {LaTeX -> "l" }},
   {uR,     {LaTeX -> "u_R" }},
   {q,     {LaTeX -> "q" }},
   {eL,     {LaTeX -> "e_L" }},
   {dL,     {LaTeX -> "d_L" }},
   {uL,     {LaTeX -> "u_L" }},
   {vL,     {LaTeX -> "\\nu_L" }},

   {DR,     {LaTeX -> "D_R" }},
   {ER,     {LaTeX -> "E_R" }},
   {UR,     {LaTeX -> "U_R" }},
   {EL,     {LaTeX -> "E_L" }},
   {DL,     {LaTeX -> "D_L" }},
   {UL,     {LaTeX -> "U_L" }}

        };       


