import numpy as np
import matplotlib.pyplot as plt
#from sklearn.model_selection import train_test_split
#%pip install seaborn
import seaborn as sns
import pandas as pd


LabelFile = open("DataFile_Labels", "r")
l = LabelFile.readlines()
LabelFile.close()
labels = np.array([l[i].split()[6] for i in range(2,len(l))])
labels = labels.astype(np.float64)
threshold = 0.05
labels = [1 if item < threshold else 0 for item in labels]

print("Number of points in positive class:", sum(labels), "and in negative class:", len(labels)-sum(labels))


InParamFile = open("DataFile_FreeParam", "r")
l = InParamFile.readlines()
InParamFile.close()
InParam = np.array([l[i].split() for i in range(2,len(l))])
InParam = InParam.astype(np.float64)

#print(InParam[0])
InParam = np.delete(InParam, [2,3,7,8,11,12], 1)
#print(InParam.shape)
#print(InParam[0])

MassFile = open("DataFile_Masses", "r")
l = MassFile.readlines()
MassFile.close()
Masses = np.array([l[i].split()[1:4] for i in range(2,len(l))])
Masses = Masses.astype(np.float64)

#print(InParam.shape)
data = np.c_[InParam, Masses, labels]
#print(data.shape)
#print(data[0])

#df = pd.DataFrame(data, columns=['InParam1','InParam2','InParam3','InParam4', 'Label'])
df = pd.DataFrame(data, columns=['lam1', 'lam2', 'lam5', 'lam6', 'lam7','lam10', 'lam11', 'm1', 'm2', 'm3', 'Label'])
#print(df)

#df.plot.scatter(x='InParam1', y='InParam2')

sns.set_style("whitegrid");
sns.pairplot(df, hue='Label', plot_kws={"s": 7});
plt.show()
