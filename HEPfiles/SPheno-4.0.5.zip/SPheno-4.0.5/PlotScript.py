import Network
import seaborn as sns

import sys
import random as rand
import math
import numpy as np
import glob
import os
import matplotlib as mpl
from matplotlib import pyplot as plt
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm
#matplotlib.rcParams['text.usetex'] = True
import matplotlib.patches as mpatches
from matplotlib.ticker import AutoMinorLocator
from mpl_toolkits.axes_grid1 import make_axes_locatable, axes_size
import matplotlib.colors as colors

import pandas as pd
import seaborn as sns
import ast

import random
from sklearn.preprocessing import StandardScaler, FunctionTransformer
from scipy import stats
from scipy.stats import gaussian_kde

import glob


minorLocator=AutoMinorLocator()
#plt.style.use('grayscale')
plt.rcParams['font.family'] = 'serif'
plt.rcParams['axes.linewidth'] = 1.5
colorsbasis=['#00A0B0','#6A4A3C','#CC333F','#EB6841','#EDC951','#A3A948','#B3E099','#5165E9','#B1B59D']
#-------------------------------------------------#

mpl.rcParams['text.usetex']=True 
mpl.rcParams['text.latex.preamble'] = r'\usepackage{bm}'
plt.rcParams.update({'font.size': 20})
mpl.rcParams["legend.framealpha"] = 1.0
mpl.rcParams['axes.spines.right'] = False
mpl.rcParams['axes.spines.top'] = False
mpl.rcParams["figure.figsize"] = [8.5, 5.5]



def ReadData1():
    with open("TDataFile_Labels", "r") as f:
        l = f.readlines()
    data_ST =  np.array([l[i].split()[:2] for i in range(2,len(l))])
    with open("TDataFile_Masses", "r") as f:
                l = f.readlines()
    data_masses =  np.array([l[i].split()[1:4] for i in range(2,len(l))])
    with open("TDataFile_FreeParam", "r") as f:
                l = f.readlines()
    data_param =  np.array([l[i].split() for i in range(2,len(l))])

    data = np.c_[data_masses, data_param, data_ST]
    df = pd.DataFrame(data[:30000], columns=['mN1', 'mN2', 'mC', 'lam1', 'lam2', 'lam3', 'lam4', 'lam5', 'lam6', 'lam7', 'lam8', 'lam9', 'lam10', 'lam11', 'mT', 'mS', 'T', 'S'])
    return df

def ReadData2():
    data = Network.ReadFiles(data_type=data_type, read_data=read_data, plot_dist=plot_dist)
    X_boosted, y_boosted = Network.Boosting(data[:10000,:10], data[:10000,10], under_sample=1, over_sample=None)
    return X_boosted, y_boosted



def STellipse(S_arr,T_arr):
    arr = []
    for i in range(S_arr.shape[0]):
        S = S_arr[i]
        T = T_arr[i]
        T_tilde = T-0.05
        theta = 0.595
        a = 0.1458
        b = 0.0437
        val = ((S*np.cos(theta)+T_tilde*np.sin(theta))/a)**2 + ((T_tilde*np.cos(theta)-S*np.sin(theta))/b)**2
        if val > 2:
            val = 2
        arr.append(val)
    #return ((S*np.cos(theta)+T_tilde*np.sin(theta))/a)**2 + ((T_tilde*np.cos(theta)-S*np.sin(theta))/b)**2
    return arr

def PlotST(X, y, fig_name):
    data = np.c_[X,y]
    df = pd.DataFrame(data, columns=["mN1", "mN2", "mC", 'Constraints'])
    sns.scatterplot(data=df, x = "mN1", y = "mC", hue="constraints")




def PlotST11(df):
    name_list=['lam1', 'lam2', 'lam5', 'lam6', 'lam7', 'lam8', 'lam9', 'lam10', 'lam11', 'mT', 'mS', 'mN1', 'mN2', 'mC']
    for name in name_list:
        #bar_label=r'$m_{\mathrm{C}}$'
        bar_label="{}".format(name)
        fig, ax = plt.subplots(figsize=(8, 5))

        plt.ylabel(r'$T$', fontweight='bold', fontsize=25)
        plt.xlabel(r'$S$', fontweight='bold', fontsize=25)
        plt.tick_params(labelsize=25)
        cm = plt.cm.gist_rainbow

        ST = STellipse(np.float64(df['S']), np.float64(df['T']))

        s = ax.scatter(np.float64(df['S']), np.float64(df['T']), c=np.float64(df["{}".format(name)]), cmap='gist_rainbow', s=2, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")

        #plt.tick_params(labelsize=20)
        plt.autoscale(enable=True, axis='both', tight=True)

        ax.set_axisbelow(True)
        plt.grid(which='minor', color='lightgrey', linestyle='--')
        plt.grid(which='major', color='grey', linestyle='-')

        colorb = plt.colorbar(s, pad=0.025, fraction=0.1)
        colorb.ax.locator_params(nbins=5)
        colorb.set_label(bar_label, labelpad=8, fontsize=20)
        colorb.ax.tick_params(labelsize=20)

        #plt.legend(loc='upper right', fontsize = 16)

        #plt.ylim(0.01,1)
        #plt.xlim(-1,1)


        #plt.gca().set_aspect(1)
        #plt.figure(figsize=(10,6))

        plt.subplots_adjust(left=0.24, bottom=0.24)
        #plt.savefig('TempPlots/ST.pdf', bbox_inches='tight',dpi=400)
        plt.show()

    
    return None

def PlotST2(df):
    #name_list=['lam1', 'lam2', 'lam5', 'lam6', 'lam7', 'lam8', 'lam9', 'lam10', 'lam11', 'mT', 'mS', 'mN1', 'mN2', 'mC']
    #for name in name_list:
    #bar_label=r'$m_{\mathrm{C}}$'
    bar_label="ST"
    fig, ax = plt.subplots(figsize=(8, 5))

    plt.ylabel(r'$param1$', fontweight='bold', fontsize=25)
    plt.xlabel(r'$param2$', fontweight='bold', fontsize=25)
    plt.tick_params(labelsize=25)
    cm = plt.cm.gist_rainbow


    ST = STellipse(np.float64(df['S']), np.float64(df['T']))

    s = ax.scatter(np.float64(df['mN1']), np.float64(df['mC']), c=ST, cmap='jet', s=2, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")

    #plt.tick_params(labelsize=20)
    plt.autoscale(enable=True, axis='both', tight=True)

    ax.set_axisbelow(True)
    plt.grid(which='minor', color='lightgrey', linestyle='--')
    plt.grid(which='major', color='grey', linestyle='-')

    colorb = plt.colorbar(s, pad=0.025, fraction=0.1)
    colorb.ax.locator_params(nbins=5)
    colorb.set_label(bar_label, labelpad=8, fontsize=20)
    colorb.ax.tick_params(labelsize=20)
    #plt.legend(loc='upper right', fontsize = 16)

    #plt.ylim(0.01,1)
    #plt.xlim(-1,1)


    #plt.gca().set_aspect(1)
    #plt.figure(figsize=(10,6))

    plt.subplots_adjust(left=0.24, bottom=0.24)
    plt.savefig('TempPlots/ST_N12.pdf', bbox_inches='tight',dpi=400)
    #plt.show()


    return None



df=ReadData()
PlotST2(df)
#PlotST(df)


