import Network

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


import sys
import random as rand
import math
import numpy as np
import glob
import os
import matplotlib as mpl
import matplotlib
import matplotlib.cm as cm
matplotlib.rcParams['text.usetex'] = True
import matplotlib.patches as mpatches
from matplotlib.ticker import AutoMinorLocator
from mpl_toolkits.axes_grid1 import make_axes_locatable, axes_size
import matplotlib.colors as colors

import ast

import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec

from sklearn.preprocessing import StandardScaler, FunctionTransformer
from scipy import stats
from scipy.stats import gaussian_kde

import glob

import matplotlib.ticker as ticker


minorLocator=AutoMinorLocator()
#plt.style.use('grayscale')
plt.rcParams['font.family'] = 'serif'
plt.rcParams['axes.linewidth'] = 1.5
colorsbasis=['#00A0B0','#6A4A3C','#CC333F','#EB6841','#EDC951','#A3A948','#B3E099','#5165E9','#B1B59D']
#-------------------------------------------------#

mpl.rcParams['text.usetex']=True
mpl.rcParams['text.latex.preamble'] = r'\usepackage{bm}'
plt.rcParams.update({'font.size': 20})
mpl.rcParams["legend.framealpha"] = 1.0
mpl.rcParams['axes.spines.right'] = False
mpl.rcParams['axes.spines.top'] = False
mpl.rcParams["figure.figsize"] = [8.5, 5.5]



def PlotDataGeneral():
    plot_dist=False
    read_data='both'
    data_type=0

    data = Network.ReadFiles(data_type=data_type, read_data=read_data, plot_dist=False)
    
    #X_boosted, y_boosted = Network.Boosting(data[:,:10], data[:,10], under_sample={"BG" : 190, "U" : 90, "H" : 90, "STU" : 90}, over_sample=None) 
    #X_boosted, y_boosted = Network.Boosting(data[:,:10], data[:,10], under_sample={"BG" : 120, "FOPT" : 66, "S-FOPT" : 66, "D-FOPT" : 66}, over_sample=None)
    #X_boosted, y_boosted = data[:,:10], data[:,10]
    #X_boosted, y_boosted = Network.Boosting(data[:2000,:-1], data[:2000,-1], under_sample=0.1, over_sample=None)
    
    #Network.PlotData(X_boosted, y_boosted, "TempPlots/Plot.png", plot_dist=plot_dist, read_data=read_data)

    return None

#PlotDataGeneral()

def PlotKDE():
    read_data='collider'
    com_norm = True    #common_norm variable in sns.kdeplot
    data = Network.ReadFiles(data_type=0, read_data=read_data, plot_dist=True)

    if read_data=='collider':
        X_boosted, y_boosted = Network.Boosting(data[:,:10], data[:,10], under_sample={"BG" : 160, "U" : 90, "H" : 90, "STU" : 90}, over_sample=None) #160
    elif read_data=='cosmic':
        X_boosted, y_boosted = Network.Boosting(data[:,:10], data[:,10], under_sample={"BG" : 100, "FOPT" : 60, "S-FOPT" : 60, "D-FOPT" : 60}, over_sample=None)
    data = np.c_[X_boosted,y_boosted]
    df = pd.DataFrame(data, columns=["Lam1", "Lam2", "lam1", "lam2", "lam3", "lam6", "lam7", "mN1", "mN2", "mC", "Constraints"])
    name_list = ["Lam1", "Lam2", "lam1", "lam2", "lam3", "lam6", "lam7", "mN1", "mN2", "mC"]
    for name in name_list:
        df[name] = pd.to_numeric(df[name])

    #sns.set_style("whitegrid");
    #fig = plt.figure(figsize=(15,18))
    #gs = gridspec.GridSpec(4, 12)
    #ax1 = plt.subplot(gs[0, 2:6])
    #ax2 = plt.subplot(gs[0, 6:10])
    #ax3 = plt.subplot(gs[1, 2:6])
    #ax4 = plt.subplot(gs[1, 6:10])
    #ax5 = plt.subplot(gs[2, :4])
    #ax6 = plt.subplot(gs[2, 4:8])
    #ax7 = plt.subplot(gs[2, 8:])
    #ax8 = plt.subplot(gs[3, :4])
    #ax9 = plt.subplot(gs[3, 4:8])
    #ax10 = plt.subplot(gs[3, 8:])

    fig = plt.figure(figsize=(27,10))
    gs = gridspec.GridSpec(2, 5)

    ax1 = plt.subplot(gs[0, 0])
    ax2 = plt.subplot(gs[0, 1])
    ax3 = plt.subplot(gs[0, 2])
    ax4 = plt.subplot(gs[0, 3])
    ax5 = plt.subplot(gs[0, 4])
    ax6 = plt.subplot(gs[1, 0])
    ax7 = plt.subplot(gs[1, 1])
    ax8 = plt.subplot(gs[1, 2])
    ax9 = plt.subplot(gs[1, 3])
    ax10 = plt.subplot(gs[1, 4])

    #fig, axes = plt.subplots(2,3, figsize=(15,12))
    fig.tight_layout()

    if read_data=='collider':
        palette_dict = {"U" : "green", "H" : "blue", "STU" : "red", "BG" : "black"}
        hue_order_list = ["U", "H", "STU", "BG"]
        bw = 1
    elif read_data=='cosmic':
        palette_dict = {"FOPT" : "orange", "S-FOPT" : "dodgerblue", "D-FOPT" : "darkgreen", "BG" : "black"}
        hue_order_list = ["FOPT", "S-FOPT", "D-FOPT", "BG"]
        bw = 0.8


    sns.kdeplot(df, ax=ax1, x = "Lam1", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax1.set_xlabel(r'$\Lambda_1 \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    ax1.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25) 
    ax1.autoscale(enable=True, axis='both', tight=True)
    ax1.tick_params(labelsize=25)
    ax1.ticklabel_format(style='sci', scilimits=(0,0), axis='y')
    
    sns.kdeplot(df, ax=ax2, x = "Lam2", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax2.set_xlabel(r'$\Lambda_2 \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    ax2.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax2.autoscale(enable=True, axis='both', tight=True)
    ax2.tick_params(labelsize=25)
    ax2.ticklabel_format(style='sci', scilimits=(0,0), axis='y')

    sns.kdeplot(df, ax=ax3, x = "lam1", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax3.set_xlabel(r'$\lambda_1$', fontweight='bold', fontsize=25)
    ax3.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax3.autoscale(enable=True, axis='both', tight=True)
    ax3.tick_params(labelsize=25)
    ax3.ticklabel_format(style='sci', scilimits=(0,0), axis='y')

    sns.kdeplot(df, ax=ax4, x = "lam2", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax4.set_xlabel(r'$\lambda_2$', fontweight='bold', fontsize=25)
    ax4.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax4.autoscale(enable=True, axis='both', tight=True)
    ax4.tick_params(labelsize=25)
    ax4.ticklabel_format(style='sci', scilimits=(0,0), axis='y')

    sns.kdeplot(df, ax=ax5, x = "lam3", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax5.set_xlabel(r'$\lambda_3$', fontweight='bold', fontsize=25)
    ax5.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax5.autoscale(enable=True, axis='both', tight=True)
    ax5.tick_params(labelsize=25)
    ax5.ticklabel_format(style='sci', scilimits=(0,0), axis='y')
    #ax5.set_ylim(top=2.0*10**(-2))

    sns.kdeplot(df, ax=ax6, x = "lam6", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax6.set_xlabel(r'$\lambda_6$', fontweight='bold', fontsize=25)
    ax6.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax6.autoscale(enable=True, axis='both', tight=True)
    ax6.tick_params(labelsize=25)
    ax6.ticklabel_format(style='sci', scilimits=(0,0), axis='y')

    sns.kdeplot(df, ax=ax7, x = "lam7", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax7.set_xlabel(r'$\lambda_7$', fontweight='bold', fontsize=25)
    ax7.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax7.autoscale(enable=True, axis='both', tight=True)
    ax7.tick_params(labelsize=25)
    ax7.ticklabel_format(style='sci', scilimits=(0,0), axis='y')

    sns.kdeplot(df, ax=ax8, x = "mC", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax8.set_xlabel(r'$m_{\mathrm{C}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    ax8.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax8.autoscale(enable=True, axis='both', tight=True)
    ax8.tick_params(labelsize=25)
    ax8.ticklabel_format(style='sci', scilimits=(0,0), axis='y')

    sns.kdeplot(df, ax=ax9, x = "mN1", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax9.set_xlabel(r'$m_{\mathrm{N_1}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    ax9.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax9.autoscale(enable=True, axis='both', tight=True)
    ax9.tick_params(labelsize=25)
    ax9.ticklabel_format(style='sci', scilimits=(0,0), axis='y')

    sns.kdeplot(df, ax=ax10, x = "mN2", hue="Constraints", fill=True, bw_adjust=bw, palette=palette_dict, hue_order=hue_order_list, legend=False, common_norm=com_norm)
    ax10.set_xlabel(r'$m_{\mathrm{N_2}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    ax10.set_ylabel(r'$\mathrm{PDF}$', fontweight='bold', fontsize=25)
    ax10.autoscale(enable=True, axis='both', tight=True)
    ax10.tick_params(labelsize=25)
    ax10.ticklabel_format(style='sci', scilimits=(0,0), axis='y')

    U_patch = mpatches.Patch(color='green', alpha=0.35, label='U')
    H_patch = mpatches.Patch(color='blue', alpha=0.55, label='H')
    STU_patch = mpatches.Patch(color='red', alpha=0.55, label='STU')

    FOPT_patch = mpatches.Patch(color='orange', alpha=0.35, label='FOPT')
    SFOPT_patch = mpatches.Patch(color='dodgerblue', alpha=0.55, label='S-FOPT')
    DFOPT_patch = mpatches.Patch(color='darkgreen', alpha=0.55, label='D-FOPT')


    BG_patch = mpatches.Patch(color='black', alpha=0.45, label='BG')


    #fig.subplots_adjust(hspace=0.35, wspace=5.5)
    fig.subplots_adjust(hspace=0.35)

    if read_data=='collider':
        #ax9.legend(handles=[U_patch, STU_patch, H_patch, BG_patch], loc = 'upper center', bbox_to_anchor=(0.5, -0.35),fancybox=False, shadow=False, frameon=False, fontsize=30, ncol=4)
        ax8.legend(handles=[U_patch, STU_patch, H_patch, BG_patch], loc = 'upper center', bbox_to_anchor=(0.5, -0.25),fancybox=False, shadow=False, frameon=False, fontsize=30, ncol=4)
        plt.savefig("TempPlots/KDE_Coll_Slides.pdf", bbox_inches="tight")
    elif read_data=='cosmic':
        #ax9.legend(handles=[FOPT_patch, SFOPT_patch, DFOPT_patch, BG_patch], loc = 'upper center', bbox_to_anchor=(0.5, -0.35),fancybox=False, shadow=False, frameon=False, fontsize=30, ncol=4)
        ax8.legend(handles=[FOPT_patch, SFOPT_patch, DFOPT_patch, BG_patch], loc = 'upper center', bbox_to_anchor=(0.5, -0.25),fancybox=False, shadow=False, frameon=False, fontsize=30, ncol=4)
        plt.savefig("TempPlots/KDE_Cos_Slides.pdf", bbox_inches="tight")

    return None

def FilterData():
    # Read controlled points. Find indicies of positive points.
    read_data = 'both'
    data_type=2
    wname="FF"

    data = Network.ReadFiles(data_type=data_type, read_data=read_data)
    labels = np.array(data[:,10])
    pos_points_indicies = np.where(labels==1)[0]
    pos_points_indicies = np.insert(pos_points_indicies, 0, [-2,-1]) #Insert two zeros at beginning


    if data_type==2:
        rname="P"
    elif data_type==3:
        rname="F"

    with open("{}DataFile_FreeParam".format(rname), "r") as f:
        l = np.array(f.readlines())
    with open("{}DataFile_FreeParam".format(wname), "w") as f:
        f.writelines(l[pos_points_indicies+2])
    with open("{}DataFile_Masses".format(rname), "r") as f:
        l = np.array(f.readlines())
    with open("{}DataFile_Masses".format(wname), "w") as f:
        f.writelines(l[pos_points_indicies+2])
    if read_data=='both' or read_data=='collider':
        with open("{}DataFile_Labels".format(rname), "r") as f:
            l = np.array(f.readlines())
        with open("{}DataFile_Labels".format(wname), "w") as f:
            f.writelines(l[pos_points_indicies+2])
    if read_data=='both' or read_data=='cosmic':
        with open("{}DataFile_Labels_GW".format(rname), "r") as f:
            l = np.array(f.readlines())
        with open("{}DataFile_Labels_GW".format(wname), "w") as f:
            f.writelines(l[pos_points_indicies+2])

    #data = Network.ReadFiles(data_type=3, read_data=read_data)

    return None


def CheckBFB(): 
    ''' Check the number of points satisfying the boundedness from below constraints '''
    with open("FFDataFile_FreeParam", "r") as f:   
        l1 = f.readlines()
    data =  np.array([l1[i].split() for i in range(2,len(l1))])
    df = pd.DataFrame(data, columns=["Lam1", "Lam2", "Lam3", "Lam4", "lam1", "lam2", "lam3", "lam4", "lam5", "lam6", "lam7", "mT", "mS"])
    df = df.astype(float)

    df_BFB = df[(df["lam1"] > 0) & (df["lam2"] > 0) & (df["lam3"] > 0) & (df["lam5"] > 0) & (df["lam7"] > 0)]

    print(df.shape[0])
    print(df_BFB.shape[0])


    #df_ST = df[df["Constraints"] == "STU"]

    return None



def PlotST():   #Must manually set labels_col = labels_ST
    fig, axes = plt.subplots(1,2, sharey=True, figsize=(10,5))
    fig.tight_layout()

    data = Network.ReadFiles(data_type=0, read_data="collider", plot_dist=False)
    data_ST = data[:,-4:]
    # Select random points from data
    num_rows = data_ST.shape[0]
    random_indices = np.random.choice(num_rows, size=30000, replace=False)
    X_boosted, y_boosted = Network.Boosting(data_ST[random_indices,:-1], data_ST[random_indices,-1], under_sample=1, over_sample=None)
    data = np.c_[X_boosted,y_boosted]
    df = pd.DataFrame(data, columns=["mN1", "mN2", "mC", 'Constraints'])
    df["Constraints"] = df["Constraints"].replace({0.0: "BG", 1.0: "STU"})  #Change name of labels for plot

    sns.scatterplot(df, ax=axes[0], x = "mN1", y = "mN2", hue="Constraints", size="Constraints", sizes={"BG" : 6, "STU" : 6}, palette={"STU" : "orange", "BG" : "grey"}, hue_order=["STU", "BG"], legend=False, rasterized=True)
    axes[0].plot([df["mN1"].min(), df["mN1"].max()], [df["mN2"].min(), df["mN2"].max()], color='red', linestyle='--')
    axes[0].set_xlabel(r'$m_{\mathrm{N_1}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    axes[0].set_ylabel(r'$m_{\mathrm{N_2}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)

    sns.scatterplot(df, ax=axes[1], x = "mC", y = "mN2", hue="Constraints", size="Constraints", sizes={"BG" : 6, "STU" : 6}, palette={"STU" : "orange", "BG" : "grey"}, hue_order=["STU", "BG"], legend=True, rasterized=True)
    #axes[1].legend(labels=["hi", "hii"], loc = "upper left")
    #legend = axes[1].legend
    axes[1].legend(title="", loc = "upper left", markerscale=2.0)

    axes[1].plot([df["mC"].min(), df["mC"].max()], [df["mN2"].min(), df["mN2"].max()], color='red', linestyle='--')
    axes[1].set_xlabel(r'$m_{\mathrm{C}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    axes[1].set_ylabel(r'$m_{\mathrm{N_2}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    #axes[1].legend(label="hi")
    #axes[1].legend(labels=["hi", "hii", "j"], loc = "upper left")
    for i in range(2):
        axes[i].autoscale(enable=True, axis='both', tight=True)
        #axes[i].grid(which='minor', color='lightgrey', linestyle='--')
        #axes[i].grid(which='major', color='grey', linestyle='-')
        axes[i].tick_params(labelsize=25)
        #axes[i].set_axisbelow(True)

    plt.savefig("TempPlots/Plot2.pdf", bbox_inches="tight", dpi=800)
    return None


# SENSITIVITY CURVES
def Ohsq_LISA(f):
    return 1.e-14*(3.5800000000000006e-15/f**4 + 3.26e-10/f**3 + 1.2e-6/f**2 + 0.00248/f + 258.*f + 18100.*f**2 + 1.5e6*f**3)

def Ohsq_BBO(f):
    return 1.e-14*(0.00013500000000000003 + 1.77e-13/f**4 + 0.000033520143197784825/f**1.5 + 0.0022299999999999998*f + 0.0012900000000000001*f**2 + 0.00299*f**3)

def Ohsq_DECIGO(f):
    return 1.e-14*(0.0011 + 3.82e-13/f**4 + 0.00007146747511980537/f**1.5 + 0.00256*f + 0.0291*f**2 + 0.007540000000000001*f**3)

def PlotSensitivity():
    with open("PDataFile_Labels_GW", "r") as f:
        l = f.readlines()
    data =  np.array([l[i].split()[1:5] for i in range(2,len(l))])
    df = pd.DataFrame(data, columns=['alpha', 'beta', 'fpeak', 'ompeak'])
    df = df.sort_values('ompeak', ascending=False)

    bar_label=r'$\mathrm{log_{10}}\alpha$'
    fig, ax = plt.subplots(figsize=(8, 5))

    plt.ylabel(r'$h^2 \Omega_\mathrm{GW}^\mathrm{peak}$', fontweight='bold', fontsize=25)
    plt.xlabel(r'$f_\mathrm{peak} \,\, \mathrm{[Hz]}$', fontweight='bold', fontsize=25)
    plt.tick_params(labelsize=25)
    cm = plt.cm.gist_rainbow

    s = ax.scatter(np.float64(df['fpeak']), np.float64(df['ompeak']), c=np.log10(np.float64(df["alpha"])), cmap='gist_rainbow', s=7, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")

    #plt.tick_params(labelsize=20)
    plt.autoscale(enable=True, axis='both', tight=True)

    ax.set_axisbelow(True)
    plt.grid(which='minor', color='lightgrey', linestyle='--')
    plt.grid(which='major', color='grey', linestyle='-')

    colorb = plt.colorbar(s, pad=0.025, fraction=0.1)
    colorb.ax.locator_params(nbins=5)
    colorb.set_label(bar_label, labelpad=8, fontsize=20)
    colorb.ax.tick_params(labelsize=20)

    xmin = 10 ** (-4)
    xmax = 10000
    f = np.arange(xmin, xmax, (xmax - xmin) / 100000000., float)
    Omega_LISA = Ohsq_LISA(f)
    Omega_BBO = Ohsq_BBO(f)
    Omega_DECIGO = Ohsq_DECIGO(f)

    plt.plot(f,Omega_LISA,'--',color='r',linewidth=2, label=r'LISA')
    plt.plot(f,Omega_BBO,'-.',color='g',linewidth=2, label=r'BBO')
    plt.plot(f,Omega_DECIGO,':',color='b',linewidth=2.5, label=r'DECIGO')
    plt.legend(loc='upper right', fontsize = 16)

    plt.ylim([10 ** (-25), 10 ** (-8)])
    plt.xlim([xmin, xmax])

    ax.set_xscale('log')
    ax.set_yscale('log')

    plt.subplots_adjust(left=0.24, bottom=0.24)
    plt.savefig('TempPlots/GW_Sensitivity_Curve2.pdf', bbox_inches='tight',dpi=400)
    #plt.show()

    return None


def PlotHBS():
    fig, axes = plt.subplots(1,2, sharey=True, figsize=(14,5))
    fig.tight_layout()

    data = Network.ReadFiles(data_type=0, read_data="collider", plot_dist=True)
    data = data[:,-4:]
    df = pd.DataFrame(data, columns=["mN1", "mN2", "mC", 'Constraints'])

    df_ST = df[df["Constraints"] == "STU"]
    df_H = df[df["Constraints"] == "H"]

    color_map = "terrain"

    s = axes[0].scatter(np.float64(df_ST['mN1']), np.float64(df_ST['mN2']), c=np.float64(df_ST["mC"]), cmap=color_map, s=8, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")
    axes[0].set_xlabel(r'$m_{\mathrm{N_1}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    axes[0].set_ylabel(r'$m_{\mathrm{N_2}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    axes[0].set_xlim(200, 1000)
    axes[0].set_ylim(200, 1000)
    axes[0].set_title('EW Precision')

    colorb1 = plt.colorbar(s, ax=axes[0], pad=0.025, fraction=0.1)
    colorb1.ax.locator_params(nbins=5)
    colorb1.set_label(r'$m_{\mathrm{C}} \,\, \mathrm{[GeV]}$', labelpad=8, fontsize=20)
    colorb1.ax.tick_params(labelsize=20)




    s = axes[1].scatter(np.float64(df_H['mN1']), np.float64(df_H['mN2']), c=np.float64(df_H["mC"]), cmap=color_map, s=8, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")
    axes[1].set_xlabel(r'$m_{\mathrm{N_1}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    axes[1].set_xlim(200, 1000)
    axes[1].set_title('Higgs Exclusion Limits')

    colorb2 = plt.colorbar(s, ax=axes[1], pad=0.025, fraction=0.1)
    colorb2.ax.locator_params(nbins=5)
    colorb2.set_label(r'$m_{\mathrm{C}} \,\, \mathrm{[GeV]}$', labelpad=8, fontsize=20)
    colorb2.ax.tick_params(labelsize=20)


    for i in range(2):
        axes[i].autoscale(enable=True, axis='both', tight=True)
        axes[i].tick_params(labelsize=25)


    plt.tight_layout()
    plt.savefig("TempPlots/PlotMasses.pdf", bbox_inches="tight", dpi=800)
    return None



def FinalPlot():
    with open("FDataFile_FreeParam", "r") as f:
        l1 = f.readlines()
    with open("FDataFile_Masses", "r") as f:
        l2 = f.readlines()
    data1 =  np.array([l1[i].split() for i in range(2,len(l1))])
    data2 =  np.array([l2[i].split() for i in range(2,len(l2))])
    data = np.c_[data1,data2]
    df = pd.DataFrame(data, columns=["Lam1", "Lam2", "Lam3", "Lam4", "lam1", "lam2", "lam3", "lam4", "lam5", "lam6", "lam7", "mT", "mS", "mH", "mN1", "mN2", "mC"])

    #df = df.sort_values('ompeak', ascending=False)
    #df["Constraints"] = df["Constraints"].replace({0.0: "BG", 1.0: "STU"})

    fig, axes = plt.subplots(2,2, figsize=(15,10))#, sharey=True)
    fig.tight_layout()

    color_map = "terrain"


    s = axes[0,1].scatter(np.float64(df['lam1']), np.float64(df['lam2']), c=np.float64(df["lam3"]), cmap=color_map, s=10, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")
    axes[0,1].set_xlabel(r'$\lambda_1$', fontweight='bold', fontsize=25)
    axes[0,1].set_ylabel(r'$\lambda_2$', fontweight='bold', fontsize=25)
    axes[0,1].set_xlim(-2.5, 2.5)  
    axes[0,1].set_ylim(-7.5, 7.5)

    colorb1 = plt.colorbar(s, ax=axes[0,1], pad=0.025, fraction=0.1)
    colorb1.ax.locator_params(nbins=5)
    colorb1.set_label(r'$\lambda_3$', labelpad=8, fontsize=20)
    colorb1.ax.tick_params(labelsize=20)



    s = axes[1,1].scatter(np.float64(df['mN1']), np.float64(df['mN2']), c=np.float64(df["mC"]), cmap=color_map, s=10, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")
    axes[1,1].set_xlabel(r'$m_{\mathrm{N_1}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    axes[1,1].set_ylabel(r'$m_{\mathrm{N_2}} \,\, \mathrm{[GeV]}$', fontweight='bold', fontsize=25)
    axes[1,1].set_xlim(200, 1000)
    axes[1,1].set_ylim(200, 1000)

    colorb2 = plt.colorbar(s, ax=axes[1,1], pad=0.025, fraction=0.1)
    colorb2.ax.locator_params(nbins=5)
    colorb2.set_label(r'$m_{\mathrm{C}} \,\, \mathrm{[GeV]}$', labelpad=8, fontsize=20)
    colorb2.ax.tick_params(labelsize=20)
    #s.set_clim(200, 550)


    s = axes[0,0].scatter(np.float64(df['mT']), np.float64(df['mS']), c=np.float64(df["lam6"]), cmap=color_map, s=10, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")
    axes[0,0].set_xlabel(r'$\mu_{\mathrm{T}}^2 \,\, \mathrm{[GeV^2]}$', fontweight='bold', fontsize=25)
    axes[0,0].set_ylabel(r'$\mu_{\mathrm{S}}^2 \,\, \mathrm{[GeV^2]}$', fontweight='bold', fontsize=25)
    axes[0,0].set_xlim(58000, 170000)
    axes[0,0].set_ylim(0, 600000)
    #axes[0,0].yaxis.set_major_formatter(ticker.ScalarFormatter(useMathText=True, useOffset=False))
    #axes[0,0].yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: f'{x/100000:g}'))
    axes[0,0].ticklabel_format(style='sci', scilimits=(0,0), axis='y')
    axes[0,0].ticklabel_format(style='sci', scilimits=(0,0), axis='x')

    colorb3 = plt.colorbar(s, ax=axes[0,0], pad=0.025, fraction=0.1)
    colorb3.ax.locator_params(nbins=5)
    colorb3.set_label(r'$\lambda_6$', labelpad=8, fontsize=20)
    colorb3.ax.tick_params(labelsize=20)
    #s.set_clim(-7, -2.5)


    s = axes[1,0].scatter(np.float64(df['lam4']), np.float64(df['lam7']), c=np.float64(df["lam3"]), cmap=color_map, s=10, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")
    axes[1,0].set_xlabel(r'$\lambda_4$', fontweight='bold', fontsize=25)
    axes[1,0].set_ylabel(r'$\lambda_7$', fontweight='bold', fontsize=25)
    axes[1,0].set_xlim(-4.5, 4.5)
    axes[1,0].set_ylim(-3.5, 3.5)

    colorb4 = plt.colorbar(s, ax=axes[1,0], pad=0.025, fraction=0.1)
    colorb4.ax.locator_params(nbins=5)
    colorb4.set_label(r'$\lambda_3$', labelpad=8, fontsize=20)
    colorb4.ax.tick_params(labelsize=20)
    #s.set_clim(-13, 13)

   
    for i in range(2):
        for j in range(2):
            #axes[i].autoscale(enable=True, axis='both', tight=True)
            axes[i,j].grid(which='minor', color='lightgrey', linestyle='--')
            axes[i,j].grid(which='major', color='grey', linestyle='-')
            axes[i,j].tick_params(labelsize=25)
            axes[i,j].set_axisbelow(True)

    plt.tight_layout()
    plt.savefig("TempPlots/PlotFinal1.pdf", bbox_inches="tight")#, dpi=800)

    return None




def CheckMinMax():
    with open("TDataFile_FreeParam", "r") as f:
        l = f.readlines()
    data =  np.array([l[i].split() for i in range(2,len(l))])
    df = pd.DataFrame(data, columns=["Lam1", "Lam2", "Lam3", "Lam4", "lam1", "lam2", "lam3", "lam4", "lam5", "lam6", "lam7", "mT", "mS"])


    df["mT"] = pd.to_numeric(df["mT"])
    df["mS"] = pd.to_numeric(df["mS"])
    df["lam4"] = pd.to_numeric(df["lam4"])

    #max_mT = df["mT"].max()
    #min_mT = df["mT"].min()

    #max_mS = df["mS"].max()
    #min_mS = df["mS"].min()

    #print("Maximum value in mT column:", max_mT)
    #print("Minimum value in mT column:", min_mT)

    #print("Maximum value in mS column:", max_mS)
    #print("Minimum value in mS column:", min_mS)

    print("MAX \n", df.max())
    print("MIN \n", df.min())

    #Maximum value in mT column: 257079.75113
    #Minimum value in mT column: 58320.5382
    #Maximum value in mS column: 891149.85392
    #Minimum value in mS column: 0.13576

    #lam4: -20 - 20


    return None


#PlotDataGeneral()
#FilterData()
#CheckBFB()
#PlotKDE()
#PlotST()
PlotHBS()
#PlotSensitivity()
#FinalPlot()
#CheckMinMax()


