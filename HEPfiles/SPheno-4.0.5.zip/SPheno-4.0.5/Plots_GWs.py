import sys
import random as rand
import math
import numpy as np
import glob
import os
import matplotlib as mpl
from matplotlib import pyplot as plt
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.cm as cm
#matplotlib.rcParams['text.usetex'] = True
import matplotlib.patches as mpatches
from matplotlib.ticker import AutoMinorLocator
from mpl_toolkits.axes_grid1 import make_axes_locatable, axes_size
import matplotlib.colors as colors

import pandas as pd
import seaborn as sns
import ast

import random
from sklearn.preprocessing import StandardScaler, FunctionTransformer
from scipy import stats
from scipy.stats import gaussian_kde

import glob




minorLocator=AutoMinorLocator()
#plt.style.use('grayscale')
plt.rcParams['font.family'] = 'serif'
plt.rcParams['axes.linewidth'] = 1.5
colorsbasis=['#00A0B0','#6A4A3C','#CC333F','#EB6841','#EDC951','#A3A948','#B3E099','#5165E9','#B1B59D']
#-------------------------------------------------#

mpl.rcParams['text.usetex']=True 
mpl.rcParams['text.latex.preamble'] = r'\usepackage{bm}'
plt.rcParams.update({'font.size': 20})
mpl.rcParams["legend.framealpha"] = 1.0
mpl.rcParams['axes.spines.right'] = False
mpl.rcParams['axes.spines.top'] = False
mpl.rcParams["figure.figsize"] = [8.5, 5.5]



def ReadData():
    with open("FDataFile_Labels_GW", "r") as f:
        l = f.readlines()
    data =  np.array([l[i].split()[1:5] for i in range(2,len(l))])
    df = pd.DataFrame(data, columns=['alpha', 'beta', 'fpeak', 'ompeak']) 
    df = df.sort_values('ompeak', ascending=False)
    #x = np.float64(df['fpeak'].tolist()[:10])
    #y = np.float64(df['ompeak'].tolist()[:10])
    #print(x,y)
    #x = [np.float(value) for value in x]
    #y = [np.float(value) for value in y]
    #plt.plot(df['fpeak'].tolist(), df['ompeak'].tolist(), 'bo')
    #plt.plot(x,y, 'bo')
    #plt.show()

    return df

def uncer(l): #My definition of uncertainty
    l = list(l)
    if l == []:
        sig = 0
    else:
        a = np.mean(l)
        b = (max(l)-min(l))/2
        sig = abs(b/a)
    return(sig)

# SENSITIVITY CURVES
def Ohsq_LISA(f):
    return 1.e-14*(3.5800000000000006e-15/f**4 + 3.26e-10/f**3 + 1.2e-6/f**2 + 0.00248/f + 258.*f + 18100.*f**2 + 1.5e6*f**3)

def Ohsq_BBO(f):
    return 1.e-14*(0.00013500000000000003 + 1.77e-13/f**4 + 0.000033520143197784825/f**1.5 + 0.0022299999999999998*f + 0.0012900000000000001*f**2 + 0.00299*f**3)

def Ohsq_DECIGO(f):
    return 1.e-14*(0.0011 + 3.82e-13/f**4 + 0.00007146747511980537/f**1.5 + 0.00256*f + 0.0291*f**2 + 0.007540000000000001*f**3)      

def PlotSensitivity(df):
    bar_label=r'$\mathrm{log_{10}}\alpha$'
    fig, ax = plt.subplots(figsize=(8, 5))

    plt.ylabel(r'$h^2 \Omega_\mathrm{GW}^\mathrm{peak}$', fontweight='bold', fontsize=25)
    plt.xlabel(r'$f_\mathrm{peak} \,\, \mathrm{[Hz]}$', fontweight='bold', fontsize=25)
    plt.tick_params(labelsize=25)
    cm = plt.cm.gist_rainbow

    s = ax.scatter(np.float64(df['fpeak']), np.float64(df['ompeak']), c=np.log10(np.float64(df["alpha"])), cmap='gist_rainbow', s=7, edgecolors='none', rasterized=True,label='_Hidden label', marker="o")

    #plt.tick_params(labelsize=20)
    plt.autoscale(enable=True, axis='both', tight=True)

    ax.set_axisbelow(True)
    plt.grid(which='minor', color='lightgrey', linestyle='--')
    plt.grid(which='major', color='grey', linestyle='-')

    colorb = plt.colorbar(s, pad=0.025, fraction=0.1)
    colorb.ax.locator_params(nbins=5)
    colorb.set_label(bar_label, labelpad=8, fontsize=20)
    colorb.ax.tick_params(labelsize=20)

    xmin = 10 ** (-3)
    xmax = 1000
    f = np.arange(xmin, xmax, (xmax - xmin) / 1000000., float)
    Omega_LISA = Ohsq_LISA(f)
    Omega_BBO = Ohsq_BBO(f)
    Omega_DECIGO = Ohsq_DECIGO(f)

    plt.plot(f,Omega_LISA,'--',color='r',linewidth=2, label=r'LISA')
    plt.plot(f,Omega_BBO,'-.',color='g',linewidth=2, label=r'BBO')
    plt.plot(f,Omega_DECIGO,':',color='b',linewidth=2.5, label=r'DECIGO')
    plt.legend(loc='upper right', fontsize = 16)

    plt.ylim([10 ** (-18), 10 ** (-8)])
    plt.xlim([xmin, xmax])

    ax.set_xscale('log')
    ax.set_yscale('log')

    #plt.gca().set_aspect(1)
    #plt.figure(figsize=(10,6))

    plt.subplots_adjust(left=0.24, bottom=0.24)
    plt.savefig('TempPlots/GW_Sensitivity_Curve.pdf', bbox_inches='tight',dpi=400)
    #plt.show()

    
    return None




df=ReadData()
PlotSensitivity(df)




"""
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams['text.usetex'] = True
import math
import pandas as pd


# In[11]:


def sensitivity_curves(f):
    OmegaLISA = 1.e-14*(3.5800000000000006e-15/f**4 + 3.26e-10/f**3 + 1.2e-6/f**2 + 0.00248/f + 258.*f + 18100.*f**2 + 1.5e6*f**3)
    OmegaBBO = (0.00013500000000000003 + 1.77e-13/f**4 + 0.000033520143197784825/f**1.5 + 0.0022299999999999998*f + 0.0012900000000000001*f**2 + 0.00299*f**3)/1.e14
    OmegaDECIGO = (0.0011 + 3.82e-13/f**4 + 0.00007146747511980537/f**1.5 + 0.00256*f + 0.0291*f**2 + 0.007540000000000001*f**3)/1.e14
    return OmegaLISA, OmegaBBO, OmegaDECIGO

def Ohsq_LISA(f):
    return 1.e-14*(3.5800000000000006e-15/f**4 + 3.26e-10/f**3 +                   1.2e-6/f**2 + 0.00248/f + 258.*f + 18100.*f**2 + 1.5e6*f**3)

def Ohsq_BBO(f):
    return 1.e-14*(0.00013500000000000003 + 1.77e-13/f**4 +                   0.000033520143197784825/f**1.5 + 0.0022299999999999998*f +                   0.0012900000000000001*f**2 + 0.00299*f**3)

def Ohsq_DECIGO(f):
    return 1.e-14*(0.0011 + 3.82e-13/f**4 + 0.00007146747511980537/f**1.5 +                   0.00256*f + 0.0291*f**2 + 0.007540000000000001*f**3)      

import sys
sys.path.append('/home/felipe/JoaoPino/1-IDMTwoloop/IDM_potential/Antonio_codes/')
sys.path.append('/home/felipe/JoaoPino/1-IDMTwoloop/IDM_potential/Antonio_codes/utils_snr')


# In[12]:


from utils_snr.espinosa import kappav, ubarf, ubarf_to_alpha
from utils_snr.SNR_precompute import get_SNRcurve
from utils_snr.curves import rstar_to_beta
from utils_snr.snr import *

# define here what you want for the color bar
def color1(data):
    return data['Ompeak']

def color2(data):
    return data['alpha']

def SNR_fgw_plot(dataframe,color_function, 
                 bar_label=r'$h^2 \Omega_\mathrm{GW}^\mathrm{peak}$',file_name:str='all'):
    
    plt.figure(figsize=(18,8))
    ax = plt.subplot(121)
    
    plt.ylabel(r'$h^2 \Omega_\mathrm{GW}^\mathrm{peak}$', fontweight = 'bold', fontsize = 25)
    plt.xlabel(r'$f_\mathrm{peak} \,\, \mathrm{[Hz]}$', fontweight = 'bold', fontsize = 25)
    plt.tick_params(labelsize=25)
    cm = plt.cm.gnuplot

    xmin=10**(-5)
    xmax=10**(0)
    ymin=10**(-17)
    ymax=10**(-8)

    plt.xlim([xmin, xmax])
    plt.ylim([ymin, ymax])
    #s=ax.scatter(dataframe['fpeak'],dataframe['Ompeak'], c=color_function(dataframe).values, 
    #             cmap=cm, s=10, edgecolors='none',rasterized=True)
    s=ax.scatter(dataframe['fpeak'],dataframe['Ompeak'], c=color2(dataframe).values, 
                 s=10, edgecolors='none',rasterized=True)
    

    plt.tick_params(labelsize=20) 
    plt.autoscale(enable=True, axis='both', tight=True)

    ax.set_axisbelow(True)
    plt.grid(which='minor', color='lightgrey', linestyle='--')
    plt.grid(which='major', color='grey', linestyle='-')

    colorb=plt.colorbar(s,pad=0.05,fraction=0.2)
    colorb.ax.locator_params(nbins=5)
    colorb.set_label(r'$\alpha$',labelpad=9, fontsize=25)
    colorb.ax.tick_params(labelsize=25)
    
    f = np.arange(xmin, xmax, (xmax-xmin)/100000., float)
    Omega_LISA = Ohsq_LISA(f)
    Omega_BBO = Ohsq_BBO(f)
    Omega_DECIGO = Ohsq_DECIGO(f)

    plt.plot(f,Omega_LISA,'--',color='gray',linewidth=2, label=r'LISA')
    plt.plot(f,Omega_BBO,'-.',color='gray',linewidth=2, label=r'BBO')
    plt.plot(f,Omega_DECIGO,':',color='gray',linewidth=2.5, label=r'DECIGO')
    plt.legend(loc='best', fontsize = 16)


    ax.set_xscale('log')
    ax.set_yscale('log')

    plt.savefig('/home/felipe/JoaoPino/1-IDMTwoloop/IDM_potential/Plots/Dvh_6D.pdf', bbox_inches='tight',dpi=400)
 


    ######################
    ######################
    ######################
    

    fig, ax2 = plt.subplots(figsize=(8, 5))
    #ax2 = plt.subplot(122)
    vw = .95
    alpha_list=[list(dataframe['alpha'].values)] 
    BetaoverH_list=[list(dataframe['betaH'].values)]
    Tstar=dataframe['Tp'].mean()
    gstar=106.75
    label_list=None
    title_list=None
    MissionProfile=0
    usetex=False
    hugeAlpha=False


    red = np.array([1,0,0])
    darkgreen = np.array([0,0,1])
    color_tuple = tuple([tuple(0.5*(np.tanh((0.5-f)*10)+1)*red
                               + f**0.5*darkgreen)  for f in (np.arange(6)*0.2)])

    
    matplotlib.rc('font', family='serif')
    matplotlib.rc('mathtext', fontset='dejavuserif')
    
    
    if hugeAlpha:
        ubarfmax = 0.866
    else:
        ubarfmax = 0.6


        
    tshHn, snr, log10HnRstar, log10Ubarf = get_SNRcurve(Tstar, gstar, MissionProfile, ubarfmax)
    log10BetaOverH = np.log10(rstar_to_beta(np.power(10.0,
                                                     log10HnRstar),
                                               vw))
    log10alpha = np.log10(ubarf_to_alpha(vw, np.power(10.0, log10Ubarf)))

    a = ubarf_to_alpha(vw, np.power(10.0, log10Ubarf))
    b = np.power(10.0, log10Ubarf)
    
    levels = np.array([1,5,20,50,100,200])
    levels_tsh = np.array([0.001,0.01,0.1,1,10,100])
    levels_tsh_hugeAlpha = np.array([0.0000001,0.000001,0.00001,0.0001])
    
    
    # Where to put contour label, based on y-coordinate and contour value
    def find_place(snr, wantedy, wantedcontour):
        nearesty = (np.abs(log10BetaOverH-wantedy)).argmin()
        nearestx = (np.abs(snr[nearesty,:]-wantedcontour)).argmin()

        return (log10alpha[nearestx],wantedy)

    
    # location of contour labels
    locs = [find_place(snr, 2, wantedcontour) for wantedcontour in levels]

    locs_tsh = [(int(math.ceil(min(log10alpha))) + 0.2,x)                 for x in range(int(math.ceil(min(log10BetaOverH))),
                               int(math.floor(max(log10BetaOverH))+1))]
    
    CS = ax2.contour(log10alpha, log10BetaOverH, snr, levels, linewidths=1,
                    colors=color_tuple,
                     extent=(log10alpha[0], log10alpha[-1],
                             log10BetaOverH[0], log10BetaOverH[-1]))
    CStsh = ax2.contour(log10alpha, log10BetaOverH,
                       tshHn, levels_tsh, linewidths=1,
                       linestyles='dashed', colors='gray',
                       extent=(log10alpha[0], log10alpha[-1],
                               log10BetaOverH[0], log10BetaOverH[-1]))

    if hugeAlpha:
        CStsh_hugeAlpha = ax2.contour(log10alpha, log10BetaOverH,
                           tshHn, levels_tsh_hugeAlpha, linewidths=1,
                           linestyles='dashed', colors='k',
                           extent=(log10alpha[0], log10alpha[-1],
                                   log10BetaOverH[0], log10BetaOverH[-1]))
        
    
    CSturb = ax2.contourf(log10alpha, log10BetaOverH, tshHn, [1, 1000], colors=('gray'), alpha=0.5,
                          extent=(log10alpha[0], log10alpha[-1],
                                  log10BetaOverH[0], log10BetaOverH[-1]))

    
    ax2.clabel(CS, inline=1, fontsize=8, fmt="%.0f", manual=locs)
    ax2.clabel(CStsh, inline=1, fontsize=8, fmt="%g", manual=locs_tsh)
    ax2.set_ylabel(r'$ \beta/H $', fontsize=25)
    ax2.set_xlabel(r'$\alpha$', fontsize=25)

    ax2.set_xlim(min(log10alpha),max(log10alpha))
    ax2.set_ylim(min(log10BetaOverH),max(log10BetaOverH))
    
    for i, (BetaoverH_set, alpha_set) in enumerate(zip(BetaoverH_list, alpha_list)):
        
        BetaOverH_log_set = [math.log10(BetaoverH) for BetaoverH in BetaoverH_set]

        alpha_log_set = [math.log10(alpha) for alpha in alpha_set]

        benchmarks = ax2.scatter(alpha_log_set, BetaOverH_log_set,cmap='gist_rainbow',
                                 s=5,
                                 c=color_function(dataframe).values,rasterized=True#,norm=matplotlib.colors.LogNorm()
                                 )

    
    xtickpos = list(range(int(math.ceil(min(log10alpha))),
                     int(math.floor(max(log10alpha))+1)))
    xticklabels = [r'$10^{%d}$' % ind
           for ind in list(range(int(math.ceil(min(log10alpha))),
                                 int(math.floor(max(log10alpha))+1)))]


    ytickpos = list(range(int(math.ceil(min(log10BetaOverH))),
                     int(math.floor(max(log10BetaOverH))+1)))
    yticklabels = [r'$10^{%d}$' % ind
                   for ind in list(
                           range(int(math.ceil(min(log10BetaOverH))),
                                 int(math.floor(max(log10BetaOverH))+1)))]    

        
    colorb=plt.colorbar(benchmarks,pad=0.05,fraction=0.2)
    #colorb.ax.locator_params(nbins=5)
    colorb.set_label(bar_label,labelpad=9, fontsize=25)
    colorb.ax.tick_params(labelsize=25)
    
    ax2.set_xticks(xtickpos)
    ax2.set_xticklabels(xticklabels,fontsize=25)
    ax2.xaxis.set_minor_locator(matplotlib.ticker.AutoMinorLocator())
    ax2.set_yticks(ytickpos)
    ax2.set_yticklabels(yticklabels,fontsize=25)
    ax2.yaxis.set_minor_locator(matplotlib.ticker.AutoMinorLocator())
    
    # position bottom right
    ax2.text(0.95, 0.05, 'LISACosWG',
             fontsize=50, color='gray',
             ha='right', va='bottom', alpha=0.4)
    
    plt.tight_layout()
    
    '''ax.set_xlim([10**-9,10**6])
    ax.set_ylim(bottom=10**-50)'''
    
    #Save data here
    #plt.savefig('/home/felipe/JoaoPino/1-IDMTwoloop/IDM_potential/Plots/snr_plot_LISA.pdf', bbox_inches='tight', dpi=400)

    plt.show()

data = data1.loc[(Ohsq_LISA(data1["fpeak"]) < data1["Ompeak"])]
SNR_fgw_plot(dataframe=data, color_function=color1, file_name='withvev')


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:



"""
