from UserInput import model
#=============================================================== PATHS ========================================================
LesHouches_path = "LesHouches.in.{}".format(model)
SPheno_spc_path = "SPheno.spc.{}".format(model)

HB_script_path = "../higgsbounds-5.10.2/build/RunHiggsBounds.sh"
HB_path = "../higgsbounds-5.10.2/build"
HB_output_path = "HiggsBounds_results.dat"

HS_script_path = "../higgssignals-2.6.2/build/RunHiggsSignals.sh"
HS_path = "../higgssignals-2.6.2/build"
HS_output_path = "HiggsSignals_results.dat"

CT_directory_path = "../DRalgo-1.0.2-beta/examples"
CT_infile_name = "LS_TColor_DRPython" #Remove .py
CT_class_name = "LS_TColor"
#============================================================================================================================
