#!/bin/bash

for ((i=1; i<=64; i++ ))
#for ((i=$1; i<=$1; i++ ))
do
	cd RunDir$i/SPheno-4.0.5

	#tail +3 TDataFile_Labels_GW >> ../../TDataFile_Labels_GW
	#tail +3 TDataFile_Labels >> ../../TDataFile_Labels
	#tail +3 TDataFile_Masses >> ../../TDataFile_Masses
	#tail +3 TDataFile_FreeParam >> ../../TDataFile_FreeParam

        tail +3 PDataFile_Labels_GW >> ../../FDataFile_Labels_GW
        tail +3 PDataFile_Labels >> ../../FDataFile_Labels
        tail +3 PDataFile_Masses >> ../../FDataFile_Masses
        tail +3 PDataFile_FreeParam >> ../../FDataFile_FreeParam

	cd ../..
	echo "copied data from RunDir$i"
done

