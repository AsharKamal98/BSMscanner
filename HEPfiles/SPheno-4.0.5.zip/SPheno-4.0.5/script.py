import matplotlib.pyplot as plt
import numpy as np
import DataConstructor as DC

with open("TDataFile_Labels_GW", "r") as file:
    l = file.readlines()
lines = np.array([l[i].split()[0] for i in range(2,len(l))])
lines = lines.astype(np.float64)

index_list=[]
c1,c2,c3,c4=0,0,0,0
for i in range(len(lines)):
    item = lines[i]
    if int(item)==1:    #FOPT
        c1+=1
        index_list.append(i)
        print(i)
    elif int(item)==2:  #SOPT
        c2+=1
    elif item==0:       #NO PT
        c3+=1
    elif item==-1:      #NUMERIC ERROR
        c4+=1
    else:
        print("Something went wrong!")

print("FOPT", c1)
print("SOPT", c2)
print("NO PT", c3)
print("NUMERIC ERROR", c4)

with open("TDataFile_FreeParam", "r") as file:
    l = file.readlines()

lines = np.array([l[i].split() for i in range(2,len(l))], dtype=object)
lines = lines.astype(np.float64)

params=[]
for item in index_list:
    params.append(lines[item])
print("params", params)


with open("TDataFile_Labels_GW", "r") as file:
    l = file.readlines()

lines = np.array([l[i].split()[0] for i in range(2,len(l))])
lines = lines.astype(np.float64)

for item in index_list:
    print("Labels", lines[item])




for item in params:
    item = item.tolist()
    tn_trans = DC.RunCosmoTransitions(item)
    print(tn_trans)
#    if len(tn_trans)>0:
#        transition_order = tn_trans[0]['trantype']
#        if transition_order==1:
#            print("FIRST ORDER PHASE TRANSITION!########################################################################")
#            print(item)
#            break
#    else:
#        print("nothin")
